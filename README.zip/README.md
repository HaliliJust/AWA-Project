# SmartfIT Management System (UI Only)

A React front-end for a gym management system, covering **Member/Client** and
**Trainer** roles, with shared **Payments** functions available on each
role's own dashboard. This is a UI-only build — every screen is laid out and
wired with routing, but no data is actually saved (all lists use static mock
data from `src/data/mockData.js`). Hook up a real API/backend to make it
functional.

## Getting started

```bash
npm install
npm start
```

Opens at http://localhost:3000. It redirects to `/login` by default.

## Structure

```
src/
  components/     Reusable UI pieces (Sidebar, Topbar, StatCard, DataTable,
                   IDCard, MembershipCard, ...)
  layouts/        DashboardLayout wraps Sidebar + Topbar + page content
  pages/
    auth/          Login (shared by Member and Trainer)
    member/        Register, Dashboard, Profile (with Membership Card),
                    Membership Status, Renew, Workout Plans (view/select),
                    Attendance History
    trainer/       Daily Schedule, Assigned Members, Workout Programs,
                    Update Plans, Schedule Sessions, Progress Monitoring,
                    Workout History, Trainer Information (ID card + QR)
    payments/      Shared: Payment Dashboard, Record Payments,
                    Verify Payments, Generate Receipts, Payment History,
                    Payment Reports — routed under both /member/payments/*
                    and /trainer/payments/*
  data/           mockData.js — placeholder data used by every page
  index.css       Design tokens + all styling (dark/red theme, plain CSS)
```

## Switching roles

There's a **Member / Trainer** switcher at the top of the sidebar — this app
doesn't have real auth yet, so it's just a way to preview both role
dashboards. `/login` lets you pick which role to log in as before submitting.

## Design system

All styling lives in `src/index.css` using CSS custom properties (see the
`:root` block) — colors, spacing, radii, and fonts are all tokens, so
re-theming means editing variables in one place rather than hunting through
components. No Tailwind or component library is used; every class is
hand-written.

## Next steps to make it functional

- Add a real auth flow (Login/Register currently just navigate away)
- Decide where user accounts are stored (localStorage for a quick mock, or a
  real backend/DB for production) and persist session state
- Replace `mockData.js` with API calls (React Query / fetch / axios)
- Add form validation and submit handlers to every form
- Add edit/delete actions to tables (currently static buttons)
- Wire the Workout Plan "Select" and ID card QR to real data

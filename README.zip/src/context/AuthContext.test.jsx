import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import { AuthProvider, useAuth } from './AuthContext';
let auth, root, container;
function Harness() { auth = useAuth(); return null; }
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  localStorage.clear(); sessionStorage.clear();
  container = document.createElement('div'); root = createRoot(container);
});
afterEach(() => act(() => root.unmount()));
function render() { act(() => root.render(<AuthProvider><Harness /></AuthProvider>)); }
function remove(username) {
  localStorage.setItem('smartfit.members.v2', JSON.stringify({members: {}, removals: {[username]: {reason: 'Repeated policy violations'}}}));
}
test.each([['member001', 'member123'], ['trainer001', 'trainer123']])('removed %s cannot log in and sees the reason only after correct credentials', async (username, password) => {
  remove(username); render();
  let result;
  await act(async () => { result = await auth.login(username, password); });
  expect(result.ok).toBe(false);
  expect(result.error).toContain('Repeated policy violations');
  expect(auth.isAuthenticated).toBe(false);
  await act(async () => { result = await auth.login(username, 'wrong'); });
  expect(result.error).toBe('Incorrect username or password.');
});
test('removal in another tab revokes an existing session', async () => {
  render();
  await act(async () => { await auth.login('member001', 'member123'); });
  expect(auth.isAuthenticated).toBe(true);
  remove('member001');
  act(() => window.dispatchEvent(new Event('storage')));
  expect(auth.isAuthenticated).toBe(false);
  expect(sessionStorage.getItem('smartfit.session')).toBeNull();
});
test('removed account session is rejected when the app reloads', () => {
  sessionStorage.setItem('smartfit.session', JSON.stringify({username: 'trainer001', role: 'trainer'}));
  remove('trainer001'); render();
  expect(auth.isAuthenticated).toBe(false);
});

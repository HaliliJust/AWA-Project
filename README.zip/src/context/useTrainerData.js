import { useAuth } from './AuthContext';
import { useMember } from './MemberContext';
import { trainerData } from '../services/trainerData';

export default function useTrainerData() {
  const { user } = useAuth();
  const { database } = useMember();
  return trainerData(database, user?.username);
}

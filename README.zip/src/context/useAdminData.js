import { useMember } from './MemberContext';
import { adminData } from '../services/adminData';
export default function useAdminData() {
  const { database } = useMember();
  return adminData(database);
}

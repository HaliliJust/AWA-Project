import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import { MemberProvider, useMember } from './MemberContext';
import { STORAGE_KEY, defaultMemberState, localDate } from '../services/memberStore';
let mockUser = {
  username: 'member001',
  role: 'member',
  name: 'Justine'
};
jest.mock('./AuthContext', () => ({
  useAuth: () => ({
    user: mockUser
  })
}));
let context, root, container;
function Harness() {
  context = useMember();
  return null;
}
function render() {
  act(() => root.render(<MemberProvider><Harness /></MemberProvider>));
}
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  localStorage.clear();
  mockUser = {
    username: 'member001',
    role: 'member',
    name: 'Justine'
  };
  container = document.createElement('div');
  document.body.append(container);
  root = createRoot(container);
  render();
});
afterEach(() => {
  act(() => root.unmount());
  container.remove();
});
function call(fn) {
  let result;
  act(() => {
    result = fn();
  });
  return result;
}
function future(days = 2) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return localDate(d);
}
test('renewal, request, trainer alternative, acceptance, and reload share the same record', () => {
  expect(call(() => context.renew(2, 'GCash', false))).toBe(true);
  expect(call(() => context.addWorkoutRequest({
    program: 'Strength',
    trainerId: 'trainer001',
    date: future(),
    time: '10:00',
    duration: 60
  }))).toBe(true);
  const id = context.state.workoutRequests[0].id;
  mockUser = {
    username: 'trainer001',
    role: 'trainer'
  };
  render();
  expect(call(() => context.respond('member001', id, 'Proposed', {
    date: future(3),
    time: '11:00'
  }))).toBe(true);
  mockUser = {
    username: 'member001',
    role: 'member'
  };
  render();
  expect(context.state.workoutSchedule[0].status).toBe('Proposed');
  expect(call(() => context.updateWorkoutScheduleStatus(id, 'Scheduled'))).toBe(true);
  expect(context.state.notifications.some(n => n.type === 'trainer_response')).toBe(true);
  act(() => context.refresh());
  expect(context.state.workoutSchedule[0].status).toBe('Scheduled');
  expect(context.state.payments).toHaveLength(1);
});
test('inactive membership and wrong trainer cannot change requests', () => {
  expect(call(() => context.addWorkoutRequest({
    date: future(),
    time: '10:00',
    duration: 60,
    trainerId: 'trainer001'
  }))).toBe(false);
  call(() => context.renew(1, 'GCash', false));
  call(() => context.addWorkoutRequest({
    program: 'Strength',
    date: future(),
    time: '10:00',
    duration: 60,
    trainerId: 'trainer001'
  }));
  const id = context.state.workoutRequests[0].id;
  mockUser = {
    username: 'intruder',
    role: 'trainer'
  };
  render();
  expect(call(() => context.respond('member001', id, 'Accepted'))).toBe(false);
});
test('points cannot be spent twice and profile survives refresh', () => {
  const db = JSON.parse(localStorage.getItem(STORAGE_KEY));
  db.members.member001.membership.points = 100;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  act(() => context.refresh());
  expect(call(() => context.redeem('guest'))).toBe(true);
  expect(call(() => context.redeem('guest'))).toBe(false);
  expect(call(() => context.updateProfile({
    name: 'Updated',
    avatar: 'data:image/png;base64,test'
  }))).toBe(true);
  act(() => context.refresh());
  expect(context.state.profile.name).toBe('Updated');
  expect(context.state.rewards).toHaveLength(1);
});
test('storage failure is reported and does not show a successful save', () => {
  const spy = jest.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
    throw new Error('Storage full');
  });
  expect(call(() => context.renew(1, 'GCash', false))).toBe(false);
  expect(context.error).toBe('Storage full');
  spy.mockRestore();
});
test('completed workouts update attendance and notification together', () => {
  const s = defaultMemberState();
  s.membership.expiryDate = future(20);
  s.workoutSchedule = [{
    id: 'session',
    date: localDate(),
    time: '00:01',
    duration: 30,
    program: 'Strength',
    status: 'Missed'
  }];
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    members: {
      member001: s
    }
  }));
  act(() => context.refresh());
  expect(call(() => context.updateWorkoutScheduleStatus('session', 'Completed'))).toBe(true);
  expect(context.state.attendanceHistory).toHaveLength(1);
  expect(context.state.notifications.some(n => n.type === 'workout_completed')).toBe(true);
});

test('personal plans, edited requests, and trainer suggestions persist with role-specific notifications', () => {
  call(() => context.renew(1, 'GCash', false));
  const exerciseItems = [{ name: 'Squat', sets: 3, reps: '10', rest: 60 }];
  expect(call(() => context.savePersonalPlan({ id: 'mine', name: 'My routine', exerciseItems }))).toBe(true);
  call(() => context.addWorkoutRequest({ program: 'My routine', exerciseItems, trainerId: 'trainer001', date: future(), time: '10:00', duration: 60 }));
  const id = context.state.workoutRequests[0].id;
  expect(call(() => context.addWorkoutRequest({ requestId: id, program: 'Edited routine', exerciseItems, trainerId: 'trainer001', date: future(), time: '11:00', duration: 60 }))).toBe(true);
  expect(context.state.workoutRequests).toHaveLength(1);
  mockUser = { username: 'trainer001', role: 'trainer' }; render();
  expect(context.notifications.some(n => n.title === 'Workout request updated')).toBe(true);
  call(() => context.markAllRead());
  expect(context.unreadCount).toBe(0);
  const suggested = [{ name: 'Goblet squat', sets: 2, reps: '8', rest: 90 }];
  expect(call(() => context.respond('member001', id, 'Proposed', { program: 'Trainer revision', exerciseItems: suggested, notes: 'Start here' }))).toBe(true);
  mockUser = { username: 'member001', role: 'member' }; render();
  expect(context.state.workoutSchedule[0].exerciseItems).toEqual(suggested);
  expect(context.state.workoutRequests[0].program).toBe('Trainer revision');
  expect(call(() => context.updateWorkoutScheduleStatus(id, 'Scheduled'))).toBe(true);
  expect(call(() => context.addWorkoutRequest({ requestId: id, program: 'Cannot change confirmed plan', exerciseItems, trainerId: 'trainer001', date: future(), time: '12:00', duration: 60 }))).toBe(false);
  act(() => context.refresh());
  expect(context.state.personalPlans[0].exerciseItems).toEqual(exerciseItems);
  mockUser = { username: 'trainer001', role: 'trainer' }; render();
  expect(context.notifications.some(n => n.title === 'Workout suggestion accepted')).toBe(true);
  expect(context.notifications.some(n => n.title === 'Membership renewed')).toBe(false);
});

test.each(['Accepted', 'Denied'])('trainer %s response notifies the member and persists', status => {
  call(() => context.renew(1, 'GCash', false));
  call(() => context.addWorkoutRequest({ program: 'Strength', trainerId: 'trainer001', date: future(), time: '10:00', duration: 60 }));
  const id = context.state.workoutRequests[0].id;
  mockUser = { username: 'trainer001', role: 'trainer' }; render();
  expect(call(() => context.respond('member001', id, status))).toBe(true);
  mockUser = { username: 'member001', role: 'member' }; render();
  expect(context.notifications.some(n => n.title === `Workout request ${status.toLowerCase()}`)).toBe(true);
  expect(context.state.workoutRequests[0].status).toBe(status);
});

test('declining a trainer suggestion notifies the trainer and allows a revised request', () => {
  call(() => context.renew(1, 'GCash', false));
  const request = { program: 'Strength', trainerId: 'trainer001', date: future(), time: '10:00', duration: 60 };
  call(() => context.addWorkoutRequest(request));
  const id = context.state.workoutRequests[0].id;
  mockUser = { username: 'trainer001', role: 'trainer' }; render();
  call(() => context.respond('member001', id, 'Proposed', {time: '11:00'}));
  mockUser = { username: 'member001', role: 'member' }; render();
  expect(call(() => context.updateWorkoutScheduleStatus(id, 'Cancelled'))).toBe(true);
  expect(call(() => context.addWorkoutRequest({...request, requestId: id}))).toBe(true);
  expect(context.state.workoutSchedule).toHaveLength(0);
  mockUser = { username: 'trainer001', role: 'trainer' }; render();
  expect(context.notifications.some(n => n.title === 'Workout suggestion declined')).toBe(true);
});

test('profile measurements and body corrections survive refresh together', () => {
  const measurements = { height: 180, chest: 105, waist: 85, hips: 102, shoulders: 49 };
  expect(call(() => context.updateProfile({ avatar: 'data:image/png;base64,test', height: 180, weight: 82, bodyType: 'Endomorph', measurements }))).toBe(true);
  act(() => context.refresh());
  expect(context.state.profile).toMatchObject({ height: 180, weight: 82, bodyType: 'Endomorph', measurements });
});

test('empty personal plans are rejected without saving', () => {
  call(() => context.renew(1, 'GCash', false));
  expect(call(() => context.savePersonalPlan({ name: 'Empty plan', exerciseItems: [] }))).toBe(false);
  expect(context.state.personalPlans).toHaveLength(0);
});

test('admin removal requires a reason, excludes the trainer, and cancels future training while keeping history', () => {
  call(() => context.renew(1, 'GCash', false));
  call(() => context.addWorkoutRequest({ program: 'Strength', trainerId: 'trainer001', date: future(), time: '10:00', duration: 60 }));
  const id = context.state.workoutRequests[0].id;
  mockUser = { username: 'trainer001', role: 'trainer' }; render();
  call(() => context.respond('member001', id, 'Accepted'));
  mockUser = { username: 'admin', role: 'admin' }; render();
  expect(call(() => context.removeGymAccount('trainer001', '  '))).toBe(false);
  expect(call(() => context.removeGymAccount('admin', 'Cannot remove an administrator'))).toBe(false);
  expect(call(() => context.removeGymAccount('trainer001', 'Repeated missed appointments'))).toBe(true);
  expect(context.database.removals.trainer001).toMatchObject({reason: 'Repeated missed appointments', removedBy: 'admin', role: 'trainer'});
  expect(context.database.members.member001.workoutSchedule[0].status).toBe('Cancelled');
  expect(context.database.members.member001.workoutRequests[0].status).toBe('Cancelled');
  expect(context.trainers).toHaveLength(0);
  expect(context.database.members.member001.payments).toHaveLength(1);
  act(() => context.refresh());
  expect(context.database.removals.trainer001.reason).toBe('Repeated missed appointments');
});

test('member removal is admin-only and removed members cannot mutate saved data', () => {
  expect(call(() => context.removeGymAccount('trainer001', 'Not authorized'))).toBe(false);
  mockUser = { username: 'admin', role: 'admin' }; render();
  expect(call(() => context.removeGymAccount('MEMBER001', 'Membership terminated by the gym'))).toBe(true);
  mockUser = { username: 'member001', role: 'member' }; render();
  expect(call(() => context.renew(1, 'GCash', false))).toBe(false);
  expect(context.database.members.member001.profile.name).toBeTruthy();
});

test('failed removal storage write leaves account and schedules unchanged', () => {
  mockUser = { username: 'admin', role: 'admin' }; render();
  const spy = jest.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new Error('Storage full'); });
  expect(call(() => context.removeGymAccount('member001', 'A required explanation'))).toBe(false);
  expect(context.database.removals.member001).toBeUndefined();
  spy.mockRestore();
  act(() => context.refresh());
  expect(context.database.removals.member001).toBeUndefined();
});

import { createContext, useContext, useState, useCallback, useMemo, useEffect } from "react";
import { accountRemoval } from "../services/accountAccess";
import { DEMO_ACCOUNTS } from "../data/demoAccounts";
import { verifyLogin, displayName, initialsOf } from "../services/accountStore";

// ---------------------------------------------------------------------------
// Sign-in checks two places, in this order:
//   1. the fixed demo accounts        (data/demoAccounts.js)
//   2. accounts created via "Create Account", saved in localStorage
//                                     (services/accountStore.js)
// The role comes from whichever account matches — there is no manual role
// picker anywhere in the UI.
// ---------------------------------------------------------------------------

const SESSION_KEY = "smartfit.session";

const AuthContext = createContext(null);

function readSession() {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    const session = raw ? JSON.parse(raw) : null;
    if (session && accountRemoval(session.username)) { sessionStorage.removeItem(SESSION_KEY); return null; }
    return session;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => readSession());

  useEffect(() => {
    function checkAccess() {
      if (!user) return;
      try {
        if (!accountRemoval(user.username)) return;
      } catch { /* Saved access data cannot be verified. End the session. */ }
      sessionStorage.removeItem(SESSION_KEY);
      setUser(null);
    }
    window.addEventListener('storage', checkAccess);
    window.addEventListener('focus', checkAccess);
    const timer = setInterval(checkAccess, 5000);
    return () => { window.removeEventListener('storage', checkAccess); window.removeEventListener('focus', checkAccess); clearInterval(timer); };
  }, [user]);

  const login = useCallback(async (username, password) => {
    const typed = String(username).trim().toLowerCase();

    let session = null;

    const demo = DEMO_ACCOUNTS.find(
      (acc) => acc.username.toLowerCase() === typed && acc.password === password
    );

    if (demo) {
      session = { username: demo.username, role: demo.role, name: demo.name, avatar: demo.avatar };
    } else {
      const stored = await verifyLogin(username, password);
      if (stored) {
        session = {
          username: stored.username,
          role: stored.role,
          name: displayName(stored),
          avatar: initialsOf(stored),
        };
      }
    }

    if (!session) {
      return { ok: false, error: "Incorrect username or password." };
    }

    try {
      const removal = accountRemoval(session.username);
      if (removal) return { ok: false, error: 'Your gym account has been removed. Reason: ' + removal.reason };
    } catch { return { ok: false, error: 'Unable to verify account access. Please contact the gym.' }; }
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setUser(session);
    return { ok: true, role: session.role };
  }, []);

  const logout = useCallback(() => {
    sessionStorage.removeItem(SESSION_KEY);
    setUser(null);
  }, []);

  const value = useMemo(
    () => ({
      user,
      role: user?.role || null,
      isAuthenticated: !!user,
      login,
      logout,
    }),
    [user, login, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}

export const homeForRole = (role) =>
  role === "trainer" ? "/trainer/dashboard" : role === "admin" ? "/admin/dashboard" : "/member/dashboard";

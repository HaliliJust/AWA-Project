import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import * as store from '../services/memberStore';
import { getAccounts } from '../services/accountStore';
import { DEMO_ACCOUNTS } from '../data/demoAccounts';
import { membershipPlans } from '../data/mockData';
function validatePlan(plan) {
  if (!plan.name?.trim() || !plan.exerciseItems?.length) throw new Error('Add a plan name and at least one exercise.');
  for (const e of plan.exerciseItems) {
    if (!e.name?.trim() || !e.reps?.trim() || !Number.isInteger(Number(e.sets)) || Number(e.sets) < 1 || Number(e.sets) > 20 || !Number.isFinite(Number(e.rest)) || Number(e.rest) < 0 || Number(e.rest) > 1800) throw new Error('Each exercise needs a name, 1?20 sets, reps or duration, and a valid rest time.');
  }
}
const MemberContext = createContext(null);
export function MemberProvider({
  children
}) {
  const {
    user
  } = useAuth();
  const [database, setDatabase] = useState({
      members: {}
    }),
    [error, setError] = useState('');
  const username = user?.username?.toLowerCase();
  const refresh = useCallback(() => {
    try {
      const data = store.readDatabase();
      if (JSON.stringify(data) !== localStorage.getItem(store.STORAGE_KEY)) store.writeDatabase(data);
      setDatabase(data);
      setError('');
    } catch {
      setError('Your changes could not be loaded or saved. Browser storage may be full or unavailable.');
    }
  }, []);
  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 30000);
    window.addEventListener('storage', refresh);
    window.addEventListener('focus', refresh);
    return () => {
      clearInterval(id);
      window.removeEventListener('storage', refresh);
      window.removeEventListener('focus', refresh);
    };
  }, [refresh, username]);
  function transact(operation) {
    try {
      const next = store.readDatabase();
      if (next.removals[username]) throw new Error('This account has been removed from the gym.');
      operation(next);
      store.reconcile(next);
      store.writeDatabase(next);
      setDatabase(next);
      setError('');
      return true;
    } catch (e) {
      setError(e.message || 'Unable to save changes.');
      return false;
    }
  }
  function memberOperation(operation) {
    return transact(db => {
      if (user?.role !== 'member' || !db.members[username]) throw new Error('Sign in as a member to continue.');
      operation(db.members[username], db);
    });
  }
  function requireActive(s) {
    if (!store.membershipInfo(s.membership).active) throw new Error('Subscribe to access workout plans.');
  }
  function checkConflict(db, slot, member, except) {
    const start = new Date(`${slot.date}T${slot.time}`).getTime(),
      end = start + parseFloat(slot.duration) * 60000;
    Object.entries(db.members).forEach(([key, s]) => s.workoutSchedule.forEach(other => {
      if (other.id === except || !['Scheduled', 'Proposed'].includes(other.status)) return;
      const t = new Date(`${other.date}T${other.time}`).getTime();
      if ((other.trainerId === slot.trainerId || key === member) && start < t + parseFloat(other.duration) * 60000 && end > t) throw new Error('This session overlaps an existing member or trainer booking. Choose another time.');
    }));
  }
  const raw = database.members[username] || store.defaultMemberState(user || undefined);
  const state = {
    ...raw,
    membership: store.membershipInfo(raw.membership)
  };
  const notifications = user?.role === 'member' ? state.notifications : user?.role === 'trainer' ? database.trainerNotifications?.[username] || [] : [];
  function notificationOperation(operation) {
    return transact(db => {
      if (user?.role === 'member') operation(db.members[username].notifications);
      else if (user?.role === 'trainer') operation(db.trainerNotifications[username] ||= []);
      else throw new Error('Sign in to manage notifications.');
    });
  }
  function notifyTrainer(db, trainerId, notification) {
    const notifications = db.trainerNotifications[trainerId.toLowerCase()] ||= [];
    store.notify({ notifications }, { ...notification, link: '/trainer/schedule' });
  }
  const value = {
    state,
    database,
    error,
    refresh,
    trainers: store.activeTrainers(),
    notifications,
    unreadCount: notifications.filter(n => !n.read).length,
    removeGymAccount: (targetUsername, reason) => transact(db => {
      if (user?.role !== 'admin') throw new Error('Only an admin can remove gym accounts.');
      const key = String(targetUsername).toLowerCase();
      const account = [...DEMO_ACCOUNTS, ...getAccounts()].find(a => a.username.toLowerCase() === key);
      if (!account || !['member', 'trainer'].includes(account.role)) throw new Error('Choose a member or trainer account.');
      if (db.removals[key]) throw new Error('This account has already been removed.');
      const explanation = String(reason || '').trim();
      if (!explanation || explanation.length > 1000) throw new Error('Enter a removal reason of 1 to 1000 characters.');
      db.removals[key] = { username: key, role: account.role, name: db.members[key]?.profile.name || account.name || [account.firstName, account.lastName].filter(Boolean).join(' '), reason: explanation, removedAt: new Date().toISOString(), removedBy: username };
      Object.entries(db.members).forEach(([memberId, member]) => {
        const affected = item => memberId === key || item.trainerId?.toLowerCase() === key;
        const changed = new Set();
        member.workoutRequests.forEach(r => {
          if (affected(r) && ['Pending', 'Proposed'].includes(r.status)) { r.status = 'Cancelled'; changed.add(r.trainerId); }
        });
        member.workoutSchedule.forEach(w => {
          if (affected(w) && ['Scheduled', 'Proposed'].includes(w.status) && (w.status === 'Proposed' || new Date(w.date + 'T' + w.time) > new Date())) {
            w.status = 'Cancelled'; w.cancellationReason = 'Account removed by administrator'; changed.add(w.trainerId);
            const request = member.workoutRequests.find(r => r.id === w.id);
            if (request) request.status = 'Cancelled';
          }
        });
        if (changed.size) {
          store.notify(member, { title: 'Training arrangements cancelled', subtitle: 'An account involved in your training was removed. Please contact the gym to arrange a new trainer or session.', link: '/member/workout-schedule' });
          changed.forEach(trainerId => { if (trainerId) notifyTrainer(db, trainerId, { title: 'Training arrangements cancelled', subtitle: member.profile.name + ': an account was removed by the gym administrator.' }); });
        }
      });
    }),
    updateProfile: patch => memberOperation(s => {
      if (!patch.avatar && !s.profile.avatar) throw new Error('A profile picture is required.');
      s.profile = {
        ...s.profile,
        ...patch
      };
    }),
    markRead: id => notificationOperation(notifications => {
      const n = notifications.find(n => n.id === id);
      if (n) n.read = true;
    }),
    markAllRead: () => notificationOperation(notifications => {
      notifications.forEach(n => {
        n.read = true;
      });
    }),
    savePersonalPlan: plan => memberOperation(s => {
      requireActive(s);
      validatePlan(plan);
      const existing = s.personalPlans.find(p => p.id === plan.id);
      if (existing) Object.assign(existing, plan);
      else s.personalPlans.push({ ...plan, id: plan.id || store.uid() });
    }),
    addWorkoutRequest: request => memberOperation((s, db) => {
      requireActive(s);
      if (!request.program?.trim()) throw new Error('Enter a workout name.');
      if (request.exerciseItems) validatePlan({ ...request, name: request.program });
      const previous = request.requestId ? s.workoutRequests.find(r => r.id === request.requestId) : null;
      if (request.requestId && (!previous || !['Pending', 'Denied'].includes(previous.status))) throw new Error('Only pending or denied requests can be edited.');
      const trainer = store.activeTrainers().find(t => t.username === request.trainerId);
      if (!trainer) throw new Error('Choose an active trainer.');
      store.validateSlot(request.date, request.time, request.duration);
      checkConflict(db, request, username);
      if (s.workoutRequests.some(r => r.id !== previous?.id && r.status === 'Pending' && r.date === request.date && r.time === request.time)) throw new Error('You already have a request at this time.');
      const nextRequest = {
        ...request,
        trainer: trainer.name,
        id: previous?.id || store.uid(),
        status: 'Pending',
        submittedAt: new Date().toISOString()
      };
      if (previous) {
        s.workoutSchedule = s.workoutSchedule.filter(w => w.id !== previous.id);
        if (previous.trainerId !== trainer.username) notifyTrainer(db, previous.trainerId, { title: 'Workout request reassigned', subtitle: s.profile.name + ': ' + previous.program });
        Object.assign(previous, nextRequest);
      } else s.workoutRequests.push(nextRequest);
      notifyTrainer(db, trainer.username, { type: 'workout_request', title: previous ? 'Workout request updated' : 'New workout request', subtitle: s.profile.name + ': ' + request.program });
      store.notify(s, { title: 'Workout request sent', subtitle: request.program + ' is awaiting ' + trainer.name + "'s review.", link: '/member/workout-schedule' });
    }),
    respond: (memberId, requestId, status, alternative = {}) => transact(db => {
      const s = db.members[memberId],
        r = s?.workoutRequests.find(r => r.id === requestId);
      if (user?.role !== 'trainer' || !r || r.trainerId !== user.username || r.status !== 'Pending') throw new Error('This request is no longer pending or belongs to another trainer.');
      if (!['Accepted', 'Denied', 'Proposed'].includes(status)) throw new Error('Invalid response.');
      if (status !== 'Denied') {
        requireActive(s);
        if (!store.activeTrainers().some(t => t.username === user.username)) throw new Error('Your trainer account is inactive.');
        const slot = {
          ...r,
          ...(status === 'Proposed' ? alternative : {})
        };
        if (slot.exerciseItems) validatePlan({ ...slot, name: slot.program });
        store.validateSlot(slot.date, slot.time, slot.duration);
        checkConflict(db, slot, memberId);
        s.workoutSchedule.push({
          ...slot,
          id: r.id,
          status: status === 'Accepted' ? 'Scheduled' : 'Proposed'
        });
        Object.assign(r, slot);
      }
      r.status = status;
      notifyTrainer(db, r.trainerId, { type: 'trainer_response', title: status === 'Proposed' ? 'Suggestion sent to member' : 'Workout request ' + status.toLowerCase(), subtitle: s.profile.name + ': ' + r.program });
      store.notify(s, {
        type: 'trainer_response',
        title: `Workout request ${status.toLowerCase()}`,
        subtitle: `${r.trainer}: ${r.program} · ${r.date} at ${r.time}`,
        link: '/member/workout-schedule'
      });
    }),
    updateWorkoutScheduleStatus: (id, status) => memberOperation((s, db) => {
      requireActive(s);
      const slot = s.workoutSchedule.find(w => w.id === id);
      if (!slot) throw new Error('Session not found.');
      if (slot.status === 'Proposed' && ['Scheduled', 'Cancelled'].includes(status)) {
        if (status === 'Scheduled') {
          store.validateSlot(slot.date, slot.time, slot.duration);
          checkConflict(db, slot, username, id);
        }
        const req = s.workoutRequests.find(r => r.id === id);
        if (req) req.status = status === 'Scheduled' ? 'Accepted' : 'Denied';
        const title = status === 'Scheduled' ? 'Workout suggestion accepted' : 'Workout suggestion declined';
        notifyTrainer(db, slot.trainerId, { type: 'member_response', title, subtitle: s.profile.name + ': ' + slot.program });
        store.notify(s, { title, subtitle: slot.program, link: '/member/workout-schedule' });
      } else if (!(['Scheduled', 'Missed'].includes(slot.status) && ['Completed', 'Cancelled'].includes(status) && new Date(`${slot.date}T${slot.time}`) <= new Date())) throw new Error('This session cannot be updated yet.');
      slot.status = status;
      if (status === 'Completed' && !s.attendanceHistory.some(a => a.id === id)) s.attendanceHistory.unshift({
        id,
        date: slot.date,
        timeIn: slot.time,
        timeOut: new Date(new Date(`${slot.date}T${slot.time}`).getTime() + parseFloat(slot.duration) * 60000).toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit'
        }),
        duration: slot.duration
      });
    }),
    renew: (planId, method, usePoints) => memberOperation(s => {
      const plan = membershipPlans.find(p => p.id === planId);
      if (!plan || !['GCash', 'Bank Transfer', 'Cash at Front Desk'].includes(method)) throw new Error('Choose a valid plan and payment method.');
      const price = Number(plan.price.replace(/[^0-9]/g, '')),
        discount = usePoints ? Math.min(s.membership.points, price) : 0;
      const info = store.membershipInfo(s.membership);
      const base = info.active ? new Date(s.membership.expiryDate) : new Date();
      const day = base.getDate();
      base.setDate(1);
      base.setMonth(base.getMonth() + (plan.name.includes('Annual') ? 12 : 1));
      base.setDate(Math.min(day, new Date(base.getFullYear(), base.getMonth() + 1, 0).getDate()));
      s.membership = {
        ...s.membership,
        plan: plan.name,
        status: 'Active',
        expiryDate: store.localDate(base),
        nextPayment: store.localDate(base),
        paymentStatus: 'Paid',
        points: s.membership.points - discount
      };
      s.payments.unshift({
        id: store.uid(),
        date: store.localDate(),
        desc: `${plan.name} renewal`,
        amount: price - discount,
        discount,
        method,
        status: 'Paid'
      });
      store.notify(s, {
        title: 'Membership renewed',
        subtitle: `${plan.name} · Valid through ${s.membership.expiryDate}`,
        link: '/member/membership'
      });
    }),
    redeem: rewardId => memberOperation(s => {
      const reward = store.REWARDS.find(r => r.id === rewardId);
      if (!reward || s.membership.points < reward.points) throw new Error('You do not have enough points for this reward.');
      s.membership.points -= reward.points;
      s.rewards.unshift({
        ...reward,
        id: store.uid(),
        redeemedAt: store.localDate()
      });
    })
  };
  if (user?.role === "member" && !database.members[username]) return <p role="status">{error || "Loading your membership..."}</p>;
  return <MemberContext.Provider value={value}>{children}</MemberContext.Provider>;
}
export function useMember() {
  const value = useContext(MemberContext);
  if (!value) throw new Error('useMember must be used within a MemberProvider');
  return value;
}

import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import { Simulate } from 'react-dom/test-utils';
import { MemoryRouter } from 'react-router-dom';
import App from './App';
import { STORAGE_KEY, defaultMemberState, localDate } from './services/memberStore';
jest.mock('./components/MeasurementMannequin', () => () => <div>Measurement preview</div>);
jest.mock('./components/BodyType3D', () => () => <div>3D preview</div>);
let root, container;
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  localStorage.clear(); sessionStorage.clear();
  const state = defaultMemberState();
  const expiry = new Date(); expiry.setDate(expiry.getDate() + 30);
  state.membership.expiryDate = localDate(expiry);
  state.profile.avatar = 'data:image/png;base64,test';
  localStorage.setItem(STORAGE_KEY, JSON.stringify({members: {member001: state}}));
  container = document.createElement('div'); document.body.append(container); root = createRoot(container);
});
afterEach(() => { act(() => root.unmount()); container.remove(); });
function open(path, role = 'member') {
  sessionStorage.setItem('smartfit.session', JSON.stringify({username: role === 'member' ? 'member001' : role === 'trainer' ? 'trainer001' : 'admin', role, name: 'Test User'}));
  act(() => root.render(<MemoryRouter initialEntries={[path]} future={{v7_startTransition: true, v7_relativeSplatPath: true}}><App/></MemoryRouter>));
}
test.each([
 ['/member/dashboard','member','Weekly Activity'],
 ['/member/profile','member','Digital Membership Card'],
 ['/member/membership','member','Days Left'],
 ['/member/renew','member','Select Plan'],
 ['/member/workout-plans','member','Create personal plan'],
 ['/member/workout-schedule','member','Workout Requests'],
 ['/member/attendance','member','Attendance History'],
 ['/trainer/dashboard','trainer','No clients yet'],
 ['/trainer/schedule','trainer','Training Schedule'],
 ['/admin/dashboard','admin','System Overview'],
])('renders %s with the shared header', (path, role, expected) => {
 open(path, role);
 expect(container.textContent).toContain(expected);
 expect(container.querySelector('[aria-label="Notifications, 0 unread"]')).not.toBeNull();
});
test('profile submits named fields and updates the digital card', () => {
 open('/member/profile');
 const input = container.querySelector('input[name="name"]'); input.value = 'New Member Name';
 act(() => container.querySelector('form').dispatchEvent(new Event('submit', {bubbles: true, cancelable: true})));
 const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
 expect(saved.members.member001.profile.name).toBe('New Member Name');
 expect(container.textContent).toContain('Profile, body measurements and 3D preview saved.');
 expect(container.textContent.match(/New Member Name/g).length).toBeGreaterThan(1);
});

test.each(['/trainer/dashboard', '/trainer/members', '/trainer/progress', '/trainer/programs', '/trainer/view-programs', '/trainer/update-plans', '/trainer/history'])(
  '%s shows no mock clients or statistics without confirmed workouts', path => {
    open(path, 'trainer');
    expect(container.textContent).toContain('No clients yet');
    expect(container.textContent).not.toContain('Justine Halili');
    expect(container.textContent).not.toContain('Miguel Santos');
    expect(container.querySelector('.stat-card')).toBeNull();
    expect(container.querySelector('progress')).toBeNull();
  }
);

test('View reveals the saved client profile and body type', () => {
  const db = JSON.parse(localStorage.getItem(STORAGE_KEY));
  const member = db.members.member001;
  member.profile.bodyType = 'Ectomorph';
  member.profile.fitnessGoal = 'Muscle Gain';
  member.workoutSchedule = [{id: 'confirmed', trainerId: 'trainer001', program: 'Strength', date: localDate(), time: '23:00', duration: 60, status: 'Scheduled'}];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  open('/trainer/members', 'trainer');
  expect(container.querySelector('#client-details')).toBeNull();
  act(() => container.querySelector('button[aria-label="View Justine Halili"]').click());
  const details = container.querySelector('#client-details');
  expect(details.textContent).toContain('Ectomorph');
  expect(details.textContent).toContain('Muscle Gain');
  expect(details.textContent).toContain('165 cm');
  expect(details.textContent).toContain('58 kg');
  expect(document.activeElement).toBe(details);
});

test('expired members with saved workouts do not appear as active clients', () => {
  const db = JSON.parse(localStorage.getItem(STORAGE_KEY));
  db.members.member001.membership.expiryDate = '2000-01-01';
  db.members.member001.workoutSchedule = [{id: 'old', trainerId: 'trainer001', program: 'Strength', date: '2000-01-01', time: '10:00', duration: 60, status: 'Completed'}];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  open('/trainer/members', 'trainer');
  expect(container.textContent).toContain('No clients yet');
  expect(container.textContent).not.toContain('Justine Halili');
});

test('workout suggestions open the chosen plan booking form', () => {
  open('/member/workout-schedule');
  expect(container.textContent).toContain('Suggested Workout Plans');
  const link = container.querySelector('a[href="/member/workout-plans?plan=WP-001"]');
  act(() => link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, button: 0 })));
  expect(container.querySelector('[aria-label="Workout plan editor"] input').value).toBe('Lower Body Strength');
  expect(container.querySelector('select[name="trainer"]')).not.toBeNull();
});

test('inactive members can see suggestions but must renew to choose one', () => {
  const db = JSON.parse(localStorage.getItem(STORAGE_KEY));
  db.members.member001.membership.expiryDate = '2000-01-01';
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  open('/member/workout-schedule');
  expect(container.textContent).toContain('Suggested Workout Plans');
  expect(container.querySelector('.suggestion-card a').getAttribute('href')).toBe('/member/renew');
});

test('trainer profile uses the photo control and omits Quick Notes', () => {
  open('/trainer/information', 'trainer');
  expect(container.querySelector('.photo-upload')).not.toBeNull();
  expect(container.textContent).not.toContain('Quick Notes');
  const input = container.querySelector('input[type="file"]');
  Object.defineProperty(input, 'files', { value: [new File(['invalid'], 'document.txt', { type: 'text/plain' })] });
  act(() => input.dispatchEvent(new Event('change', {bubbles: true})));
  expect(container.querySelector('[role="alert"]').textContent).toContain('Choose a JPG, PNG or WebP image under 2 MB.');
});

test('customized template saves as a reusable personal plan without a trainer booking', () => {
  open('/member/workout-plans?plan=WP-001');
  const editor = container.querySelector('[aria-label="Workout plan editor"]');
  const save = [...editor.querySelectorAll('button')].find(b => b.textContent === 'Save personal plan');
  const event = new Event('submit', { bubbles: true, cancelable: true });
  Object.defineProperty(event, 'submitter', { value: save });
  act(() => editor.querySelector('form').dispatchEvent(event));
  const member = JSON.parse(localStorage.getItem(STORAGE_KEY)).members.member001;
  expect(member.personalPlans).toHaveLength(1);
  expect(member.personalPlans[0].exerciseItems).toHaveLength(4);
  expect(member.workoutRequests).toHaveLength(0);
  expect(container.textContent).toContain('Personal plan saved.');
});

test('admin roster and goals show only registered members', () => {
  open('/admin/members', 'admin');
  expect(container.querySelectorAll('tbody tr')).toHaveLength(1);
  expect(container.textContent).toContain('Justine Halili');
  expect(container.textContent).not.toContain('Miguel Santos');
});

test('admin can view member information and cancel a removal without changing the account', () => {
  open('/admin/members', 'admin');
  const view = [...container.querySelectorAll('button')].find(b => b.textContent === 'View');
  act(() => view.click());
  const panel = container.querySelector('#admin-account-details');
  expect(panel.textContent).toContain('justine.halili@email.com');
  expect(panel.textContent).toContain('Emergency Contact');
  expect(document.activeElement).toBe(panel);
  act(() => [...panel.querySelectorAll('button')].find(b => b.textContent === 'Remove member').click());
  expect([...panel.querySelectorAll('button')].find(b => b.textContent === 'Confirm removal').disabled).toBe(true);
  act(() => [...panel.querySelectorAll('button')].find(b => b.textContent === 'Cancel').click());
  expect(JSON.parse(localStorage.getItem(STORAGE_KEY)).removals.member001).toBeUndefined();
});

test('trainer details use saved professional profile and omit credentials', () => {
  localStorage.setItem('smartfit.trainer-profile.trainer001', JSON.stringify({name: 'Updated Coach', email: 'coach@example.com', phone: '09123456789', specialty: 'Strength', certification: 'Certified coach', experience: '5 years'}));
  open('/admin/trainers', 'admin');
  act(() => [...container.querySelectorAll('button')].find(b => b.textContent === 'View').click());
  const panel = container.querySelector('#admin-account-details');
  expect(panel.textContent).toContain('Updated Coach');
  expect(panel.textContent).toContain('coach@example.com');
  expect(panel.textContent).toContain('Certified coach');
  expect(panel.textContent).not.toContain('trainer123');
});

test('admin confirms a removal with a reason and sees it in removal history', () => {
  open('/admin/members', 'admin');
  act(() => [...container.querySelectorAll('button')].find(b => b.textContent === 'Remove').click());
  const input = container.querySelector('#removal-reason');
  act(() => Simulate.change(input, { target: { value: 'Repeated gym rule violations' } }));
  const panel = container.querySelector('#admin-account-details');
  act(() => panel.querySelector('form').dispatchEvent(new Event('submit', {bubbles: true, cancelable: true})));
  const db = JSON.parse(localStorage.getItem(STORAGE_KEY));
  expect(db.removals.member001.reason).toBe('Repeated gym rule violations');
  expect(container.textContent).toContain('Justine Halili has been removed from the gym.');
  expect(container.textContent).toContain('Removal history');
  expect(container.querySelector('tbody')?.textContent || '').not.toContain('Justine Halili');
});

// ---------------------------------------------------------------------------
// Fixed demo accounts (always available, cannot be edited or deleted).
// Accounts created through the Create Account form live in localStorage —
// see services/accountStore.js.
// ---------------------------------------------------------------------------
export const DEMO_ACCOUNTS = [
  {
    username: "member001",
    password: "member123",
    role: "member",
    name: "Justine Halili",
    avatar: "JH",
  },
  {
    username: "trainer001",
    password: "trainer123",
    role: "trainer",
    name: "Coach Rafael Ignacio",
    avatar: "RI",
  },
  {
    username: "admin",
    password: "root",
    role: "admin",
    name: "System Admin",
    avatar: "AD",
  },
];

// Static placeholder data only — no backend / API calls are wired up yet.
// Every page in this project reads from here so the UI has something
// realistic to display while the actual functions are still being built.

export const currentMember = {
  name: "Justine Halili",
  email: "justine.halili@email.com",
  memberId: "MBR-00214",
  plan: "Premium Monthly",
  status: "Active",
  joinDate: "Jan 14, 2025",
  expiryDate: "Sep 14, 2026",
  daysLeft: 19,
  height: "165 cm",
  weight: "58 kg",
  bmi: 21.3,
  bodyType: "Mesocorph",
  avatar: "JH",
  bloodType: "O+",
  emergencyContact: "0917 998 2211",
};

export const currentTrainer = {
  name: "Coach Rafael Ignacio",
  email: "rafael.ignacio@smartfit.gym",
  trainerId: "TRN-00042",
  specialty: "Strength & Conditioning",
  certification: "NASM-CPT, CSCS",
  experience: "6 years",
  phone: "0917 234 5678",
  joinDate: "Mar 02, 2022",
  status: "Active",
  avatar: "RI",
  qrValue: "SMARTFIT-TRAINER-TRN-00042",
  // Trainer's own gym membership / staff perk — mirrors the member side so
  // trainers can also avail or renew a membership from their dashboard.
  membershipPlan: "Staff Premium",
  membershipStatus: "Active",
  membershipExpiry: "Nov 02, 2026",
  membershipDaysLeft: 63,
};

export const membershipPlans = [
  { id: 1, name: "Basic Monthly", price: "₱999 / mo", perks: ["Gym floor access", "Locker use"] },
  { id: 2, name: "Premium Monthly", price: "₱1,799 / mo", perks: ["Gym floor access", "Group classes", "1 trainer session / mo"] },
  { id: 3, name: "Premium Annual", price: "₱17,999 / yr", perks: ["All Premium perks", "2 months free", "Priority booking"] },
];

// Staff plans available to trainers who also want their own gym membership.
export const staffMembershipPlans = [
  { id: 1, name: "Staff Basic", price: "₱0 / mo", perks: ["Gym floor access (off-hours)", "Locker use"] },
  { id: 2, name: "Staff Premium", price: "₱499 / mo", perks: ["Gym floor access (any hour)", "Group classes", "Guest pass / mo"] },
];

export const paymentHistory = [
  { id: "PMT-1042", date: "Aug 14, 2026", desc: "Premium Monthly Renewal", amount: "₱1,799", status: "Paid" },
  { id: "PMT-0988", date: "Jul 14, 2026", desc: "Premium Monthly Renewal", amount: "₱1,799", status: "Paid" },
  { id: "PMT-0931", date: "Jun 14, 2026", desc: "Premium Monthly Renewal", amount: "₱1,799", status: "Paid" },
  { id: "PMT-0877", date: "May 14, 2026", desc: "Premium Monthly Renewal", amount: "₱1,799", status: "Overdue" },
];

export const attendanceHistory = [
  { date: "Aug 25, 2026", timeIn: "6:12 AM", timeOut: "7:40 AM", duration: "1h 28m" },
  { date: "Aug 23, 2026", timeIn: "6:05 AM", timeOut: "7:22 AM", duration: "1h 17m" },
  { date: "Aug 21, 2026", timeIn: "5:58 AM", timeOut: "7:35 AM", duration: "1h 37m" },
  { date: "Aug 19, 2026", timeIn: "6:20 AM", timeOut: "7:10 AM", duration: "0h 50m" },
];

export const weeklyActivity = [40, 62, 55, 80, 46, 70, 90];
export const weeklyLabels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export const assignedMembers = [
  { id: "MBR-00214", name: "Justine Halili", plan: "Premium", goal: "Weight Loss", progress: 68, lastSession: "Aug 24, 2026", weight: "58 kg", bmi: 21.3, measurements: "Waist 27in · Chest 33in · Hips 36in", strengthImprovement: "+9% squat 1RM" },
  { id: "MBR-00198", name: "Miguel Santos", plan: "Basic", goal: "Muscle Gain", progress: 42, lastSession: "Aug 23, 2026", weight: "71 kg", bmi: 24.6, measurements: "Waist 33in · Chest 39in · Hips 38in", strengthImprovement: "+14% bench press" },
  { id: "MBR-00176", name: "Ana Dela Cruz", plan: "Premium", goal: "Endurance", progress: 81, lastSession: "Aug 22, 2026", weight: "54 kg", bmi: 20.1, measurements: "Waist 25in · Chest 32in · Hips 35in", strengthImprovement: "+18% 5K run pace" },
  { id: "MBR-00152", name: "Carlo Reyes", plan: "Basic", goal: "Strength", progress: 55, lastSession: "Aug 20, 2026", weight: "80 kg", bmi: 26.4, measurements: "Waist 36in · Chest 41in · Hips 40in", strengthImprovement: "+11% deadlift 1RM" },
];

export const workoutPrograms = [
  {
    id: "WP-001",
    goal: "Strength",
    activityLevel: "Moderately active",
    type: "Resistance training",
    name: "Lower Body Strength",
    member: "Justine Halili",
    level: "Intermediate",
    duration: "6 weeks",
    status: "Active",
    exercises: "Back Squat, Romanian Deadlift, Walking Lunges, Leg Press",
    sets: 4,
    reps: 10,
    restTime: "60 sec",
    schedule: "Mon, Wed, Fri · 6:00 AM",
  },
  {
    id: "WP-002",
    goal: "Muscle Gain",
    activityLevel: "Lightly active",
    type: "Hypertrophy training",
    name: "Lean Bulk Split",
    member: "Miguel Santos",
    level: "Beginner",
    duration: "8 weeks",
    status: "Active",
    exercises: "Bench Press, Lat Pulldown, Shoulder Press, Bicep Curl",
    sets: 3,
    reps: 12,
    restTime: "45 sec",
    schedule: "Tue, Thu, Sat · 8:00 AM",
  },
  {
    id: "WP-003",
    goal: "Endurance",
    activityLevel: "Very active",
    type: "Cardio and conditioning",
    name: "Endurance Builder",
    member: "Ana Dela Cruz",
    level: "Advanced",
    duration: "4 weeks",
    status: "Completed",
    exercises: "Interval Running, Rowing, Jump Rope, Mountain Climbers",
    sets: 5,
    reps: 15,
    restTime: "30 sec",
    schedule: "Mon–Fri · 2:00 PM",
  },
];

export const workoutHistory = [
  {
    id: "WP-000",
    name: "Full Body Foundations",
    member: "Carlo Reyes",
    completedOn: "Jul 30, 2026",
    result: "Goal reached",
    exercises: "Bodyweight Squats, Push-ups, Inverted Rows, Plank Hold",
    sets: 3,
    reps: 12,
    restTime: "45 sec",
    notes: "Client hit all strength targets and is ready to progress to a split routine.",
  },
  {
    id: "WP--01",
    name: "Core & Mobility",
    member: "Justine Halili",
    completedOn: "Jul 12, 2026",
    result: "Goal reached",
    exercises: "Dead Bug, Bird Dog, Hip Flexor Stretch, Cat-Cow",
    sets: 3,
    reps: 15,
    restTime: "30 sec",
    notes: "Noticeable mobility gains in hips and lower back; no more soreness reported.",
  },
  {
    id: "WP--02",
    name: "Beginner Cardio Base",
    member: "Ana Dela Cruz",
    completedOn: "Jun 02, 2026",
    result: "Discontinued",
    exercises: "Brisk Walking, Stationary Bike, Light Jogging",
    sets: 1,
    reps: 1,
    restTime: "N/A",
    notes: "Discontinued early due to scheduling conflicts; recommend restarting at week 1.",
  },
];

export const trainerSchedule = [
  { time: "6:00 AM", member: "Justine Halili", type: "Personal Training" },
  { time: "8:00 AM", member: "Miguel Santos", type: "Strength Assessment" },
  { time: "10:30 AM", member: "Group Class", type: "HIIT Circuit" },
  { time: "2:00 PM", member: "Ana Dela Cruz", type: "Personal Training" },
  { time: "4:30 PM", member: "Carlo Reyes", type: "Follow-up Check" },
];

export const allPayments = [
  { id: "PMT-1042", member: "Justine Halili", date: "Aug 14, 2026", amount: "₱1,799", method: "GCash", status: "Verified" },
  { id: "PMT-1041", member: "Miguel Santos", date: "Aug 13, 2026", amount: "₱999", method: "Cash", status: "Pending" },
  { id: "PMT-1040", member: "Ana Dela Cruz", date: "Aug 12, 2026", amount: "₱17,999", method: "Bank Transfer", status: "Verified" },
  { id: "PMT-1039", member: "Carlo Reyes", date: "Aug 10, 2026", amount: "₱999", method: "Cash", status: "Overdue" },
  { id: "PMT-1038", member: "Justine Halili", date: "Jul 14, 2026", amount: "₱1,799", method: "GCash", status: "Verified" },
];

export const paymentSummary = {
  collected: "₱48,320",
  pending: "₱2,798",
  overdue: "₱999",
  members: 4,
};

// ---------------------------------------------------------------------------
// Admin-only mock data — system-wide monitoring across members, trainers,
// goals, and payments. Not connected to a real database yet.
// ---------------------------------------------------------------------------

export const currentAdmin = {
  name: "System Admin",
  email: "admin@smartfit.gym",
  avatar: "AD",
};

export const systemOverview = {
  totalMembers: 214,
  totalTrainers: 12,
  activeMemberships: 186,
  expiredMemberships: 28,
  totalPayments: "₱482,930",
  pendingPayments: "₱18,450",
  avgAttendanceRate: 74,
  popularGoal: "Weight Loss",
};

export const allMembersAdmin = [
  { id: "MBR-00214", name: "Justine Halili", plan: "Premium", goal: "Weight Loss", status: "Active", attendance: 82, trainer: "Coach Rafael Ignacio" },
  { id: "MBR-00198", name: "Miguel Santos", plan: "Basic", goal: "Muscle Gain", status: "Active", attendance: 61, trainer: "Coach Rafael Ignacio" },
  { id: "MBR-00176", name: "Ana Dela Cruz", plan: "Premium", goal: "Endurance", status: "Active", attendance: 90, trainer: "Coach Bea Lim" },
  { id: "MBR-00152", name: "Carlo Reyes", plan: "Basic", goal: "Strength", status: "Expired", attendance: 34, trainer: "Coach Bea Lim" },
  { id: "MBR-00133", name: "Trisha Gomez", plan: "Premium", goal: "General Fitness", status: "Active", attendance: 77, trainer: "Coach Rafael Ignacio" },
  { id: "MBR-00109", name: "Noel Bautista", plan: "Basic", goal: "Weight Loss", status: "Pending", attendance: 12, trainer: "Unassigned" },
];

export const allTrainersAdmin = [
  { id: "TRN-00042", name: "Coach Rafael Ignacio", specialty: "Strength & Conditioning", assigned: 3, sessionsToday: 5, status: "Active" },
  { id: "TRN-00051", name: "Coach Bea Lim", specialty: "Endurance & HIIT", assigned: 2, sessionsToday: 3, status: "Active" },
  { id: "TRN-00063", name: "Coach Miko Torres", specialty: "Powerlifting", assigned: 4, sessionsToday: 2, status: "Active" },
  { id: "TRN-00070", name: "Coach Elaine Cruz", specialty: "Mobility & Rehab", assigned: 1, sessionsToday: 0, status: "On Leave" },
];

export const goalStats = [
  { goal: "Weight Loss", count: 78 },
  { goal: "Muscle Gain", count: 54 },
  { goal: "Endurance", count: 33 },
  { goal: "Strength", count: 29 },
  { goal: "General Fitness", count: 20 },
];

export const goalValues = goalStats.map((g) => g.count);
export const goalLabels = goalStats.map((g) => g.goal.split(" ")[0]);

export const trainerPayouts = [
  { id: "PYT-3021", trainer: "Coach Rafael Ignacio", date: "Aug 15, 2026", amount: "₱18,000", status: "Paid" },
  { id: "PYT-3020", trainer: "Coach Bea Lim", date: "Aug 15, 2026", amount: "₱15,500", status: "Paid" },
  { id: "PYT-3019", trainer: "Coach Miko Torres", date: "Aug 15, 2026", amount: "₱16,200", status: "Pending" },
  { id: "PYT-3018", trainer: "Coach Elaine Cruz", date: "Jul 15, 2026", amount: "₱9,800", status: "Paid" },
];

// Simple Paid / Unpaid / Pending roster the admin uses to monitor who still
// owes dues (members) or is due for payout (trainers). UI only for now.
export const memberPaymentStatus = [
  { id: "MBR-00214", name: "Justine Halili", plan: "Premium", amount: "₱1,799", dueDate: "Sep 14, 2026", status: "Paid" },
  { id: "MBR-00198", name: "Miguel Santos", plan: "Basic", amount: "₱999", dueDate: "Sep 02, 2026", status: "Pending" },
  { id: "MBR-00176", name: "Ana Dela Cruz", plan: "Premium", amount: "₱17,999", dueDate: "Dec 20, 2026", status: "Paid" },
  { id: "MBR-00152", name: "Carlo Reyes", plan: "Basic", amount: "₱999", dueDate: "Aug 10, 2026", status: "Unpaid" },
  { id: "MBR-00133", name: "Trisha Gomez", plan: "Premium", amount: "₱1,799", dueDate: "Sep 05, 2026", status: "Paid" },
  { id: "MBR-00109", name: "Noel Bautista", plan: "Basic", amount: "₱999", dueDate: "Aug 28, 2026", status: "Unpaid" },
];

export const trainerPaymentStatus = [
  { id: "TRN-00042", name: "Coach Rafael Ignacio", role: "Strength & Conditioning", amount: "₱18,000", dueDate: "Aug 15, 2026", status: "Paid" },
  { id: "TRN-00051", name: "Coach Bea Lim", role: "Endurance & HIIT", amount: "₱15,500", dueDate: "Aug 15, 2026", status: "Paid" },
  { id: "TRN-00063", name: "Coach Miko Torres", role: "Powerlifting", amount: "₱16,200", dueDate: "Aug 15, 2026", status: "Pending" },
  { id: "TRN-00070", name: "Coach Elaine Cruz", role: "Mobility & Rehab", amount: "₱9,800", dueDate: "Jul 15, 2026", status: "Unpaid" },
];

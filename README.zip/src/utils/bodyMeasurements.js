// Converts real, literal body measurements (cm) into the abstract "shape"
// scale that BodySilhouette / BodyType3D expect (see BodySilhouette.jsx —
// that scale is deliberately exaggerated for a glanceable schematic picker,
// not a 1:1 anatomical scale). Ported over from the standalone 3D-mannequin
// prototype's slider-driven measurement panel, re-targeted at the gym
// system's existing (higher-fidelity) mannequin renderer instead of its
// original plain box/cylinder body.

// A reference set of "normal" adult measurements (cm) …
export const DEFAULT_MEASUREMENTS = {
  height: 170,
  chest: 90,
  waist: 75,
  hips: 95,
  shoulders: 45,
};

export const MEASUREMENT_RANGES = {
  height: { min: 145, max: 210, step: 1 },
  chest: { min: 70, max: 130, step: 1 },
  waist: { min: 55, max: 120, step: 1 },
  hips: { min: 75, max: 135, step: 1 },
  shoulders: { min: 32, max: 58, step: 1 },
};

// … paired with the shape values BodyType3D renders for a mid-mesomorph
// build at that same reference size. Each slider scales its shape dimension
// proportionally around this anchor point.
const REFERENCE_SHAPE = { shoulder: 54, chest: 48, waist: 31.5, hip: 34, thigh: 17, armThigh: 22.5 };

function ratio(value, reference) {
  return reference > 0 ? value / reference : 1;
}

/**
 * @param {{height:number, chest:number, waist:number, hips:number, shoulders:number}} cm
 * @returns {{ shape: object, heightScale: number }}
 */
export function measurementsToShape(cm) {
  const m = { ...DEFAULT_MEASUREMENTS, ...cm };

  const chestRatio = ratio(m.chest, DEFAULT_MEASUREMENTS.chest);
  const waistRatio = ratio(m.waist, DEFAULT_MEASUREMENTS.waist);
  const hipRatio = ratio(m.hips, DEFAULT_MEASUREMENTS.hips);
  const shoulderRatio = ratio(m.shoulders, DEFAULT_MEASUREMENTS.shoulders);

  const shape = {
    shoulder: REFERENCE_SHAPE.shoulder * shoulderRatio,
    chest: REFERENCE_SHAPE.chest * chestRatio,
    waist: REFERENCE_SHAPE.waist * waistRatio,
    hip: REFERENCE_SHAPE.hip * hipRatio,
    // No direct sliders for thigh/upper-arm thickness — tie them to the
    // nearest limb's parent measurement so the figure still reads as
    // proportional.
    thigh: REFERENCE_SHAPE.thigh * hipRatio,
    armThigh: REFERENCE_SHAPE.armThigh * shoulderRatio,
  };

  const heightScale = ratio(m.height, DEFAULT_MEASUREMENTS.height);

  return { shape, heightScale };
}

// Estimates are a starting point; members can enter their actual measurements.
export function profileMeasurements(profile) {
  const height = parseFloat(profile.height) || 170;
  const weight = parseFloat(profile.weight) || 65;
  const build = { Ectomorph: 0.94, Mesomorph: 1, Endomorph: 1.07 }[profile.bodyType] || 1;
  const scale = Math.sqrt(weight / 65) * Math.sqrt(170 / height) * build;
  return Object.fromEntries(Object.entries(DEFAULT_MEASUREMENTS).map(([key, value]) => {
    const range = MEASUREMENT_RANGES[key];
    return [key, key === 'height' ? height : Math.round(Math.min(range.max, Math.max(range.min, value * scale)))];
  }));
}

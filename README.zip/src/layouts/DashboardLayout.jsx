import { Outlet, useLocation } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
import { useMember } from "../context/MemberContext";

const titles = {
  "/member/dashboard": ["Dashboard", "Your personal fitness overview"],
  "/member/profile": ["Update Profile", "Edit your personal information"],
  "/member/membership": ["Membership Status", "Track your current plan"],
  "/member/renew": ["Renew Membership", "Extend your membership before it expires"],
  "/member/workout-plans": ["Workout Plans", "Create, customize and submit your workout plans"],
  "/member/workout-schedule": ["Workout Schedule", "Your upcoming and today's workouts"],
  "/member/attendance": ["Attendance History", "Your gym check-in records"],

  "/trainer/dashboard": ["Daily Schedule", "Your appointments for today"],
  "/trainer/members": ["Assigned Members", "Members currently under your coaching"],
  "/trainer/programs": ["Workout Programs", "Design personalized workout plans"],
  "/trainer/update-plans": ["Update Workout Plans", "Modify programs already in progress"],
  "/trainer/schedule": ["Schedule Sessions", "Set training schedules for members"],
  "/trainer/progress": ["Progress Monitoring", "Track each member's fitness progress"],
  "/trainer/history": ["Workout History", "Previously assigned workout plans"],
  "/trainer/information": ["Trainer Information", "Your profile and digital ID card"],
  "/trainer/membership": ["Membership Status", "Track your staff membership plan"],
  "/trainer/renew": ["Renew Membership", "Avail or extend your staff membership"],

  "/admin/dashboard": ["System Overview", "Gym-wide performance at a glance"],
  "/admin/members": ["Manage Members", "All members, memberships, and goals"],
  "/admin/trainers": ["Manage Trainers", "All trainers, assignments, and schedules"],
  "/admin/goals": ["Fitness Goals", "System-wide goal distribution and trends"],
  "/admin/payments": ["Payments Overview", "Monitor who's paid, pending, or unpaid"],
};

function DashboardLayout({ role }) {
  const { error } = useMember();
  const { pathname } = useLocation();
  const [title, crumb] = titles[pathname] || ["Dashboard", ""];

  return (
    <div className="app-shell">
      <a className="skip-link" href="#main-content">Skip to content</a>
      <Sidebar role={role} />
      <div className="app-main">
        <Topbar title={title} crumb={crumb} />
        <main className="app-content" id="main-content" tabIndex={-1}>
          {error && <p className="save-error" role="alert">{error}</p>}
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export default DashboardLayout;

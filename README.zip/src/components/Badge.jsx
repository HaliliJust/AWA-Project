const toneByStatus = {
  active: "success",
  paid: "success",
  verified: "success",
  completed: "success",
  "goal reached": "success",
  pending: "warning",
  overdue: "danger",
  expired: "danger",
  discontinued: "danger",
  unpaid: "danger",
};

function Badge({ status, tone }) {
  const resolvedTone = tone || toneByStatus[String(status).toLowerCase()] || "neutral";
  return <span className={`badge badge-${resolvedTone}`}>{status}</span>;
}

export default Badge;

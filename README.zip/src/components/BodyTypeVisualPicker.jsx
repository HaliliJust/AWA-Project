import { AlertCircle, Check } from "lucide-react";
import BodySilhouette, { FEMININE_RANGES, MASCULINE_RANGES, lerpShape } from "./BodySilhouette";
import BodyType3D from "./BodyType3D";

const STYLE_RANGES = { feminine: FEMININE_RANGES, masculine: MASCULINE_RANGES };
const STYLE_TABS = [
  { value: "feminine", label: "Feminine" },
  { value: "masculine", label: "Masculine" },
];
const CATEGORY_ORDER = ["ectomorph", "mesomorph", "endomorph"];

function buildWord(build) {
  if (build < 30) return "Leaner";
  if (build > 70) return "Fuller";
  return "Balanced";
}

/**
 * Body type picker for the registration form:
 *  - Feminine / Masculine tabs choose which silhouette set is shown.
 *  - Three somatotype cards (ectomorph / mesomorph / endomorph) are the
 *    actual required selection.
 *  - Once a category is picked, a slider dials in a build anywhere between
 *    that category's leanest and fullest reference shape — the 2D icons and
 *    the 3D preview both update live as it moves.
 */
function BodyTypeVisualPicker({ id, style, onStyleChange, category, onCategoryChange, build, onBuildChange, error }) {
  const ranges = STYLE_RANGES[style];
  const activeRange = category ? ranges[category] : null;
  const t = build / 100;

  // The 3D/2D previews always show something, even before a category is
  // chosen — a neutral mid-mesomorph build — so nothing ever looks blank.
  const previewShape = activeRange
    ? lerpShape(activeRange.min, activeRange.max, t)
    : lerpShape(ranges.mesomorph.min, ranges.mesomorph.max, 0.5);

  return (
    <div className="authx-field authx-span-6">
      <span className="authx-label" id={`${id}-label`}>
        Body type
      </span>

      <div className="authx-bodystyle-tabs" role="tablist" aria-label="Body silhouette style">
        {STYLE_TABS.map((tab) => (
          <button
            key={tab.value}
            type="button"
            role="tab"
            aria-selected={style === tab.value}
            className={`authx-bodystyle-tab${style === tab.value ? " is-active" : ""}`}
            onClick={() => onStyleChange(tab.value)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="authx-body3d-wrap">
        <BodyType3D shape={previewShape} />
        <p className="authx-body3d-hint">Drag to rotate the preview</p>
      </div>

      <div
        id={id}
        className="authx-bodycat-list"
        role="radiogroup"
        aria-labelledby={`${id}-label`}
        aria-describedby={error ? `${id}-error` : undefined}
      >
        {CATEGORY_ORDER.map((key) => {
          const range = ranges[key];
          const iconShape = lerpShape(range.min, range.max, 0.5);
          const selected = category === key;
          return (
            <button
              key={key}
              type="button"
              role="radio"
              aria-checked={selected}
              className={`authx-bodycat${selected ? " is-selected" : ""}`}
              onClick={() => onCategoryChange(key)}
            >
              <BodySilhouette shape={iconShape} size={34} />
              <span className="authx-bodycat-text">
                <span className="authx-bodycat-title">{range.label}</span>
                <span className="authx-bodycat-desc">{range.description}</span>
              </span>
              {selected && (
                <span className="authx-body-check" aria-hidden="true">
                  <Check size={13} strokeWidth={3} />
                </span>
              )}
            </button>
          );
        })}
      </div>

      {category && (
        <div className="authx-bodyslider">
          <div className="authx-bodyslider-head">
            <label htmlFor={`${id}-build`} className="authx-bodyslider-label">
              Adjust build within {activeRange.label}
            </label>
            <span className="authx-bodyslider-value">{buildWord(build)}</span>
          </div>
          <input
            id={`${id}-build`}
            type="range"
            min={0}
            max={100}
            step={1}
            value={build}
            onChange={(e) => onBuildChange(Number(e.target.value))}
            className="authx-range"
            aria-describedby={`${id}-build-scale`}
            aria-valuetext={buildWord(build)}
          />
          <div id={`${id}-build-scale`} className="authx-bodyslider-scale">
            <span>Leaner</span>
            <span>Fuller</span>
          </div>
        </div>
      )}

      {error && (
        <p id={`${id}-error`} className="authx-error">
          <AlertCircle size={15} aria-hidden="true" />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}

export default BodyTypeVisualPicker;

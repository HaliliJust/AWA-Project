import { Check } from "lucide-react";

/**
 * Progress through the registration steps.
 * Each step has a number (or a check when done) plus a text label; the current
 * step is exposed with aria-current="step" and extra screen-reader text, so state
 * is never shown by color alone.
 */
function StepIndicator({ steps, current }) {
  return (
    <ol className="authx-steps" aria-label="Registration progress">
      {steps.map((s, i) => {
        const n = i + 1;
        const state = n < current ? "done" : n === current ? "current" : "todo";
        return (
          <li
            key={s}
            className={`authx-step authx-step--${state}`}
            aria-current={state === "current" ? "step" : undefined}
          >
            <span className="authx-step-bar" aria-hidden="true" />
            <span className="authx-step-label">
              {state === "done" ? <Check size={14} strokeWidth={3} aria-hidden="true" /> : <span aria-hidden="true">{n}</span>}
              <span>{s}</span>
              <span className="authx-sr">
                {state === "done" ? " (completed)" : state === "current" ? " (current step)" : ""}
              </span>
            </span>
          </li>
        );
      })}
    </ol>
  );
}

export default StepIndicator;

import { useRef, useState } from "react";
import { AlertCircle, RotateCcw, Upload } from "lucide-react";
import { fileToCompressedDataURL, MAX_UPLOAD_BYTES } from "../services/imageTools";

/**
 * One side (front or back) of a government ID upload.
 *  - `value` is a data URL (or "") ; `onChange(dataUrl)` fires once the image
 *    has been read and compressed.
 *  - Accepts photos from the camera or the gallery (accept="image/*").
 *  - `id` is the field's group id (used by the form to focus this field on
 *    error); the actual controls get their own sub-ids.
 */
function IdUploadField({ id, label, value, onChange, error, span = 3 }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [localError, setLocalError] = useState("");

  const btnId = `${id}-btn`;
  const fileId = `${id}-file`;

  async function handleFile(file) {
    setLocalError("");
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setLocalError("Please choose an image file (JPG or PNG).");
      return;
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      setLocalError("That image is too large. Please choose a file under 8MB.");
      return;
    }
    setBusy(true);
    try {
      const dataUrl = await fileToCompressedDataURL(file);
      onChange(dataUrl);
    } catch {
      setLocalError("We couldn't read that image. Please try another file.");
    } finally {
      setBusy(false);
    }
  }

  const shownError = error || localError;

  return (
    <div id={id} className={`authx-field authx-span-${span}`}>
      <label className="authx-label" htmlFor={btnId}>
        {label}
      </label>

      <input
        ref={inputRef}
        id={fileId}
        type="file"
        accept="image/*"
        tabIndex={-1}
        aria-hidden="true"
        className="authx-sr"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />

      {value ? (
        <div className={`authx-id-preview${shownError ? " has-error" : ""}`}>
          <img src={value} alt="" className="authx-id-thumb" />
          <button
            id={btnId}
            type="button"
            className="authx-id-replace"
            onClick={() => inputRef.current?.click()}
            disabled={busy}
            aria-describedby={shownError ? `${id}-error` : undefined}
          >
            <RotateCcw size={16} aria-hidden="true" />
            Replace photo
          </button>
        </div>
      ) : (
        <button
          id={btnId}
          type="button"
          className={`authx-id-drop${shownError ? " has-error" : ""}`}
          onClick={() => inputRef.current?.click()}
          disabled={busy}
          aria-describedby={shownError ? `${id}-error` : undefined}
        >
          <Upload size={20} aria-hidden="true" />
          <span>{busy ? "Processing…" : "Upload photo"}</span>
          <span className="authx-id-drop-hint">JPG or PNG, up to 8MB</span>
        </button>
      )}

      {shownError && (
        <p id={`${id}-error`} className="authx-error">
          <AlertCircle size={15} aria-hidden="true" />
          <span>{shownError}</span>
        </p>
      )}
    </div>
  );
}

export default IdUploadField;

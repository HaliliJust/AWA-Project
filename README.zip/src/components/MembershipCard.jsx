import Badge from "./Badge";

function MembershipCard({ member }) {
  return (
    <div className="membership-card">
      <div className="membership-card-top">
        <div className="membership-card-brand">
          Smart<span>fIT</span>
        </div>
        <Badge status={member.status} />
      </div>

      <div className="membership-card-body">
        <div className="sidebar-avatar" style={{ width: 54, height: 54, fontSize: "1rem" }}>
          {member.avatar}
        </div>
        <div>
          <div className="membership-card-name">{member.name}</div>
          <div className="membership-card-plan">{member.plan}</div>
        </div>
      </div>

      <div className="membership-card-foot">
        <span>{member.memberId}</span>
        <span>Valid thru {member.expiryDate}</span>
      </div>
    </div>
  );
}

export default MembershipCard;

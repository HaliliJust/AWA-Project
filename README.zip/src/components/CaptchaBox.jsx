import { AlertCircle, ShieldCheck } from "lucide-react";

/**
 * "I'm not a robot" checkbox.
 *
 * PLACEHOLDER: it only checks that the box is ticked — nothing is verified yet.
 * When a real CAPTCHA is connected later, replace this component and check the
 * token on the server. (For accessibility, choose a provider that offers a
 * non-visual, non-puzzle option — WCAG 3.3.8 Accessible Authentication.)
 */
function CaptchaBox({ id, checked, onChange, error }) {
  return (
    <div className="authx-field authx-span-6">
      <label className={`authx-captcha${error ? " has-error" : ""}`} htmlFor={id}>
        <input
          id={id}
          type="checkbox"
          checked={checked}
          onChange={(e) => onChange(e.target.checked)}
          aria-required="true"
          aria-invalid={error ? "true" : undefined}
          aria-describedby={error ? `${id}-error` : undefined}
        />
        <span className="authx-captcha-text">I'm not a robot</span>
        <span className="authx-captcha-brand" aria-hidden="true">
          <ShieldCheck size={22} />
          <span>Verification</span>
        </span>
      </label>

      {error && (
        <p id={`${id}-error`} className="authx-error">
          <AlertCircle size={15} aria-hidden="true" />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}

export default CaptchaBox;

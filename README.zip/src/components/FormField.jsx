import { useId } from 'react';
function FormField({
  label,
  type = 'text',
  full,
  hint,
  options,
  rows,
  ...props
}) {
  const id = useId();
  const shared = {
    ...props,
    id,
    'aria-describedby': hint ? `${id}-hint` : undefined
  };
  return <div className={`field${full ? ' full' : ''}`}><label htmlFor={id}>{label}</label>{type === 'select' ? <select {...shared}>{options.map(opt => <option key={opt}>{opt}</option>)}</select> : type === 'textarea' ? <textarea {...shared} rows={rows || 4} /> : <input {...shared} type={type} />} {hint && <span id={`${id}-hint`} className="field-hint">{hint}</span>}</div>;
}
export default FormField;

import { Users } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function TrainerEmptyState() {
  return <section className="card empty-state">
    <Users aria-hidden="true" />
    <h3>No clients yet</h3>
    <p>Members appear here after a workout is confirmed and their membership is active.</p>
    <Link className="btn btn-primary" to="/trainer/schedule">Review Workout Requests</Link>
  </section>;
}

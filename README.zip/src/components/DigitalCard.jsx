import { useState, useMemo } from "react";
import { RotateCw, Wifi, ShieldCheck, Phone, Droplet, Dumbbell } from "lucide-react";

// ---- design tokens — pulled from the app's real theme (index.css :root) --
const navyDark = "#0b0b0c"; // --bg
const navyMid = "#1c1c1f"; // --panel-alt
const navyLight = "#2a1116"; // dark, red-tinted panel for the gradient top
const amber = "#e8283f"; // --accent (brand red)
const mint = "#34c77b"; // --success (brand green, used for "active"/verified)
const offwhite = "#f5f5f6"; // --text
const muted = "rgba(245,245,246,0.55)"; // --text-soft equivalent, translucent
const mutedMint = "rgba(52,199,123,0.8)"; // soft --success for secondary accents

const cardGradient = `linear-gradient(135deg, ${navyLight} 0%, ${navyMid} 55%, ${navyDark} 100%)`;

// deterministic pseudo-random generator so the "QR" + barcode patterns
// stay stable across renders instead of reshuffling every time
function seededRandom(seedStr) {
  let seed = 0;
  for (let i = 0; i < seedStr.length; i++) seed = (seed * 31 + seedStr.charCodeAt(i)) >>> 0;
  return () => {
    seed = (seed * 1103515245 + 12345) >>> 0;
    return seed / 4294967295;
  };
}

const row = { display: "flex", alignItems: "center" };

/**
 * Flippable digital ID card, shared by both the Member and Trainer profile
 * pages. Pass `roleLabel` ("MEMBER" / "TRAINER") plus the relevant fields —
 * everything else about the layout stays identical between the two so the
 * card reads as one consistent system-wide design.
 *
 * UI only for now: flipping is the one working interaction, nothing here
 * reads from or writes to a backend.
 */
export default function DigitalCard({
  roleLabel = "MEMBER",
  name = "Juan Dela Cruz",
  idNumber = "GM-2024-0512",
  idLabel = "MEMBER ID",
  tier = "Premium",
  status = "Active",
  sinceLabel = "MEMBER SINCE",
  since = "May 2024",
  validThru = "06/2025",
  metaLeftIcon: MetaLeftIcon = Droplet,
  metaLeftValue = "O+",
  metaRightIcon: MetaRightIcon = Phone,
  metaRightValue = "+63 917 000 0000",
  footerNote = "This card is property of SmartfIT and is non-transferable. If found, please return to any SmartfIT front desk.",
  avatarImage = "",
}) {
  const [flipped, setFlipped] = useState(false);

  const initials = useMemo(
    () =>
      name
        .split(" ")
        .filter(Boolean)
        .slice(0, 2)
        .map((w) => w[0])
        .join("")
        .toUpperCase(),
    [name]
  );

  const qrCells = useMemo(() => {
    const rand = seededRandom(idNumber);
    const cells = Array.from({ length: 64 }, () => rand() > 0.55);
    [0, 1, 8, 9, 6, 7, 14, 15, 48, 49, 56, 57].forEach((i) => (cells[i] = true));
    return cells;
  }, [idNumber]);

  const barcodeBars = useMemo(() => {
    const rand = seededRandom(idNumber + "-bars");
    return Array.from({ length: 34 }, () => 1 + Math.floor(rand() * 3));
  }, [idNumber]);

  const toggleFlip = () => setFlipped((f) => !f);
  const handleKeyDown = (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      toggleFlip();
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');

        .digital-card-shell {
          outline: none;
          transition: transform 0.35s ease, filter 0.35s ease;
        }
        .digital-card-shell:hover { transform: translateY(-6px); }
        .digital-card-shell:active { transform: translateY(-2px) scale(0.995); }
        .digital-card-shell:focus-visible {
          outline: 2px solid ${mint};
          outline-offset: 8px;
        }
        .digital-card-flip {
          transition: transform 0.7s cubic-bezier(0.2, 0.8, 0.2, 1);
        }
        .digital-card-flip.is-flipped { transform: rotateY(180deg); }
        .digital-card-face {
          -webkit-backface-visibility: hidden;
          backface-visibility: hidden;
        }
        .digital-card-back { transform: rotateY(180deg); }

        .digital-card-trace-dim { opacity: 0.28; }
        .digital-card-trace-bright {
          stroke-dasharray: 18 82;
          animation: digitalCardTraceMove 2.6s linear infinite;
        }
        @keyframes digitalCardTraceMove {
          to { stroke-dashoffset: -100; }
        }

        @media (prefers-reduced-motion: reduce) {
          .digital-card-flip { transition: none !important; }
          .digital-card-trace-bright { animation: none !important; }
          .digital-card-shell { transition: none !important; }
        }
      `}</style>

      <div
        role="button"
        tabIndex={0}
        aria-pressed={flipped}
        aria-label={`${roleLabel === "TRAINER" ? "Trainer" : "Membership"} card, tap to flip`}
        onClick={toggleFlip}
        onKeyDown={handleKeyDown}
        className="digital-card-shell"
        style={{
          width: "100%",
          maxWidth: 400,
          aspectRatio: "1.6 / 1",
          perspective: 1600,
          cursor: "pointer",
        }}
      >
        <div
          className={`digital-card-flip ${flipped ? "is-flipped" : ""}`}
          style={{ position: "relative", width: "100%", height: "100%", transformStyle: "preserve-3d" }}
        >
          {/* ---------------- FRONT ---------------- */}
          <div
            className="digital-card-face"
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: 20,
              background: cardGradient,
              boxShadow: "0 20px 45px -18px rgba(0,0,0,0.65)",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                position: "absolute",
                inset: 0,
                background: "radial-gradient(circle at 18% 12%, rgba(255,255,255,0.10), transparent 45%)",
                pointerEvents: "none",
              }}
            />
            <div style={{ height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: 16, position: "relative" }}>
              {/* header */}
              <div style={{ ...row, alignItems: "flex-start", justifyContent: "space-between" }}>
                <div>
                  <div style={{ ...row, gap: 6 }}>
                    <Dumbbell size={14} color={mint} />
                    <span
                      style={{
                        fontFamily: "'Oswald', sans-serif",
                        fontWeight: 500,
                        fontStyle: "italic",
                        fontSize: "clamp(15px, 4.2vw, 18px)",
                        color: offwhite,
                        letterSpacing: 0.5,
                      }}
                    >
                      Smart
                      <span style={{ fontWeight: 700, color: amber }}>fIT</span>
                    </span>
                  </div>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 8,
                      letterSpacing: 2,
                      color: muted,
                      marginLeft: 20,
                    }}
                  >
                    {roleLabel} · {idLabel}
                  </div>
                </div>
                <div style={{ ...row, gap: 8 }}>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontWeight: 700,
                      fontSize: 9,
                      letterSpacing: 1,
                      color: amber,
                      background: "rgba(255,138,61,0.14)",
                      border: "1px solid rgba(255,138,61,0.5)",
                      borderRadius: 999,
                      padding: "3px 8px",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {tier.toUpperCase()}
                  </div>
                  <Wifi size={16} color={mutedMint} style={{ transform: "rotate(90deg)" }} />
                </div>
              </div>

              {/* identity */}
              <div style={{ ...row, gap: 12 }}>
                <div
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: "50%",
                    flexShrink: 0,
                    background: avatarImage ? `center / cover no-repeat url(${avatarImage})` : `linear-gradient(135deg, ${mint}, ${amber})`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontFamily: "'Oswald', sans-serif",
                    fontWeight: 700,
                    fontSize: 18,
                    color: navyDark,
                  }}
                >
                  {!avatarImage && initials}
                </div>
                <div style={{ minWidth: 0 }}>
                  <div
                    style={{
                      fontFamily: "'Oswald', sans-serif",
                      fontWeight: 700,
                      fontSize: "clamp(15px, 4.4vw, 19px)",
                      textTransform: "uppercase",
                      color: offwhite,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {name}
                  </div>
                  <div
                    style={{
                      fontFamily: "'JetBrains Mono', monospace",
                      fontSize: 11,
                      letterSpacing: 0.5,
                      color: mutedMint,
                      marginTop: 2,
                    }}
                  >
                    {idNumber}
                  </div>
                </div>
              </div>

              {/* heartbeat trace */}
              <svg viewBox="0 0 300 30" width="100%" height="22" preserveAspectRatio="none">
                <path
                  className="digital-card-trace-dim"
                  d="M0 15 H95 L104 4 L114 26 L122 10 L130 15 H300"
                  fill="none"
                  stroke={amber}
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  className="digital-card-trace-bright"
                  pathLength="100"
                  d="M0 15 H95 L104 4 L114 26 L122 10 L130 15 H300"
                  fill="none"
                  stroke={amber}
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>

              {/* footer */}
              <div style={{ ...row, alignItems: "flex-end", justifyContent: "space-between" }}>
                <div>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 8, letterSpacing: 1.5, color: muted }}>
                    {sinceLabel}
                  </div>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, fontWeight: 500, color: offwhite }}>
                    {since}
                  </div>
                </div>
                <div>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 8, letterSpacing: 1.5, color: muted, textAlign: "right" }}>
                    VALID THRU
                  </div>
                  <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, fontWeight: 500, color: offwhite, textAlign: "right" }}>
                    {validThru}
                  </div>
                </div>
                <div style={{ ...row, gap: 4 }}>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: mint, display: "inline-block" }} />
                  <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 9, fontWeight: 600, color: mint, letterSpacing: 0.5 }}>
                    {status.toUpperCase()}
                  </span>
                </div>
              </div>
            </div>
            <div
              style={{
                position: "absolute",
                bottom: 0,
                left: 0,
                right: 0,
                height: 4,
                background: amber,
                borderBottomLeftRadius: 20,
                borderBottomRightRadius: 20,
              }}
            />
          </div>

          {/* ---------------- BACK ---------------- */}
          <div
            className="digital-card-face digital-card-back"
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: 20,
              background: cardGradient,
              boxShadow: "0 20px 45px -18px rgba(0,0,0,0.65)",
              overflow: "hidden",
            }}
          >
            <div style={{ height: "100%", display: "flex", flexDirection: "column", position: "relative" }}>
              <div style={{ background: "rgba(0,0,0,0.75)", height: 30, marginTop: 14, flexShrink: 0 }} />

              <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between", padding: 16, paddingTop: 12 }}>
                {/* barcode + qr */}
                <div style={{ ...row, justifyContent: "space-between", gap: 12 }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "flex-end", gap: 2, height: 30 }}>
                      {barcodeBars.map((w, i) => (
                        <div key={i} style={{ width: w, height: "100%", background: offwhite, opacity: 0.9 }} />
                      ))}
                    </div>
                    <div
                      style={{
                        fontFamily: "'JetBrains Mono', monospace",
                        fontSize: 9,
                        letterSpacing: 1,
                        color: muted,
                        marginTop: 4,
                      }}
                    >
                      {idNumber}
                    </div>
                  </div>
                  <div
                    style={{
                      flexShrink: 0,
                      display: "grid",
                      gridTemplateColumns: "repeat(8, 1fr)",
                      gap: 1,
                      width: 52,
                      height: 52,
                      background: offwhite,
                      padding: 3,
                      borderRadius: 3,
                    }}
                  >
                    {qrCells.map((on, i) => (
                      <div key={i} style={{ background: on ? navyDark : "transparent" }} />
                    ))}
                  </div>
                </div>

                {/* fine print */}
                <p
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontSize: 8,
                    lineHeight: 1.5,
                    color: muted,
                    margin: 0,
                  }}
                >
                  {footerNote}
                </p>

                {/* signature panel */}
                <div>
                  <div
                    style={{
                      background: "rgba(245,243,238,0.92)",
                      borderRadius: 6,
                      height: 30,
                      display: "flex",
                      alignItems: "center",
                      paddingLeft: 10,
                    }}
                  >
                    <span
                      style={{
                        fontFamily: "Georgia, 'Times New Roman', serif",
                        fontStyle: "italic",
                        fontSize: 15,
                        color: navyDark,
                      }}
                    >
                      {name}
                    </span>
                  </div>
                  <div
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 7,
                      letterSpacing: 1.5,
                      color: muted,
                      marginTop: 3,
                    }}
                  >
                    AUTHORIZED SIGNATURE
                  </div>
                </div>

                {/* bottom info */}
                <div style={{ ...row, justifyContent: "space-between" }}>
                  <div style={{ ...row, gap: 12 }}>
                    <div style={{ ...row, gap: 4 }}>
                      <MetaLeftIcon size={11} color={amber} />
                      <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: offwhite }}>
                        {metaLeftValue}
                      </span>
                    </div>
                    <div style={{ ...row, gap: 4 }}>
                      <MetaRightIcon size={11} color={mutedMint} />
                      <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: offwhite }}>
                        {metaRightValue}
                      </span>
                    </div>
                  </div>
                  <div style={{ ...row, gap: 4 }}>
                    <ShieldCheck size={12} color={mint} />
                    <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 8, letterSpacing: 1, color: mint }}>
                      VERIFIED
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <button
        type="button"
        onClick={toggleFlip}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          background: "transparent",
          border: "1px solid rgba(245,243,238,0.2)",
          borderRadius: 999,
          padding: "8px 16px",
          fontFamily: "'Inter', sans-serif",
          fontSize: 12,
          color: offwhite,
          cursor: "pointer",
        }}
      >
        <RotateCw size={13} />
        Flip card
      </button>
    </div>
  );
}
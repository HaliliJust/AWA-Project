import { useState } from "react";
import { AlertCircle, ChevronDown, Eye, EyeOff } from "lucide-react";

/**
 * Form field for the auth screens.
 *  - <label> is tied to the control with htmlFor/id
 *  - required is announced (aria-required); optional fields say "(optional)" in the label
 *  - errors show an icon + text (never color alone) and are linked with aria-describedby
 *  - type="password" gets a show/hide toggle (44px touch target)
 *  - type="select" renders a styled native <select>; pass `options` as [{ value, label }]
 *  - `span` (2, 3 or 6) sets the column width inside the 6-column register grid
 */
function AuthField({
  id,
  label,
  type = "text",
  value,
  onChange,
  error,
  hint,
  options,
  optional = false,
  span = 3,
  autoComplete,
  autoCapitalize,
  inputMode,
  placeholder,
  min,
  max,
  maxLength,
}) {
  const [shown, setShown] = useState(false);
  const isPassword = type === "password";
  const isSelect = type === "select";

  // An error replaces the hint (they'd usually repeat each other).
  const showHint = hint && !error;
  const describedBy =
    [showHint && `${id}-hint`, error && `${id}-error`].filter(Boolean).join(" ") || undefined;

  const shared = {
    id,
    name: id,
    value,
    onChange,
    className: "authx-input",
    "aria-required": optional ? undefined : true,
    "aria-invalid": error ? "true" : undefined,
    "aria-describedby": describedBy,
  };

  return (
    <div className={`authx-field authx-span-${span}`}>
      <label className="authx-label" htmlFor={id}>
        {label}
        {optional && <span className="authx-optional"> (optional)</span>}
      </label>

      <div className="authx-control">
        {isSelect ? (
          <>
            <select {...shared} autoComplete={autoComplete}>
              {options.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
            <ChevronDown className="authx-chevron" size={18} aria-hidden="true" />
          </>
        ) : (
          <input
            {...shared}
            type={isPassword && shown ? "text" : type}
            autoComplete={autoComplete}
            autoCapitalize={autoCapitalize}
            spellCheck={autoCapitalize === "none" ? false : undefined}
            inputMode={inputMode}
            placeholder={placeholder}
            min={min}
            max={max}
            maxLength={maxLength}
          />
        )}

        {isPassword && (
          <button
            type="button"
            className="authx-toggle"
            onClick={() => setShown((s) => !s)}
            aria-label={shown ? "Hide password" : "Show password"}
          >
            {shown ? <EyeOff size={18} aria-hidden="true" /> : <Eye size={18} aria-hidden="true" />}
          </button>
        )}
      </div>

      {showHint && (
        <p id={`${id}-hint`} className="authx-hint">
          {hint}
        </p>
      )}
      {error && (
        <p id={`${id}-error`} className="authx-error">
          <AlertCircle size={15} aria-hidden="true" />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
}

export default AuthField;

import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  UserCircle,
  ShieldCheck,
  RefreshCcw,
  CalendarCheck,
  CalendarClock,
  Users,
  ClipboardList,
  PencilLine,
  TrendingUp,
  History,
  LogOut,
  IdCard,
  ListChecks,
  UserCog,
  Target,
  CreditCard,
  Eye,
} from "lucide-react";
import { currentMember, currentTrainer } from "../data/mockData";
import { useMember } from "../context/MemberContext";
import { useAuth } from "../context/AuthContext";

const navByRole = {
  member: [
    { to: "/member/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { to: "/member/workout-schedule", label: "Workout Schedule", icon: CalendarClock },
    { to: "/member/profile", label: "Profile", icon: UserCircle },
    { to: "/member/membership", label: "Membership Status", icon: ShieldCheck },
    { to: "/member/renew", label: "Renew Membership", icon: RefreshCcw },
    { to: "/member/workout-plans", label: "Workout Plans", icon: ListChecks },
    { to: "/member/attendance", label: "Attendance History", icon: CalendarCheck },
  ],
  trainer: [
    { to: "/trainer/dashboard", label: "Daily Schedule", icon: LayoutDashboard },
    { to: "/trainer/members", label: "Assigned Members", icon: Users },
    { to: "/trainer/programs", label: "Workout Programs", icon: ClipboardList },
    { to: "/trainer/view-programs", label: "View Programs", icon: Eye },
    { to: "/trainer/update-plans", label: "Update Workout Plans", icon: PencilLine },
    { to: "/trainer/schedule", label: "Schedule Sessions", icon: CalendarClock },
    { to: "/trainer/progress", label: "Progress Monitoring", icon: TrendingUp },
    { to: "/trainer/history", label: "Workout History", icon: History },
    { to: "/trainer/information", label: "Trainer Information", icon: IdCard },
  ],
  admin: [
    { to: "/admin/dashboard", label: "System Overview", icon: LayoutDashboard },
    { to: "/admin/members", label: "Manage Members", icon: Users },
    { to: "/admin/trainers", label: "Manage Trainers", icon: UserCog },
    { to: "/admin/goals", label: "Fitness Goals", icon: Target },
    { to: "/admin/payments", label: "Payments Overview", icon: CreditCard },
  ],
};

const roleLabel = {
  member: "Member",
  trainer: "Trainer",
  admin: "Admin",
};

function Sidebar({ role }) {
  const links = navByRole[role] || [];
  const linkClass = ({ isActive }) => "sidebar-link" + (isActive ? " active" : "");
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const { state } = useMember();
  const fallback = role === "trainer" ? currentTrainer : currentMember;
  const displayName = role === "member" ? state.profile.name : user?.name || fallback.name;
  const displayAvatar = displayName.split(" ").map(n => n[0]).join("").slice(0,2);
  const userId = role === "trainer" ? currentTrainer.trainerId : role === "member" ? state.profile.memberId : user?.username;

  function handleLogout(e) {
    e.preventDefault();
    logout();
    navigate("/login", { replace: true });
  }

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        Smart<span>fIT</span>
      </div>

      <div className="sidebar-user">
        <div className="sidebar-avatar">{role === "member" && state.profile.avatar ? <img src={state.profile.avatar} alt="" /> : displayAvatar}</div>
        <div>
          <div className="sidebar-user-name">{displayName}</div>
          <div className="sidebar-user-role">{roleLabel[role]} view · {userId}</div>
        </div>
      </div>

      <nav className="sidebar-nav">
        {links.map((item) =>
          item.section ? (
            <div className="sidebar-section-label" key={item.section}>{item.section}</div>
          ) : (
            <NavLink key={item.to} to={item.to} className={linkClass}>
              <item.icon />
              {item.label}
            </NavLink>
          )
        )}
      </nav>

      <div className="sidebar-foot">
        <NavLink to="/login" className="sidebar-link" onClick={handleLogout}>
          <LogOut />
          Log out
        </NavLink>
      </div>
    </aside>
  );
}

export default Sidebar;

import { Link } from 'react-router-dom';
import { workoutPrograms } from '../data/mockData';

export default function WorkoutSuggestions({ profile, active }) {
  const goal = profile.fitnessGoal;
  const matches = workoutPrograms.filter(plan => plan.goal === goal);
  const suggestions = matches.length ? matches : workoutPrograms;
  return <section className="card section-gap" aria-labelledby="workout-suggestions">
    <h3 id="workout-suggestions">Suggested Workout Plans</h3>
    <p>{matches.length ? `Explore plans for your saved goal: ${goal}.` : 'Explore these available plans with your trainer.'}</p>
    <div className="grid grid-3">{suggestions.map(plan => <article className="suggestion-card" key={plan.id}>
      <h4>{plan.name}</h4><p>{plan.type}</p>
      <dl><dt>Goal</dt><dd>{plan.goal}</dd><dt>Activity Level</dt><dd>{plan.activityLevel}</dd><dt>Program Duration</dt><dd>{plan.duration}</dd></dl>
      <Link className="btn btn-primary" to={active ? `/member/workout-plans?plan=${plan.id}` : '/member/renew'}>{active ? 'Choose This Plan' : 'Subscribe to Choose'}</Link>
    </article>)}</div>
  </section>;
}

import { calcAge } from '../services/accountStore';
import Badge from './Badge';

export default function MemberDetails({ member }) {
  const p = member.profile;
  const height = parseFloat(p.height), weight = parseFloat(p.weight);
  const bmi = height > 0 && weight > 0 ? (weight / (height / 100) ** 2).toFixed(1) : null;
  const fields = [
    ['Member ID', p.memberId], ['Age', calcAge(p.dob)], ['Gender', p.gender],
    ['Email', p.email], ['Contact Number', p.contact], ['Fitness Goal', p.fitnessGoal],
    ['Body Type', p.bodyType], ['Height', height > 0 ? `${height} cm` : null],
    ['Weight', weight > 0 ? `${weight} kg` : null], ['BMI', bmi],
    ['Membership Plan', member.membership.plan],
    ['Emergency Contact', p.emergencyName], ['Emergency Number', p.emergencyContact],
  ];
  return <div className="member-details">
    <div className="member-detail-heading">
      {p.avatar && <img className="member-detail-photo" src={p.avatar} alt={`${p.name}'s profile`} />}
      <div><h3>{p.name}</h3><p>Member information</p></div>
    </div>
    <dl className="member-detail-grid">{fields.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value === '' || value == null ? 'Not provided' : value}</dd></div>)}</dl>
    {member.sessions && <><h4>Assigned Workouts</h4>{member.sessions.map(s => <div className="session-item" key={s.id}><strong>{s.program}</strong><p>{s.date} at {s.time} · {s.duration} minutes</p><Badge status={s.status} /></div>)}</>}
  </div>;
}

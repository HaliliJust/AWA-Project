function TimelineList({ items }) {
  return (
    <div className="timeline">
      {items.map((item, i) => (
        <div className="timeline-item" key={i}>
          <span className="timeline-time">{item.time}</span>
          <span className="timeline-icon">
            <item.icon />
          </span>
          <div className="timeline-body">
            <div className="timeline-title">{item.title}</div>
            <div className="timeline-sub">{item.subtitle}</div>
          </div>
          {item.trailing}
        </div>
      ))}
    </div>
  );
}

export default TimelineList;

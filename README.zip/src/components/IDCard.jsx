import { useState } from "react";
import { QrCode } from "lucide-react";

function IDCard({ name, role, id, avatar, qrValue }) {
  const [flipped, setFlipped] = useState(false);

  return (
    <div className="id-card-scene">
      <div
        className={`id-card${flipped ? " flipped" : ""}`}
        onClick={() => setFlipped((f) => !f)}
        role="button"
        tabIndex={0}
      >
        <div className="id-card-inner">
          <div className="id-card-face">
            <div className="id-card-brand">
              Smart<span>fIT</span>
            </div>
            <div className="id-card-body">
              <div className="sidebar-avatar" style={{ width: 54, height: 54, fontSize: "1rem" }}>
                {avatar}
              </div>
              <div>
                <div className="id-card-name">{name}</div>
                <div className="id-card-role">{role}</div>
              </div>
            </div>
            <div className="id-card-id">{id}</div>
            <div className="id-card-hint">Tap card to flip &amp; view QR code</div>
          </div>

          <div className="id-card-face id-card-back">
            <div className="qr-box">
              <QrCode size={72} color="#0b0b0c" />
            </div>
            <div className="id-card-id" style={{ marginTop: 0 }}>{qrValue}</div>
            <div className="id-card-hint">Scan for quick verification</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default IDCard;

import { useId } from 'react';
import { Camera, Upload } from 'lucide-react';

export default function ProfilePhotoUpload({ value, name, onChange, busy, error, required = false }) {
  const id = useId();
  return <div className="field full">
    <label htmlFor={id}>Profile Photo{required ? ' (required)' : ''}</label>
    <div className={`photo-upload${error ? ' photo-upload-error' : ''}`}>
      <div className="photo-upload-preview">
        {value ? <img src={value} alt={`${name || 'Your'} profile preview`} /> : <Camera size={32} aria-hidden="true" />}
      </div>
      <div className="photo-upload-content">
        <strong>{value ? 'Update your profile photo' : 'Add a profile photo'}</strong>
        <p id={`${id}-hint`}>JPG, PNG or WebP, up to 2 MB. Choose a clear photo of yourself.</p>
        <div className="photo-upload-control">
          <input id={id} type="file" accept="image/jpeg,image/png,image/webp" disabled={busy}
            aria-required={required} aria-invalid={!!error}
            aria-describedby={`${id}-hint${error ? ` ${id}-error` : ''}`}
            onChange={e => { onChange(e); e.target.value = ''; }} />
          <span className="btn btn-ghost" aria-hidden="true"><Upload size={16} />{busy ? 'Preparing photo...' : value ? 'Change Photo' : 'Choose Photo'}</span>
        </div>
        <p className="photo-upload-status" role="status">{busy ? 'Resizing your photo...' : 'Preview your photo, then select Save Changes.'}</p>
      </div>
    </div>
    {error && <p id={`${id}-error`} className="photo-error" role="alert">{error}</p>}
  </div>;
}

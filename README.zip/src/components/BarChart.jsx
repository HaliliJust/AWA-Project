function BarChart({ values = [], labels = [] }) {
  const max = Math.max(...values, 1);

  return (
    <div className="bar-chart">
      {values.map((value, i) => (
        <div className="bar-col" key={labels[i] ?? i}>
          <div className="bar" style={{ height: `${(value / max) * 100}%` }} />
          <span className="bar-label">{labels[i]}</span>
        </div>
      ))}
    </div>
  );
}

export default BarChart;

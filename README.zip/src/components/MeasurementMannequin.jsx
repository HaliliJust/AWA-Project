import { useMemo, useState } from "react";
import BodyType3D from "./BodyType3D";
import { DEFAULT_MEASUREMENTS, MEASUREMENT_RANGES, measurementsToShape } from "../utils/bodyMeasurements";

const FIELDS = [
  { key: "height", label: "Height", unit: "cm" },
  { key: "chest", label: "Chest", unit: "cm" },
  { key: "waist", label: "Waist", unit: "cm" },
  { key: "hips", label: "Hips", unit: "cm" },
  { key: "shoulders", label: "Shoulders", unit: "cm" },
];

/**
 * Interactive 3D mannequin driven by literal body measurements (cm), rather
 * than the somatotype picker used at registration. Ported from the
 * standalone 3D-mannequin prototype's slider panel, but rendered with the
 * gym system's own BodyType3D mannequin instead of the prototype's plain
 * cylinder/sphere body.
 */
function MeasurementMannequin({ initialMeasurements, value, onChange }) {
  const [localMeasurements, setMeasurements] = useState({ ...DEFAULT_MEASUREMENTS, ...initialMeasurements });

  const measurements = value || localMeasurements;
  const { shape, heightScale } = useMemo(() => measurementsToShape(measurements), [measurements]);

  const handleChange = (key, value) => {
    const next = { ...measurements, [key]: Number(value) };
    if (onChange) onChange(next); else setMeasurements(next);
  };

  return (
    <div className="card">
      <div className="card-head">
        <h3>Body Measurements &amp; 3D Preview</h3>
      </div>

      <div className="mm-layout">
        <div className="mm-sliders">
          {FIELDS.map(({ key, label, unit }) => {
            const range = MEASUREMENT_RANGES[key];
            return (
              <div className="mm-field" key={key}>
                <div className="mm-field-head">
                  <label htmlFor={`mm-${key}`}>{label}</label>
                  <span className="mm-field-value">
                    {measurements[key]} {unit}
                  </span>
                </div>
                <input
                  id={`mm-${key}`}
                  type="range"
                  className="mm-range"
                  min={range.min}
                  max={range.max}
                  step={range.step}
                  value={measurements[key]}
                  onChange={(e) => handleChange(key, e.target.value)}
                />
              </div>
            );
          })}
          <p className="mm-hint">Adjust the sliders to preview how each measurement changes the mannequin.</p>
        </div>

        <div className="mm-preview">
          <div className="mm-canvas">
            <BodyType3D shape={shape} heightScale={heightScale} />
          </div>
          <p className="mm-preview-hint">Drag to rotate the preview</p>
        </div>
      </div>
    </div>
  );
}

export default MeasurementMannequin;

import { AlertTriangle } from "lucide-react";

function Banner({ title, subtitle, actionLabel, icon: Icon = AlertTriangle }) {
  return (
    <div className="banner">
      <Icon />
      <div>
        <div className="banner-title">{title}</div>
        {subtitle && <div className="banner-sub">{subtitle}</div>}
      </div>
      {actionLabel && (
        <button type="button" className="btn btn-primary btn-sm">
          {actionLabel}
        </button>
      )}
    </div>
  );
}

export default Banner;

// A simple, parametric 2D body silhouette (not a photo/avatar) — just enough
// shape to tell body types apart at a glance, similar to the reference
// screenshot's body-type picker.
//
// Each "shape" is a set of widths at fixed heights (shoulder, chest, waist,
// hip, thigh). torsoPath() connects them with smooth curves; legs and arms
// are drawn separately so the waist can pinch in without cutting into limbs.

const CX = 50; // horizontal center of the 100-wide viewBox
const Y = { neck: 28, shoulder: 38, chest: 60, waist: 92, hip: 118, thighTop: 120, bottom: 190 };

// Each somatotype (ectomorph/mesomorph/endomorph) spans a min..max range for
// every measurement, so a single slider can dial in a build anywhere within
// that category — from leaner to fuller — rather than only offering one
// fixed shape per category. Ranges are deliberately exaggerated so they read
// as different body types at a small, glanceable size; this is a schematic
// picker, not an anatomical scale.
export const FEMININE_RANGES = {
  ectomorph: {
    label: "Ectomorph",
    description: "Naturally lean, narrow frame that gains weight slowly.",
    min: { shoulder: 28, chest: 26, waist: 19, hip: 26, thigh: 9, armThigh: 14 },
    max: { shoulder: 34, chest: 31, waist: 23, hip: 32, thigh: 12, armThigh: 17 },
  },
  mesomorph: {
    label: "Mesomorph",
    description: "Athletic, well-proportioned frame that builds muscle easily.",
    min: { shoulder: 34, chest: 34, waist: 24, hip: 34, thigh: 14, armThigh: 18 },
    max: { shoulder: 40, chest: 42, waist: 28, hip: 46, thigh: 18, armThigh: 21 },
  },
  endomorph: {
    label: "Endomorph",
    description: "Broader frame that gains both muscle and fat easily.",
    min: { shoulder: 38, chest: 42, waist: 34, hip: 44, thigh: 18, armThigh: 21 },
    max: { shoulder: 46, chest: 56, waist: 62, hip: 62, thigh: 26, armThigh: 27 },
  },
};

export const MASCULINE_RANGES = {
  ectomorph: {
    label: "Ectomorph",
    description: "Naturally lean, narrow frame that gains weight slowly.",
    min: { shoulder: 38, chest: 30, waist: 24, hip: 26, thigh: 12, armThigh: 16 },
    max: { shoulder: 46, chest: 37, waist: 29, hip: 30, thigh: 15, armThigh: 19 },
  },
  mesomorph: {
    label: "Mesomorph",
    description: "Athletic, well-proportioned frame that builds muscle easily.",
    min: { shoulder: 48, chest: 42, waist: 29, hip: 32, thigh: 15, armThigh: 20 },
    max: { shoulder: 60, chest: 54, waist: 34, hip: 36, thigh: 19, armThigh: 25 },
  },
  endomorph: {
    label: "Endomorph",
    description: "Broader frame that gains both muscle and fat easily.",
    min: { shoulder: 50, chest: 52, waist: 46, hip: 42, thigh: 19, armThigh: 23 },
    max: { shoulder: 62, chest: 64, waist: 64, hip: 54, thigh: 26, armThigh: 28 },
  },
};

const MEASUREMENTS = ["shoulder", "chest", "waist", "hip", "thigh", "armThigh"];

// t is 0..1 (0 = the category's leanest build, 1 = its fullest).
export function lerpShape(min, max, t) {
  const shape = {};
  MEASUREMENTS.forEach((key) => {
    shape[key] = min[key] + (max[key] - min[key]) * t;
  });
  return shape;
}

function torsoPath(s) {
  const hw = (n) => n / 2; // half-width
  // Right-side outline, top to bottom, then mirrored back up the left side.
  const pts = [
    [CX + hw(s.shoulder) * 0.55, Y.neck],
    [CX + hw(s.shoulder), Y.shoulder],
    [CX + hw(s.chest), Y.chest],
    [CX + hw(s.waist), Y.waist],
    [CX + hw(s.hip), Y.hip],
  ];
  const left = pts.map(([x, y]) => [CX - (x - CX), y]).reverse();

  let d = `M ${pts[0][0]} ${pts[0][1]}`;
  for (let i = 1; i < pts.length; i += 1) {
    const [px, py] = pts[i - 1];
    const [x, y] = pts[i];
    const midY = (py + y) / 2;
    d += ` C ${px} ${midY}, ${x} ${midY}, ${x} ${y}`;
  }
  d += ` L ${left[0][0]} ${left[0][1]}`;
  for (let i = 1; i < left.length; i += 1) {
    const [px, py] = left[i - 1];
    const [x, y] = left[i];
    const midY = (py + y) / 2;
    d += ` C ${px} ${midY}, ${x} ${midY}, ${x} ${y}`;
  }
  d += " Z";
  return d;
}

function BodySilhouette({ shape, size = 88 }) {
  const s = shape;
  const legGap = 3;
  const legW = s.thigh;
  const armW = s.armThigh * 0.32;
  const armX = CX + s.shoulder / 2 - armW * 0.35;

  return (
    <svg viewBox="0 0 100 200" width={size} height={size * 2} aria-hidden="true" focusable="false">
      {/* arms */}
      <rect x={armX} y={Y.shoulder - 2} width={armW} height={70} rx={armW / 2} className="authx-bodysvg-fill" />
      <rect
        x={100 - armX - armW}
        y={Y.shoulder - 2}
        width={armW}
        height={70}
        rx={armW / 2}
        className="authx-bodysvg-fill"
      />
      {/* legs */}
      <rect
        x={CX - legGap / 2 - legW}
        y={Y.thighTop}
        width={legW}
        height={Y.bottom - Y.thighTop}
        rx={legW / 2.4}
        className="authx-bodysvg-fill"
      />
      <rect
        x={CX + legGap / 2}
        y={Y.thighTop}
        width={legW}
        height={Y.bottom - Y.thighTop}
        rx={legW / 2.4}
        className="authx-bodysvg-fill"
      />
      {/* head */}
      <circle cx={CX} cy={16} r={11} className="authx-bodysvg-fill" />
      {/* torso (drawn last so it overlaps the tops of arms/legs cleanly) */}
      <path d={torsoPath(s)} className="authx-bodysvg-fill" />
    </svg>
  );
}

export default BodySilhouette;

import { useState, useEffect, useRef } from "react";
import { Bell, X, CalendarClock, UserX, UserCheck, RefreshCw } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useMember } from "../context/MemberContext";

function formatDate(date) {
  return date.toLocaleDateString("en-PH", {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
}

function notificationIcon(n) {
  switch (n.type) {
    case "workout_completed":
      return <UserCheck size={16} />;
    case "workout_missed":
      return <UserX size={16} />;
    case "trainer_response":
      return <RefreshCw size={16} />;
    case "membership_expiry":
      return <CalendarClock size={16} />;
    case "workout_reminder":
      return <CalendarClock size={16} />;
    default:
      return <Bell size={16} />;
  }
}

function notificationColor(n) {
  switch (n.type) {
    case "workout_completed":
      return "var(--success)";
    case "workout_missed":
      return "var(--danger)";
    case "trainer_response":
      return "var(--accent)";
    case "membership_expiry":
      return "var(--warning)";
    case "workout_reminder":
      return "var(--accent-2)";
    default:
      return "var(--text-soft)";
  }
}

function Topbar({ title, crumb }) {
  const [today, setToday] = useState(new Date());
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);
  const bellRef = useRef(null);
  const navigate = useNavigate();
  const { notifications, markRead, markAllRead, unreadCount } = useMember();

  useEffect(() => {
    const tick = () => setToday(new Date());
    const id = setInterval(tick, 60000);
    return () => clearInterval(id);
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handler(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const count = unreadCount;

  return (
    <header className="topbar">
      <div>
        <h1>{title}</h1>
        {crumb && <div className="topbar-crumb">{crumb}</div>}
      </div>

      <div className="topbar-right">
        <div className="topbar-pill">
          Today
          <span style={{ marginLeft: 6, opacity: 1, fontSize: "0.78rem" }}>
            {formatDate(today)}
          </span>
        </div>

        <div className="topbar-notification-wrap" ref={dropdownRef} onKeyDown={e => { if (e.key === "Escape") { setOpen(false); bellRef.current?.focus(); } }}>
          <button
            className="topbar-icon-btn"
            type="button"
            ref={bellRef}
            aria-controls="notifications-panel"
            aria-label={`Notifications, ${count} unread`}
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
          >
            <Bell />
            {count > 0 && <span className="topbar-dot" />}
          </button>

          {open && (
            <section id="notifications-panel" aria-label="Notifications" className="notification-dropdown">
              <div className="notification-head">
                <span className="notification-title">
                  Notifications {count > 0 && `(${count})`}
                </span>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  {count > 0 && (
                    <button
                      type="button"
                      className="notification-link"
                      onClick={markAllRead}
                    >
                      Mark all read
                    </button>
                  )}
                  <button
                    type="button"
                    className="notification-close"
                    aria-label="Close"
                    onClick={() => setOpen(false)}
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>

              <div className="notification-list">
                {notifications.length === 0 ? (
                  <div className="notification-empty">
                    <Bell size={22} />
                    <p>No notifications yet</p>
                  </div>
                ) : (
                  notifications.map((n) => (
                    <button
                      type="button"
                      key={n.id}
                      className={`notification-item ${n.read ? "read" : "unread"}`}
                      onClick={() => { if (markRead(n.id) && n.link) { setOpen(false); navigate(n.link); } }}
                    >
                      <div
                        className="notification-icon"
                        style={{ color: notificationColor(n) }}
                      >
                        {notificationIcon(n)}
                      </div>
                      <div className="notification-body">
                        <div className="notification-title-text">{n.title}</div>
                        {n.subtitle && (
                          <div className="notification-sub">{n.subtitle}</div>
                        )}
                        <div className="notification-time">
                          {new Date(n.createdAt).toLocaleString("en-PH", {
                            month: "short",
                            day: "numeric",
                            hour: "numeric",
                            minute: "2-digit",
                            hour12: true,
                          })}
                        </div>
                      </div>
                      {!n.read && <span className="notification-dot" />}
                    </button>
                  ))
                )}
              </div>
            </section>
          )}
        </div>
      </div>
    </header>
  );
}

export default Topbar;
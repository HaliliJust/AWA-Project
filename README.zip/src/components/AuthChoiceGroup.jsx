import { AlertCircle, Check } from "lucide-react";

/**
 * A group of radio buttons or checkboxes, built on a real <fieldset>/<legend>.
 *  - type="radio":    `value` is a string, `onChange(newValue)`
 *  - type="checkbox": `value` is an array, `onChange(newArray)`
 *  - variant "card" (title + description) or "chip" (short pill)
 * The native inputs stay in the page (visually hidden) so keyboard, arrow keys and
 * screen readers behave normally. The selected state is shown with a mark (dot / check)
 * as well as color, so it never relies on color alone.
 */
function AuthChoiceGroup({
  id,
  legend,
  type = "radio",
  variant = "card",
  options,
  value,
  onChange,
  error,
  hint,
  span = 6,
}) {
  const isCheckbox = type === "checkbox";
  const isSelected = (v) => (isCheckbox ? value.includes(v) : value === v);
  const choose = (v) => {
    if (isCheckbox) onChange(value.includes(v) ? value.filter((x) => x !== v) : [...value, v]);
    else onChange(v);
  };

  const describedBy =
    [hint && !error && `${id}-hint`, error && `${id}-error`].filter(Boolean).join(" ") || undefined;

  return (
    <fieldset id={id} className={`authx-field authx-choices authx-span-${span}`} aria-describedby={describedBy}>
      <legend className="authx-label">{legend}</legend>

      <div className={`authx-choice-list authx-choice-list--${variant}`}>
        {options.map((o) => {
          const selected = isSelected(o.value);
          return (
            <label key={o.value} className={`authx-choice authx-choice--${variant}`}>
              <input
                type={type}
                name={id}
                value={o.value}
                checked={selected}
                onChange={() => choose(o.value)}
                className="authx-sr"
              />
              <span className={`authx-choice-face${selected ? " is-selected" : ""}`}>
                <span className={`authx-choice-mark authx-choice-mark--${type}`} aria-hidden="true">
                  {selected && (isCheckbox ? <Check size={14} strokeWidth={3} /> : <span className="authx-radio-dot" />)}
                </span>
                <span className="authx-choice-text">
                  <span className="authx-choice-label">{o.label}</span>
                  {o.description && <span className="authx-choice-desc">{o.description}</span>}
                </span>
              </span>
            </label>
          );
        })}
      </div>

      {hint && !error && (
        <p id={`${id}-hint`} className="authx-hint">
          {hint}
        </p>
      )}
      {error && (
        <p id={`${id}-error`} className="authx-error">
          <AlertCircle size={15} aria-hidden="true" />
          <span>{error}</span>
        </p>
      )}
    </fieldset>
  );
}

export default AuthChoiceGroup;

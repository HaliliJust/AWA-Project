export function planExercises(plan = {}) {
  return plan.exerciseItems || (plan.exercises || '').split(',').filter(Boolean).map(name => ({ name: name.trim(), sets: plan.sets || 3, reps: String(plan.reps || '10'), rest: parseFloat(plan.restTime) || 60 }));
}
export function ExerciseSummary({ plan }) {
  return <ol className="exercise-summary">{planExercises(plan).map((e, i) => <li key={i}><strong>{e.name}</strong><span>{e.sets} sets · {e.reps} reps / duration · {e.rest}s rest</span></li>)}</ol>;
}
export default function ExerciseEditor({ value, onChange }) {
  function update(index, key, next) { onChange(value.map((e, i) => i === index ? { ...e, [key]: next } : e)); }
  return <div className="field full"><div className="card-head"><h3>Exercises</h3><span>{value.length} exercises</span></div>
    {value.map((exercise, i) => <div className="exercise-editor-row" key={i}>
      <label className="field">Exercise {i + 1}<input required maxLength={100} value={exercise.name} onChange={e => update(i, 'name', e.target.value)} placeholder="e.g. Dumbbell squat" /></label>
      <label className="field">Sets<input required type="number" min="1" max="20" value={exercise.sets} onChange={e => update(i, 'sets', e.target.value)} /></label>
      <label className="field">Reps / duration<input required maxLength={40} value={exercise.reps} onChange={e => update(i, 'reps', e.target.value)} placeholder="10 reps or 30 sec" /></label>
      <label className="field">Rest (sec)<input required type="number" min="0" max="1800" value={exercise.rest} onChange={e => update(i, 'rest', e.target.value)} /></label>
      <button type="button" className="btn btn-ghost" aria-label={`Remove exercise ${i + 1}`} onClick={() => onChange(value.filter((_, n) => n !== i))}>Remove</button>
    </div>)}
    <button type="button" className="btn btn-ghost" onClick={() => onChange([...value, { name: '', sets: 3, reps: '10', rest: 60 }])}>+ Add exercise</button>
  </div>;
}

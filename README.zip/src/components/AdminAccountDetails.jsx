import { useEffect, useRef, useState } from 'react';
import { useMember } from '../context/MemberContext';
import { getAccounts } from '../services/accountStore';
import { DEMO_ACCOUNTS } from '../data/demoAccounts';
import { trainerProfile } from '../services/adminData';
import { membershipInfo } from '../services/memberStore';
import MemberDetails from './MemberDetails';

function Fields({ values }) {
  return <dl className="member-detail-grid">{values.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value === '' || value == null ? 'Not provided' : value}</dd></div>)}</dl>;
}

export function RemovalHistory({ records, onView }) {
  return <section className="card section-gap"><h3>Removal history</h3>{records.length ? records.map(record => <article className="session-item" key={record.username}>
    <h4>{record.name} <span className="badge">Removed</span></h4><p>{record.username} · {new Date(record.removedAt).toLocaleString()} · Admin: {record.removedBy}</p>
    <p className="removal-reason"><strong>Reason:</strong> {record.reason}</p><button className="btn btn-ghost btn-sm" onClick={() => onView(record.username)}>View information</button>
  </article>) : <p>No accounts have been removed.</p>}</section>;
}

export default function AdminAccountDetails({ username, onClose, startRemoval = false }) {
  const { database, removeGymAccount, error } = useMember();
  const [removing, setRemoving] = useState(startRemoval);
  const [reason, setReason] = useState('');
  const [notice, setNotice] = useState('');
  const panel = useRef(null);
  useEffect(() => { panel.current?.focus(); }, []);
  const account = [...DEMO_ACCOUNTS, ...getAccounts()].find(a => a.username.toLowerCase() === username);
  if (!account) return null;
  const member = account.role === 'member' ? database.members[username] : null;
  const trainer = account.role === 'trainer' ? trainerProfile(account) : null;
  const name = member?.profile.name || trainer?.name || account.name;
  const removal = database.removals?.[username];
  const membership = member && membershipInfo(member.membership);
  const assigned = trainer ? Object.entries(database.members).filter(([key, m]) => !database.removals?.[key] && membershipInfo(m.membership).active && m.workoutSchedule.some(s => s.trainerId?.toLowerCase() === username && ['Scheduled', 'Completed', 'Missed'].includes(s.status))) : [];
  function submit(e) {
    e.preventDefault();
    if (removeGymAccount(username, reason)) { setRemoving(false); setNotice(name + ' has been removed from the gym.'); }
  }
  return <section className="card section-gap" id="admin-account-details" tabIndex={-1} ref={panel} aria-label={`${name} account information`}>
    <div className="card-head"><h2>Account information</h2><button className="btn btn-ghost" onClick={onClose}>Close details</button></div>
    <p role="status">{notice}</p>
    <Fields values={[["Username", username], ["Account role", account.role], ["Account status", removal ? 'Removed' : account.status || 'Active'], ["Registered", account.createdAt ? new Date(account.createdAt).toLocaleDateString() : member?.membership.joinDate]]} />
    {member && <><MemberDetails member={member} /><Fields values={[["Date of birth", member.profile.dob], ["Address", member.profile.address], ["Membership status", membership.status], ["Membership expires", membership.expiryDate], ["Payment status", membership.paymentStatus], ["Recorded attendance", member.attendanceHistory.length + ' visits']]} />
      {member.profile.measurements && <Fields values={Object.entries(member.profile.measurements).map(([key, value]) => [key[0].toUpperCase() + key.slice(1), value + ' cm'])} />}
    </>}
    {trainer && <><div className="member-detail-heading">{trainer.photo && <img className="member-detail-photo" src={trainer.photo} alt={`${name}'s profile`} />}<h3>{name}</h3></div>
      <Fields values={[["Trainer ID", account.id || account.username], ["Email", trainer.email], ["Phone", trainer.phone], ["Specialty", trainer.specialty], ["Certifications", trainer.certification], ["Experience", trainer.experience], ["Date of birth", account.birthdate], ["Gender", account.gender], ["Emergency contact", account.emergencyContactName], ["Emergency number", account.emergencyContactNumber]]} />
      <h4>Assigned members ({assigned.length})</h4>{assigned.length ? <ul>{assigned.map(([key, m]) => <li key={key}>{m.profile.name} · {m.profile.memberId}</li>)}</ul> : <p>No assigned members.</p>}
    </>}
    {removal ? <div className="removal-notice"><h3>Account removed</h3><p className="removal-reason">{removal.reason}</p><p>{new Date(removal.removedAt).toLocaleString()} · Admin: {removal.removedBy}</p></div> : removing ? <form onSubmit={submit} className="removal-notice">
      <h3>Remove {name} from the gym?</h3><p>This blocks sign-in, removes the account from current rosters, and cancels pending requests and future sessions. Past workout and payment records are retained. The reason is shown to this account when they try to sign in.</p>
      <label className="field" htmlFor="removal-reason">Reason for removal (required)<textarea id="removal-reason" required maxLength={1000} rows={4} value={reason} onChange={e => setReason(e.target.value)} placeholder="Explain why this account is being removed" /></label>
      {error && <p role="alert">{error}</p>}<div className="btn-row"><button className="btn btn-danger" disabled={!reason.trim()}>Confirm removal</button><button type="button" className="btn btn-ghost" onClick={() => { setRemoving(false); setReason(''); }}>Cancel</button></div>
    </form> : <button className="btn btn-danger section-gap" onClick={() => setRemoving(true)}>Remove {account.role}</button>}
  </section>;
}

function DataTable({ columns, rows, renderRow }) {
  if (!rows.length) {
    return (
      <div className="empty-state">
        <h4>Nothing here yet</h4>
        <p>Records will show up in this table once this feature is connected.</p>
      </div>
    );
  }

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col}>{col}</th>
            ))}
          </tr>
        </thead>
        <tbody>{rows.map((row, i) => renderRow(row, i))}</tbody>
      </table>
    </div>
  );
}

export default DataTable;

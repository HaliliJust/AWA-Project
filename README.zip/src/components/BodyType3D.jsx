import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";

// Width unit (from BodySilhouette.jsx's shape config) -> a radius in meters.
const r = (w) => Math.max(w / 130, 0.015);

function buildHand(wristR, material) {
  const hand = new THREE.Group();

  const palm = new THREE.Mesh(new THREE.SphereGeometry(wristR * 1.05, 10, 8), material);
  palm.scale.set(1, 0.85, 0.6);
  palm.position.y = -wristR * 0.6;
  palm.castShadow = true;
  hand.add(palm);

  const fingerLen = wristR * 2.6;
  const fingerR = wristR * 0.22;
  for (let i = 0; i < 4; i += 1) {
    const finger = new THREE.Mesh(
      new THREE.CapsuleGeometry(fingerR, Math.max(fingerLen - fingerR * 2, 0.02), 3, 6),
      material
    );
    finger.position.set((i - 1.5) * fingerR * 2.2, -wristR * 1.1 - fingerLen / 2, wristR * 0.15);
    finger.rotation.x = 0.25;
    finger.castShadow = true;
    hand.add(finger);
  }

  const thumb = new THREE.Mesh(
    new THREE.CapsuleGeometry(fingerR * 1.1, Math.max(fingerLen * 0.6 - fingerR * 2, 0.02), 3, 6),
    material
  );
  thumb.position.set(wristR * 1.05, -wristR * 0.45, wristR * 0.3);
  thumb.rotation.z = 0.9;
  thumb.rotation.x = 0.3;
  thumb.castShadow = true;
  hand.add(thumb);

  return hand;
}

// A shoulder -> upper arm -> elbow -> forearm -> hand chain, built from nested
// pivots so each joint just needs a rotation, not manual trigonometry.
function buildArm({ upperLen, upperR, foreLen, foreR, outAngle, bendAngle, mirror, material }) {
  const shoulder = new THREE.Group();
  shoulder.rotation.z = mirror * outAngle;
  shoulder.rotation.x = 0.14;

  const upper = new THREE.Mesh(
    new THREE.CapsuleGeometry(upperR, Math.max(upperLen - upperR * 2, 0.04), 4, 10),
    material
  );
  upper.position.y = -upperLen / 2;
  upper.castShadow = true;
  shoulder.add(upper);

  const elbow = new THREE.Group();
  elbow.position.y = -upperLen;
  elbow.rotation.z = mirror * bendAngle;
  shoulder.add(elbow);

  const fore = new THREE.Mesh(new THREE.CapsuleGeometry(foreR, Math.max(foreLen - foreR * 2, 0.04), 4, 10), material);
  fore.position.y = -foreLen / 2;
  fore.castShadow = true;
  elbow.add(fore);

  const wrist = new THREE.Group();
  wrist.position.y = -foreLen;
  wrist.rotation.z = mirror * 0.1;
  elbow.add(wrist);
  wrist.add(buildHand(foreR, material));

  return shoulder;
}

function buildLeg({ hipX, thighLen, thighR, calfLen, calfR, mirror, material, standAngle }) {
  const hip = new THREE.Group();
  hip.position.set(mirror * hipX, 0, 0);
  hip.rotation.z = mirror * standAngle;

  const thigh = new THREE.Mesh(
    new THREE.CapsuleGeometry(thighR, Math.max(thighLen - thighR * 2, 0.05), 4, 10),
    material
  );
  thigh.position.y = -thighLen / 2;
  thigh.castShadow = true;
  hip.add(thigh);

  const knee = new THREE.Group();
  knee.position.y = -thighLen;
  hip.add(knee);

  const calf = new THREE.Mesh(new THREE.CapsuleGeometry(calfR, Math.max(calfLen - calfR * 2, 0.05), 4, 10), material);
  calf.position.y = -calfLen / 2;
  calf.castShadow = true;
  knee.add(calf);

  const foot = new THREE.Mesh(new THREE.CapsuleGeometry(calfR * 0.8, calfR * 2.3, 4, 8), material);
  foot.rotation.x = Math.PI / 2;
  foot.position.set(0, -calfLen - calfR * 0.35, calfR * 1.25);
  foot.castShadow = true;
  knee.add(foot);

  return hip;
}

// Builds the full mannequin for one shape config, feet resting on y = 0.
// heightScale stretches the whole figure vertically (1 = the shape's native
// proportions); applied before the foot-grounding pass below so feet stay
// planted at y = 0 at any height.
function buildBody(shape, heightScale = 1) {
  const material = new THREE.MeshPhysicalMaterial({
    color: 0x2e3138,
    roughness: 0.42,
    metalness: 0.15,
    clearcoat: 0.9,
    clearcoatRoughness: 0.22,
    envMapIntensity: 1.15,
  });

  const group = new THREE.Group();

  // Torso: the trunk is narrower than the full shoulder-to-shoulder span —
  // the deltoid spheres and arms (below) fill out the rest of the shoulder
  // width, which reads as a rounded, sculpted silhouette rather than a
  // single wide cylinder.
  const torsoTopR = r(shape.shoulder) * 0.62;
  const profile = [
    new THREE.Vector2(r(shape.hip) * 0.8, 0.0),
    new THREE.Vector2(r(shape.hip), 0.16),
    new THREE.Vector2(r(shape.waist), 0.42),
    new THREE.Vector2(r(shape.chest), 0.62),
    new THREE.Vector2(torsoTopR, 0.74),
    new THREE.Vector2(torsoTopR * 0.55, 0.83),
  ];
  const torso = new THREE.Mesh(new THREE.LatheGeometry(profile, 40), material);
  torso.castShadow = true;
  torso.receiveShadow = true;
  group.add(torso);

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(torsoTopR * 0.5, torsoTopR * 0.58, 0.09, 16), material);
  neck.position.y = 0.87;
  neck.castShadow = true;
  group.add(neck);

  const headR = 0.115;
  const head = new THREE.Mesh(new THREE.SphereGeometry(headR, 24, 18), material);
  head.scale.set(0.92, 1.12, 0.98);
  head.position.y = 0.91 + headR * 1.05;
  head.castShadow = true;
  group.add(head);

  const shoulderX = torsoTopR + 0.05;
  const armR = Math.min(Math.max(shape.armThigh / 2 / 130, 0.032), 0.09);
  [-1, 1].forEach((mirror) => {
    const delt = new THREE.Mesh(new THREE.SphereGeometry(armR * 1.35, 14, 10), material);
    delt.position.set(mirror * shoulderX, 0.74, 0);
    delt.castShadow = true;
    group.add(delt);

    const arm = buildArm({
      upperLen: 0.34,
      upperR: armR,
      foreLen: 0.3,
      foreR: armR * 0.85,
      outAngle: 0.5,
      bendAngle: 0.35,
      mirror,
      material,
    });
    arm.position.set(mirror * shoulderX, 0.76, 0);
    group.add(arm);
  });

  const hipX = r(shape.hip) * 0.42;
  const thighR = Math.min(r(shape.thigh) * 0.62, 0.145);
  [-1, 1].forEach((mirror) => {
    const leg = buildLeg({
      hipX,
      thighLen: 0.58,
      thighR,
      calfLen: 0.52,
      calfR: thighR * 0.72,
      mirror,
      material,
      standAngle: 0.035,
    });
    group.add(leg);
  });

  group.scale.y = heightScale;

  // Settle the whole figure so its lowest point (a foot) sits at y = 0,
  // regardless of how the proportions above shift for a given shape. The
  // shift is baked into a wrapper's position (not this group's own), so that
  // later scaling the wrapper for the "pop" animation keeps the feet
  // anchored at y = 0 at every scale, not just at scale 1.
  group.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(group);
  group.position.y -= box.min.y;

  const root = new THREE.Group();
  root.add(group);
  return root;
}

function disposeGroup(group) {
  const seen = new Set();
  group.traverse((obj) => {
    if (obj.geometry) obj.geometry.dispose();
    if (obj.material && !seen.has(obj.material)) {
      seen.add(obj.material);
      obj.material.dispose();
    }
  });
}

/**
 * A rotatable 3D preview of the currently chosen body type.
 *  - Drag (mouse or touch) to spin it; it slowly auto-rotates otherwise.
 *  - Purely a visual aid — marked aria-hidden. The actual, keyboard- and
 *    screen-reader-friendly selection happens via the buttons rendered by
 *    BodyTypeVisualPicker, which is what updates `shape` here.
 */
function BodyType3D({ shape, heightScale = 1 }) {
  const containerRef = useRef(null);
  const stateRef = useRef(null);

  // One-time scene / renderer / lighting / platform / controls setup.
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return undefined;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 20);
    camera.position.set(0.5, 1.25, 4.2);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(renderer.domElement);

    // Procedural studio lighting (no image files to load) gives the glossy
    // material realistic-looking reflections.
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    const key = new THREE.DirectionalLight(0xffffff, 1.6);
    key.position.set(1.4, 2.6, 1.8);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    const lightTarget = new THREE.Object3D();
    lightTarget.position.set(0, 1.1, 0);
    scene.add(lightTarget);
    key.target = lightTarget;
    key.shadow.camera.left = -1;
    key.shadow.camera.right = 1;
    key.shadow.camera.top = 1.6;
    key.shadow.camera.bottom = -1.6;
    key.shadow.camera.near = 0.5;
    key.shadow.camera.far = 7;
    key.shadow.bias = -0.0025;
    const fill = new THREE.DirectionalLight(0xffffff, 0.35);
    fill.position.set(-1.6, 0.8, -1);
    const rim = new THREE.PointLight(0xe8283f, 0.4, 6);
    rim.position.set(-1.4, 1.2, -1.6);
    scene.add(key, fill, rim);

    // A thin glass-like platform beneath the figure's feet.
    const platform = new THREE.Mesh(
      new THREE.CylinderGeometry(0.62, 0.62, 0.035, 48),
      new THREE.MeshPhysicalMaterial({
        color: 0xdcecfb,
        transparent: true,
        opacity: 0.4,
        roughness: 0.06,
        transmission: 0.9,
        thickness: 0.06,
        ior: 1.4,
        clearcoat: 1,
        clearcoatRoughness: 0.08,
      })
    );
    platform.position.y = -0.0175;
    platform.receiveShadow = true;
    scene.add(platform);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableZoom = false;
    controls.enablePan = false;
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.rotateSpeed = 0.6;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 2.2;
    controls.minPolarAngle = Math.PI / 2 - 0.32;
    controls.maxPolarAngle = Math.PI / 2 + 0.02;
    controls.target.set(0, 1.05, 0);
    controls.update();

    let raf;
    const animate = () => {
      controls.update();
      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    };
    animate();

    const resize = () => {
      const { clientWidth: w, clientHeight: h } = container;
      if (!w || !h) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    resize();

    stateRef.current = { scene, camera, renderer, controls, group: null };

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      controls.dispose();
      if (stateRef.current?.group) disposeGroup(stateRef.current.group);
      platform.geometry.dispose();
      platform.material.dispose();
      scene.environment?.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) container.removeChild(renderer.domElement);
      stateRef.current = null;
    };
  }, []);

  // Rebuild the mannequin whenever the selected shape changes, with a small
  // "pop" so a change is felt as well as seen.
  useEffect(() => {
    const state = stateRef.current;
    if (!state || !shape) return undefined;

    if (state.group) {
      state.scene.remove(state.group);
      disposeGroup(state.group);
    }
    const group = buildBody(shape, heightScale);
    state.scene.add(group);
    state.group = group;

    let t = 0;
    let raf;
    const grow = () => {
      t += 0.08;
      group.scale.setScalar(0.9 + Math.min(t, 1) * 0.1);
      if (t < 1) raf = requestAnimationFrame(grow);
    };
    grow();

    return () => cancelAnimationFrame(raf);
  }, [shape, heightScale]);

  return <div ref={containerRef} className="authx-body3d-canvas" role="presentation" aria-hidden="true" />;
}

export default BodyType3D;

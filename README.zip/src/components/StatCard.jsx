function StatCard({ icon: Icon, label, value, unit, trend, trendDirection = "up" }) {
  return (
    <div className="stat-card">
      <div className="stat-top">
        <div className="stat-label">
          {Icon && (
            <span className="stat-icon">
              <Icon />
            </span>
          )}
          {label}
        </div>
      </div>

      <div className="stat-value">
        {value}
        {unit && <small>{unit}</small>}
      </div>

      {trend && <div className={`stat-trend ${trendDirection}`}>{trend}</div>}
    </div>
  );
}

export default StatCard;

import { Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { MemberProvider } from "./context/MemberContext";
import ProtectedRoute from "./components/ProtectedRoute";
import DashboardLayout from "./layouts/DashboardLayout";

import Login from "./pages/auth/Login";

import MemberDashboard from "./pages/member/MemberDashboard";
import Profile from "./pages/member/Profile";
import MembershipStatus from "./pages/member/MembershipStatus";
import RenewMembership from "./pages/member/RenewMembership";
import ViewWorkoutPlans from "./pages/member/ViewWorkoutPlans";
import WorkoutSchedule from "./pages/member/WorkoutSchedule";
import AttendanceHistory from "./pages/member/AttendanceHistory";

import TrainerDashboard from "./pages/trainer/TrainerDashboard";
import AssignedMembers from "./pages/trainer/AssignedMembers";
import WorkoutPrograms from "./pages/trainer/WorkoutPrograms";
import ViewPrograms from "./pages/trainer/ViewPrograms";
import UpdateWorkoutPlans from "./pages/trainer/UpdateWorkoutPlans";
import ScheduleSessions from "./pages/trainer/ScheduleSessions";
import ProgressMonitoring from "./pages/trainer/ProgressMonitoring";
import WorkoutHistory from "./pages/trainer/WorkoutHistory";
import TrainerInformation from "./pages/trainer/TrainerInformation";

import AdminDashboard from "./pages/admin/AdminDashboard";
import ManageMembers from "./pages/admin/ManageMembers";
import ManageTrainers from "./pages/admin/ManageTrainers";
import GoalsOverview from "./pages/admin/GoalsOverview";
import PaymentsOverview from "./pages/admin/PaymentsOverview";

function MemberLayout() {
  return (
      <DashboardLayout role="member" />
  );
}

function App() {
  return (
    <AuthProvider>
      <MemberProvider>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />

        {/* Standalone auth screen (no sidebar). Registration is disabled for
            now — this build uses the fixed demo accounts only. */}
        <Route path="/login" element={<Login />} />

        {/* Member / Client — only reachable once logged in as "member".
            Payments are intentionally reduced to just avail/renew — no
            record/verify/receipts/history/reports pages for this build. */}
        <Route element={<ProtectedRoute allowedRole="member" />}>
          <Route path="/member" element={<MemberLayout />}>
            <Route index element={<MemberDashboard />} />
            <Route path="dashboard" element={<MemberDashboard />} />
            <Route path="profile" element={<Profile />} />
            <Route path="membership" element={<MembershipStatus />} />
            <Route path="renew" element={<RenewMembership />} />
            <Route path="workout-plans" element={<ViewWorkoutPlans />} />
            <Route path="workout-schedule" element={<WorkoutSchedule />} />
            <Route path="attendance" element={<AttendanceHistory />} />
          </Route>
        </Route>

        {/* Trainer — only reachable once logged in as "trainer". */}
        <Route element={<ProtectedRoute allowedRole="trainer" />}>
          <Route path="/trainer" element={<DashboardLayout role="trainer" />}>
            <Route path="dashboard" element={<TrainerDashboard />} />
            <Route path="members" element={<AssignedMembers />} />
            <Route path="programs" element={<WorkoutPrograms />} />
            <Route path="view-programs" element={<ViewPrograms />} />
            <Route path="update-plans" element={<UpdateWorkoutPlans />} />
            <Route path="schedule" element={<ScheduleSessions />} />
            <Route path="progress" element={<ProgressMonitoring />} />
            <Route path="history" element={<WorkoutHistory />} />
            <Route path="information" element={<TrainerInformation />} />
          </Route>
        </Route>

        {/* Admin — only reachable once logged in as "admin */}
        <Route element={<ProtectedRoute allowedRole="admin" />}>
          <Route path="/admin" element={<DashboardLayout role="admin" />}>
            <Route path="dashboard" element={<AdminDashboard />} />
            <Route path="members" element={<ManageMembers />} />
            <Route path="trainers" element={<ManageTrainers />} />
            <Route path="goals" element={<GoalsOverview />} />
            <Route path="payments" element={<PaymentsOverview />} />
          </Route>
        </Route>

        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
      </MemberProvider>
    </AuthProvider>
  );
}

export default App;

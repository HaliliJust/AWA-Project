import { ExerciseSummary } from "../../components/ExerciseEditor";
import { useState } from "react";
import PageHead from "../../components/PageHead";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import useTrainerData from "../../context/useTrainerData";
import TrainerEmptyState from "../../components/TrainerEmptyState";
import MemberDetails from "../../components/MemberDetails";

function ViewPrograms() {
  const { clients, programs: workoutPrograms } = useTrainerData();
  const [selectedId, setSelectedId] = useState(workoutPrograms[0]?.id || null);
  const selected = workoutPrograms.find((p) => p.id === selectedId);

  if (!clients.length) return <><PageHead eyebrow="Programs" title="View Programs" description="View confirmed workouts for your clients." /><TrainerEmptyState /></>;
  const member = selected && clients.find(m => m.username === selected.memberUsername);

  return (
    <>
      <PageHead
        eyebrow="Programs"
        title="View Programs"
        description="Browse every workout program you've created, across all members."
      />

      <div className="split">
        <div className="card">
          <div className="card-head">
            <h3>All Programs</h3>
          </div>
          <DataTable
            columns={["", "Program", "Member", "Level", "Duration", "Status"]}
            rows={workoutPrograms}
            renderRow={(p) => (
              <tr key={p.id}>
                <td>
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    onClick={() => setSelectedId(p.id)}
                  >
                    View
                  </button>
                </td>
                <td className="cell-primary">{p.name}</td>
                <td>{p.member}</td>
                <td>{p.level}</td>
                <td>{p.duration}</td>
                <td><Badge status={p.status} /></td>
              </tr>
            )}
          />
        </div>

        <div className="card">
          {selected ? (
            <>
              <div className="card-head">
                <h3>{selected.name}</h3>
                <Badge status={selected.status} />
              </div>
              <ExerciseSummary plan={selected} />
              <div className="info-list">
                <li><span>Member</span><span>{selected.member}</span></li>
                <li><span>Level</span><span>{selected.level}</span></li>
                <li><span>Duration</span><span>{selected.duration}</span></li>
                <li><span>Exercises</span><span>{selected.exercises}</span></li>
                <li><span>Sets</span><span>{selected.sets}</span></li>
                <li><span>Repetitions</span><span>{selected.reps}</span></li>
                <li><span>Rest Time</span><span>{selected.restTime}</span></li>
                <li><span>Schedule</span><span>{selected.schedule}</span></li>
              </div>
            </>
          ) : (
            <div className="empty-state">
              <h4>No program selected</h4>
              <p>Choose a program from the list to see its full details here.</p>
            </div>
          )}
        </div>
      </div>
      {member && <section className="card section-gap"><MemberDetails member={member} /></section>}
    </>
  );
}

export default ViewPrograms;

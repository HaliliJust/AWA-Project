import PageHead from '../../components/PageHead';
import TrainerEmptyState from '../../components/TrainerEmptyState';
import useTrainerData from '../../context/useTrainerData';
import { weeklySummary } from '../../services/memberStore';

export default function ProgressMonitoring() {
  const { clients } = useTrainerData();
  return <><PageHead eyebrow="Coaching" title="Progress Monitoring" description="Workout completion recorded for your current clients." />
    {!clients.length ? <TrainerEmptyState /> : <div className="grid grid-2">{clients.map(m => {
      const days = weeklySummary(m.sessions);
      const total = days.reduce((sum, d) => sum + d.sessions.length, 0);
      const done = days.reduce((sum, d) => sum + d.completed, 0);
      return <section className="card" key={m.username}><h3>{m.profile.name}</h3><p>{m.profile.fitnessGoal || 'No goal provided'}</p>
        <label htmlFor={`progress-${m.username}`}>{done} of {total} sessions completed this week</label>
        <progress id={`progress-${m.username}`} max={total || 1} value={done} />
        <ul className="info-list">{days.map(d => <li key={d.date}><span>{d.label}</span><span>{d.completed} completed · {d.duration} min</span></li>)}</ul>
      </section>;
    })}</div>}
  </>;
}

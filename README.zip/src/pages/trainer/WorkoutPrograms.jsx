import PageHead from "../../components/PageHead";
import FormField from "../../components/FormField";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import useTrainerData from "../../context/useTrainerData";
import TrainerEmptyState from "../../components/TrainerEmptyState";

function WorkoutPrograms() {
  const { clients, programs: workoutPrograms } = useTrainerData();
  const assignedMembers = clients.map(m => ({ id: m.username, name: m.profile.name }));
  if (!clients.length) return <><PageHead eyebrow="Programs" title="Workout Programs" description="Create and manage programs for your assigned clients." /><TrainerEmptyState /></>;
  return (
    <>
      <PageHead
        eyebrow="Programs"
        title="Create Workout Programs"
        description="Design a personalized workout plan for a member."
      />

      <div className="split" style={{ marginBottom: 24 }}>
        <div className="card">
          <div className="card-head">
            <h3>New Program</h3>
          </div>
          <form className="form-grid" onSubmit={(e) => e.preventDefault()}>
            <FormField label="Program Name" placeholder="e.g. Upper Body Hypertrophy" full />
            <FormField
              label="Assign to Member"
              type="select"
              options={assignedMembers.map((m) => m.name)}
            />
            <FormField
              label="Difficulty Level"
              type="select"
              options={["Beginner", "Intermediate", "Advanced"]}
            />
            <FormField label="Duration (weeks)" type="number" placeholder="6" />
            <FormField
              label="Sessions / Week"
              type="select"
              options={["2", "3", "4", "5"]}
            />
            <FormField
              label="Exercises"
              type="textarea"
              full
              placeholder="e.g. Back Squat, Romanian Deadlift, Walking Lunges, Leg Press"
              hint="List each exercise in this routine, separated by commas."
            />
            <FormField label="Sets" type="number" placeholder="4" />
            <FormField label="Repetitions" type="number" placeholder="10" />
            <FormField label="Rest Time" placeholder="e.g. 60 sec" />
            <FormField label="Schedule" placeholder="e.g. Mon, Wed, Fri · 6:00 AM" hint="Which days/time this program runs." />
            <button type="submit" className="btn btn-primary field full">Save Program</button>
          </form>
        </div>

        <div className="card">
          <div className="card-head">
            <h3>Quick Tips</h3>
          </div>
          <div className="info-list">
            <li><span>Beginner</span><span>2–3 sessions / wk</span></li>
            <li><span>Intermediate</span><span>3–4 sessions / wk</span></li>
            <li><span>Advanced</span><span>4–5 sessions / wk</span></li>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Existing Programs</h3>
        </div>
        <DataTable
          columns={["Program", "Member", "Level", "Duration", "Status", ""]}
          rows={workoutPrograms}
          renderRow={(p) => (
            <tr key={p.id}>
              <td className="cell-primary">{p.name}</td>
              <td>{p.member}</td>
              <td>{p.level}</td>
              <td>{p.duration}</td>
              <td><Badge status={p.status} /></td>
              <td><button type="button" className="btn btn-ghost btn-sm">Edit</button></td>
            </tr>
          )}
        />
      </div>
    </>
  );
}

export default WorkoutPrograms;

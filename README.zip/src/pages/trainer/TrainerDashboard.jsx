import { Link } from 'react-router-dom';
import { Users, ClipboardList, CalendarClock, CalendarCheck } from 'lucide-react';
import PageHead from '../../components/PageHead';
import StatCard from '../../components/StatCard';
import Badge from '../../components/Badge';
import useTrainerData from '../../context/useTrainerData';
import TrainerEmptyState from '../../components/TrainerEmptyState';
import { localDate } from '../../services/memberStore';
export default function TrainerDashboard() {
  const { clients: members, requests, programs: sessions } = useTrainerData();
  const today = sessions.filter(s => s.date === localDate()).sort((a, b) => a.time.localeCompare(b.time));
  return <><PageHead eyebrow="Trainer" title="Today's Schedule" description="Your member requests and confirmed sessions." />{members.length > 0 ? <div className="grid grid-4 section-bottom"><StatCard icon={Users} label="Assigned Members" value={members.length} /><StatCard icon={ClipboardList} label="Pending Requests" value={requests.length} /><StatCard icon={CalendarClock} label="Sessions Today" value={today.length} /><StatCard icon={CalendarCheck} label="Completed Sessions" value={sessions.filter(s => s.status === 'Completed').length} /></div> : <TrainerEmptyState />}<div className="split section-gap"><section className="card"><h3>Daily Schedule</h3>{today.length ? today.map(s => <article className="session-item" key={s.id}><h4>{s.time} · {s.member}</h4><p>{s.program} · {s.duration}</p><Badge status={s.status} /></article>) : <p>No sessions today.</p>}</section><section className="card"><h3>Workout Requests</h3><p>{requests.length} requests awaiting your response.</p><Link className="btn btn-primary" to="/trainer/schedule">Review Requests and Schedules</Link></section></div></>;
}

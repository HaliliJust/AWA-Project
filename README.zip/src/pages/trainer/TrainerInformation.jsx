import { useState } from "react";
import { Award, Phone } from "lucide-react";
import ProfilePhotoUpload from "../../components/ProfilePhotoUpload";
import { fileToCompressedDataURL } from "../../services/imageTools";
import { useAuth } from "../../context/AuthContext";
import { getAccount } from "../../services/accountStore";
import PageHead from "../../components/PageHead";
import DigitalCard from "../../components/DigitalCard";
import Badge from "../../components/Badge";
import { currentTrainer } from "../../data/mockData";

function TrainerInformation() {
  const { user } = useAuth();
  const account = getAccount(user.username);
  const storageKey = `smartfit.trainer-profile.${user.username}`;
  const [draft, setDraft] = useState(() => {
    try { const saved = localStorage.getItem(storageKey); if (saved) return JSON.parse(saved); } catch {}
    return {
    name: user.name || currentTrainer.name,
    email: account?.email || (user.username === "trainer001" ? currentTrainer.email : ""),
    phone: account?.contactNumber || (user.username === "trainer001" ? currentTrainer.phone : ""),
    specialty: account?.specialty || currentTrainer.specialty,
    certification: account?.certifications || currentTrainer.certification,
    experience: account?.experience || currentTrainer.experience,
    status: currentTrainer.status,
    photo: "",
    };
  });

  const [saved, setSaved] = useState(draft);
  const [photoError, setPhotoError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [notice, setNotice] = useState("");

  function handleChange(field) {
    return (e) => setDraft((prev) => ({ ...prev, [field]: e.target.value }));
  }

  async function handlePhotoChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 2 * 1024 * 1024) { setPhotoError('Choose a JPG, PNG or WebP image under 2 MB.'); return; }
    setUploading(true);
    try { const photo = await fileToCompressedDataURL(file, { maxDim: 480 }); setDraft(prev => ({ ...prev, photo })); setPhotoError(''); }
    catch (error) { setPhotoError(error.message); }
    finally { setUploading(false); }
  }

  function handleSave(e) {
    e.preventDefault();
    try {
      localStorage.setItem(storageKey, JSON.stringify(draft));
      setSaved(draft);
      setNotice("Trainer information saved.");
    } catch { setNotice("Unable to save trainer information. Browser storage may be full."); }
  }

  return (
    <>
      <PageHead
        eyebrow="Trainer"
        title="Trainer Information"
        description="All information on file for your trainer account."
      />

      <div className="split">
        <div className="card">
          <div className="card-head">
            <h3>Profile Details</h3>
            <Badge status={draft.status} />
          </div>

          <form className="form-grid" onSubmit={handleSave}>
            <ProfilePhotoUpload value={draft.photo} name={draft.name} onChange={handlePhotoChange} busy={uploading} error={photoError} />
            <p className="field full" role="status">{notice}</p>

            <div className="field">
              <label htmlFor="trainer-name">Full Name</label>
              <input type="text" id="trainer-name" value={draft.name} onChange={handleChange("name")} />
            </div>
            <div className="field">
              <label htmlFor="trainer-email">Email</label>
              <input type="email" id="trainer-email" value={draft.email} onChange={handleChange("email")} />
            </div>
            <div className="field">
              <label htmlFor="trainer-phone">Phone</label>
              <input type="text" id="trainer-phone" value={draft.phone} onChange={handleChange("phone")} />
            </div>
            <div className="field">
              <label htmlFor="trainer-specialty">Specialty</label>
              <input type="text" id="trainer-specialty" value={draft.specialty} onChange={handleChange("specialty")} />
            </div>
            <div className="field">
              <label htmlFor="trainer-certification">Certification</label>
              <input type="text" id="trainer-certification" value={draft.certification} onChange={handleChange("certification")} />
            </div>
            <div className="field">
              <label htmlFor="trainer-experience">Experience</label>
              <input type="text" id="trainer-experience" value={draft.experience} onChange={handleChange("experience")} />
            </div>
            <div className="field">
              <label htmlFor="trainer-status">Status</label>
              <select id="trainer-status" value={draft.status} onChange={handleChange("status")}>
                {["Active", "On Leave", "Inactive"].map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            <div className="field full">
              <span className="field-hint">Trainer ID: {currentTrainer.trainerId} · Joined {currentTrainer.joinDate}</span>
            </div>

            <button type="submit" disabled={uploading} className="btn btn-primary field full">Save Changes</button>
          </form>
        </div>

        <div className="card">
          <div className="card-head">
            <h3>Digital Trainer Card</h3>
          </div>
          <DigitalCard
            roleLabel="TRAINER"
            name={saved.name}
            idNumber={currentTrainer.trainerId}
            idLabel="TRAINER ID"
            tier={saved.specialty}
            status={saved.status}
            sinceLabel="TRAINER SINCE"
            since={currentTrainer.joinDate}
            validThru={currentTrainer.membershipExpiry}
            metaLeftIcon={Award}
            metaLeftValue={saved.certification.split(",")[0]}
            metaRightIcon={Phone}
            metaRightValue={saved.phone}
            avatarImage={saved.photo}
            footerNote="This card is property of SmartfIT and identifies an authorized staff trainer. If found, please return to any SmartfIT front desk."
          />
        </div>
      </div>

    </>
  );
}

export default TrainerInformation;

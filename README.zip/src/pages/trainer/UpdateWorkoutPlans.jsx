import { useState } from "react";
import PageHead from "../../components/PageHead";
import FormField from "../../components/FormField";
import useTrainerData from "../../context/useTrainerData";
import TrainerEmptyState from "../../components/TrainerEmptyState";

function initials(name) {
  return name.split(" ").map((n) => n[0]).join("").slice(0, 2);
}

function UpdateWorkoutPlans() {
  const { clients, programs: workoutPrograms } = useTrainerData();
  const assignedMembers = clients.map(m => ({id: m.username, name: m.profile.name}));
  const [selectedId, setSelectedId] = useState(assignedMembers[0]?.id || null);
  const selectedClient = assignedMembers.find((m) => m.id === selectedId) || assignedMembers[0];
  const activeProgram =
    workoutPrograms.find((p) => p.member === selectedClient?.name) || workoutPrograms[0];

  if (!clients.length) return <><PageHead eyebrow="Programs" title="Update Workout Programs" description="Manage programs for your assigned clients." /><TrainerEmptyState /></>;

  return (
    <>
      <PageHead
        eyebrow="Programs"
        title="Update Workout Programs"
        description="Pick a client to view or change their existing workout program."
      />

      <div className="split">
        <div className="card">
          <div className="card-head">
            <h3>All Clients</h3>
          </div>
          <div className="info-list">
            {assignedMembers.map((m) => (
              <li
                key={m.id}
                style={{ cursor: "pointer", ...(m.id === selectedId ? { borderColor: "var(--accent)" } : {}) }}
                onClick={() => setSelectedId(m.id)}
              >
                <span>
                  <div className="member-row">
                    <span className="mini-avatar">{initials(m.name)}</span>
                    <div>
                      <div className="cell-primary">{m.name}</div>
                      <div className="cell-sub">{m.id}</div>
                    </div>
                  </div>
                </span>
                <span>
                  <button type="button" className="btn btn-ghost btn-sm">
                    {m.id === selectedId ? "Selected" : "Select"}
                  </button>
                </span>
              </li>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <h3>Editing: {activeProgram?.name || "No Program Yet"}</h3>
          </div>
          <form className="form-grid" key={selectedId} onSubmit={(e) => e.preventDefault()}>
            <FormField label="Program Name" defaultValue={activeProgram?.name} full />
            <FormField label="Assign to Member" type="select" options={assignedMembers.map((m) => m.name)} defaultValue={selectedClient?.name} />
            <FormField
              label="Difficulty Level"
              type="select"
              options={["Beginner", "Intermediate", "Advanced"]}
              defaultValue={activeProgram?.level}
            />
            <FormField label="Session Duration (minutes)" defaultValue={activeProgram?.duration?.split(" ")[0] || "60"} />
            <FormField
              label="Sessions / Week"
              type="select"
              options={["2", "3", "4", "5"]}
            />
            <FormField
              label="Status"
              type="select"
              options={["Scheduled", "Missed", "Completed"]}
              defaultValue={activeProgram?.status}
            />
            <FormField
              label="Exercises"
              type="textarea"
              full
              defaultValue={activeProgram?.exercises}
              placeholder="e.g. Back Squat, Romanian Deadlift, Walking Lunges, Leg Press"
            />
            <FormField label="Sets" type="number" defaultValue={activeProgram?.sets} />
            <FormField label="Repetitions" type="number" defaultValue={activeProgram?.reps} />
            <FormField label="Rest Time" defaultValue={activeProgram?.restTime} />
            <FormField label="Schedule" defaultValue={activeProgram?.schedule} />
            <div className="field full btn-row">
              <button type="submit" className="btn btn-primary">Save Updates</button>
              <button type="button" className="btn btn-ghost">Discard</button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}

export default UpdateWorkoutPlans;

import { useState } from "react";
import PageHead from "../../components/PageHead";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import useTrainerData from "../../context/useTrainerData";
import TrainerEmptyState from "../../components/TrainerEmptyState";
import MemberDetails from "../../components/MemberDetails";

function WorkoutHistory() {
  const { clients, programs } = useTrainerData();
  const workoutHistory = programs.filter(p => p.status === "Completed").map(p => ({...p, completedOn: p.date, result: p.status}));
  const [selectedId, setSelectedId] = useState(null);
  const selected = workoutHistory.find((w) => w.id === selectedId);

  if (!clients.length) return <><PageHead eyebrow="Programs" title="Workout History" description="Previously completed workouts for your clients." /><TrainerEmptyState /></>;
  const member = selected && clients.find(m => m.username === selected.memberUsername);

  return (
    <>
      <PageHead
        eyebrow="Programs"
        title="Workout History"
        description="View previously assigned workout plans."
      />

      <div className="card" style={{ marginBottom: selected ? 20 : 0 }}>
        <DataTable
          columns={["", "Program", "Member", "Completed On", "Result"]}
          rows={workoutHistory}
          renderRow={(w) => (
            <tr key={w.id}>
              <td>
                <button
                  type="button"
                  className="btn btn-ghost btn-sm"
                  onClick={() => setSelectedId(w.id)}
                >
                  View
                </button>
              </td>
              <td className="cell-primary">{w.name}</td>
              <td>{w.member}</td>
              <td>{w.completedOn}</td>
              <td><Badge status={w.result} /></td>
            </tr>
          )}
        />
      </div>

      {selected && (
        <div className="card">
          <div className="card-head">
            <h3>Finished Program</h3>
            <Badge status={selected.result} />
          </div>
          <div className="info-list">
            <li><span>Program</span><span>{selected.name}</span></li>
            <li><span>Member</span><span>{selected.member}</span></li>
            <li><span>Completed On</span><span>{selected.completedOn}</span></li>
            <li><span>Exercises</span><span>{selected.exercises}</span></li>
            <li><span>Sets</span><span>{selected.sets}</span></li>
            <li><span>Repetitions</span><span>{selected.reps}</span></li>
            <li><span>Rest Time</span><span>{selected.restTime}</span></li>
            <li><span>Trainer Notes</span><span>{selected.notes}</span></li>
          </div>
        </div>
      )}
      {member && <section className="card section-gap"><MemberDetails member={member} /></section>}
    </>
  );
}

export default WorkoutHistory;

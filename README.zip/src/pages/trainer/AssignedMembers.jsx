import { useEffect, useRef, useState } from 'react';
import PageHead from '../../components/PageHead';
import MemberDetails from '../../components/MemberDetails';
import TrainerEmptyState from '../../components/TrainerEmptyState';
import useTrainerData from '../../context/useTrainerData';

export default function AssignedMembers() {
  const { clients } = useTrainerData();
  const [selectedId, setSelectedId] = useState(null);
  const details = useRef(null), trigger = useRef(null);
  const selected = clients.find(m => m.username === selectedId);
  useEffect(() => { if (selectedId) details.current?.focus(); }, [selectedId]);
  return <>
    <PageHead eyebrow="Coaching" title="Assigned Members" description="Members with active memberships and confirmed workouts with you." />
    {!clients.length ? <TrainerEmptyState /> : <section className="card">
      <div className="table-wrap"><table><thead><tr>{['Member', 'Membership', 'Goal', 'Workouts Completed', 'Details'].map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
        <tbody>{clients.map(m => <tr key={m.username}>
          <td className="cell-primary">{m.profile.name}</td><td>{m.membership.plan}</td><td>{m.profile.fitnessGoal || 'Not provided'}</td>
          <td>{m.sessions.filter(s => s.status === 'Completed').length}</td>
          <td><button className="btn btn-ghost btn-sm" aria-label={`View ${m.profile.name}`} aria-expanded={selectedId === m.username} aria-controls="client-details" onClick={e => { trigger.current = e.currentTarget; setSelectedId(m.username); }}>View</button></td>
        </tr>)}</tbody></table></div>
    </section>}
    {selected && <section className="card section-gap" id="client-details" tabIndex={-1} ref={details} aria-label={`${selected.profile.name} details`}>
      <MemberDetails member={selected} />
      <button className="btn btn-ghost section-gap" onClick={() => { setSelectedId(null); trigger.current?.focus(); }}>Close Details</button>
    </section>}
  </>;
}

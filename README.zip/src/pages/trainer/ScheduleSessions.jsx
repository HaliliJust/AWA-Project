import ExerciseEditor, { ExerciseSummary, planExercises } from '../../components/ExerciseEditor';
import { useState } from 'react';
import MemberDetails from '../../components/MemberDetails';
import PageHead from '../../components/PageHead';
import Badge from '../../components/Badge';
import { useAuth } from '../../context/AuthContext';
import { useMember } from '../../context/MemberContext';
import { hoursFor, localDate } from '../../services/memberStore';
function Request({
  memberId,
  member,
  request: r,
  respond
}) {
  const [alternative, setAlternative] = useState(false),
    [date, setDate] = useState(r.date);
  const [exercises, setExercises] = useState(planExercises(r));
  function submit(e) {
    e.preventDefault();
    const f = new FormData(e.target);
    if (respond(memberId, r.id, 'Proposed', {
      date,
      time: f.get('time'),
      program: f.get('program'),
      notes: f.get('notes'),
      exerciseItems: exercises,
      exercises: exercises.map(e => e.name).join(', ')
    })) setAlternative(false);
  }
  return <article className="card"><h3>{member.profile.name} · {r.program}</h3><p>{r.date} at {r.time} · {r.duration} minutes</p><Badge status={r.status} /><ExerciseSummary plan={r} />{r.notes && <p>Notes: {r.notes}</p>}<details className="request-member-details"><summary>View Member Information</summary><MemberDetails member={member} /></details>{r.status === 'Pending' && <><div className="btn-row"><button className="btn btn-primary" onClick={() => respond(memberId, r.id, 'Accepted')}>Accept</button><button className="btn btn-ghost" onClick={() => respond(memberId, r.id, 'Denied')}>Deny</button><button className="btn btn-ghost" onClick={() => setAlternative(!alternative)}>Suggest Alternative</button></div>{alternative && <form className="form-grid section-gap" onSubmit={submit}><label className="field">Suggested plan name<input name="program" required defaultValue={r.program} /></label><label className="field">Suggestion notes<textarea name="notes" defaultValue={r.notes || ""} /></label><ExerciseEditor value={exercises} onChange={setExercises} /><label className="field">Alternative Date<input required type="date" min={localDate()} value={date} onChange={e => setDate(e.target.value)} /></label><label className="field">Alternative Time<input required name="time" defaultValue={r.time} type="time" min={hoursFor(date).min} max={hoursFor(date).max} /></label><p className="field full">Weekdays 8 AM–9 PM; weekends 7 AM–10 PM. Sessions must end by closing.</p><button className="btn btn-primary">Send Alternative</button></form>}</>}</article>;
}
export default function ScheduleSessions() {
  const {
      user
    } = useAuth(),
    {
      database,
      respond
    } = useMember();
  const requests = Object.entries(database.members).flatMap(([id, m]) => m.workoutRequests.filter(r => r.trainerId === user.username).map(r => ({
    id,
    m,
    r
  })));
  const sessions = Object.entries(database.members).flatMap(([id, m]) => m.workoutSchedule.filter(s => s.trainerId === user.username).map(s => ({
    ...s,
    member: m.profile.name
  }))).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  return <><PageHead eyebrow="Scheduling" title="Schedule Sessions" description="Review member requests, confirm sessions, or propose an available alternative." /><h3>Workout Requests</h3><div className="grid section-gap">{requests.length ? requests.map(({
        id,
        m,
        r
      }) => <Request key={r.id + r.submittedAt} memberId={id} member={m} request={r} respond={respond} />) : <p className="card">No workout requests yet.</p>}</div><section className="card section-gap"><h3>Training Schedule</h3>{sessions.length ? <div className="table-wrap"><table><thead><tr>{['Member', 'Program', 'Date', 'Time', 'Duration', 'Status'].map(h => <th key={h} scope="col">{h}</th>)}</tr></thead><tbody>{sessions.map(s => <tr key={s.id}><td>{s.member}</td><td>{s.program}</td><td>{s.date}</td><td>{s.time}</td><td>{s.duration} min</td><td><Badge status={s.status} /></td></tr>)}</tbody></table></div> : <p>No sessions confirmed yet.</p>}</section></>;
}

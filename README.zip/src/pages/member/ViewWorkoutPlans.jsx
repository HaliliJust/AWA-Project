import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Dumbbell, Plus } from 'lucide-react';
import PageHead from '../../components/PageHead';
import ExerciseEditor, { ExerciseSummary, planExercises } from '../../components/ExerciseEditor';
import { workoutPrograms } from '../../data/mockData';
import { useMember } from '../../context/MemberContext';
import { hoursFor, localDate, uid } from '../../services/memberStore';

function draft(plan = {}) {
  return { ...plan, name: plan.program || plan.name || '', goal: plan.goal || 'General Fitness', level: plan.level || 'Beginner', notes: plan.notes || '', exerciseItems: planExercises(plan) };
}
export default function ViewWorkoutPlans() {
  const { state, trainers, addWorkoutRequest, savePersonalPlan } = useMember();
  const [params] = useSearchParams();
  const initialRequest = state.workoutRequests.find(r => r.id === params.get('request') && ['Pending', 'Denied'].includes(r.status));
  const initial = initialRequest || workoutPrograms.find(p => p.id === params.get('plan'));
  const [selected, setSelected] = useState(() => initial ? draft(initial) : null);
  const [requestId, setRequestId] = useState(initialRequest?.id || '');
  const [date, setDate] = useState(initialRequest?.date || '');
  const [notice, setNotice] = useState('');
  if (!state.membership.active) return <div className="card"><h2>Subscribe to access workout plans.</h2><p>An active membership is required to request a trainer and workout schedule.</p><Link className="btn btn-primary" to="/member/renew">Subscribe or Renew Membership</Link></div>;
  function choose(plan) { setSelected(draft(plan)); setRequestId(''); setDate(''); setNotice(''); }
  function change(key, value) { setSelected(p => ({ ...p, [key]: value })); setNotice(''); }
  function submit(e) {
    e.preventDefault();
    const form = new FormData(e.target);
    const plan = { ...selected, exercises: selected.exerciseItems.map(e => e.name).join(', ') };
    if (e.nativeEvent.submitter?.value === 'save') {
      const id = state.personalPlans.some(p => p.id === selected.id) ? selected.id : uid();
      if (savePersonalPlan({ ...plan, id })) { setSelected(p => ({ ...p, id })); setNotice('Personal plan saved. You can reuse it or send it to a trainer.'); }
      return;
    }
    if (addWorkoutRequest({ ...plan, program: plan.name, planId: plan.id, requestId, trainerId: form.get('trainer'), date, time: form.get('time'), duration: Number(form.get('duration')) })) {
      setSelected(null); setRequestId(''); setNotice('Request sent. Your trainer can accept, decline or suggest changes.');
    }
  }
  const hours = hoursFor(date);
  function card(plan, personal = false) {
    return <article className="card workout-plan-card" key={plan.id}><span className="badge">{personal ? 'Your personal plan' : plan.level}</span><h3>{plan.name}</h3><p>{plan.goal} · {plan.duration || 'Custom session'}</p><ExerciseSummary plan={plan} /><button className="btn btn-primary btn-block" onClick={() => choose(plan)}>Customize & choose</button></article>;
  }
  return <><PageHead eyebrow="Your training" title="Workout Plans" description="Start with a program or build your own routine. Customize every exercise and send it to your trainer." />
    <p role="status">{notice}</p>
    <section className="card workout-builder-banner"><div><Dumbbell size={28} /><h2>Train your way</h2><p>Choose exercises, sets, reps and recovery time. Keep your favorite routines in one place.</p></div><button className="btn btn-primary" onClick={() => choose()}><Plus size={16} /> Create personal plan</button></section>
    {selected && <section className="card section-gap" aria-label="Workout plan editor"><h2>{requestId ? 'Edit & resend request' : 'Build your workout'}</h2><form key={requestId || selected.id || 'new'} className="form-grid" onSubmit={submit}>
      <label className="field">Plan name<input required maxLength={100} value={selected.name} onChange={e => change('name', e.target.value)} placeholder="My full body routine" /></label>
      <label className="field">Fitness goal<input required value={selected.goal} onChange={e => change('goal', e.target.value)} /></label>
      <label className="field">Level<select value={selected.level} onChange={e => change('level', e.target.value)}>{['Beginner', 'Intermediate', 'Advanced'].map(l => <option key={l}>{l}</option>)}</select></label>
      <label className="field">Notes for your trainer<textarea value={selected.notes} onChange={e => change('notes', e.target.value)} placeholder="Preferences, equipment or changes you want to discuss" /></label>
      <ExerciseEditor value={selected.exerciseItems} onChange={v => change('exerciseItems', v)} />
      <div className="field full"><button className="btn btn-ghost" type="submit" value="save" formNoValidate>Save personal plan</button></div>
      <h3 className="field full">Send for trainer review</h3>
      <label className="field">Trainer<select name="trainer" required defaultValue={selected.trainerId || ''}><option value="" disabled>Select a trainer</option>{trainers.map(t => <option key={t.username} value={t.username}>{t.name}</option>)}</select></label>
      <label className="field">Date<input type="date" required min={localDate()} value={date} onChange={e => setDate(e.target.value)} /></label>
      <label className="field">Time<input name="time" type="time" required min={hours.min} max={hours.max} defaultValue={selected.time || ''} /><span className="field-hint">Session must fit within {hours.min}–{hours.max}.</span></label>
      <label className="field">Session duration<select name="duration" defaultValue={Number(selected.duration) || 60}><option value="30">30 minutes</option><option value="60">60 minutes</option><option value="90">90 minutes</option></select></label>
      {!trainers.length && <p className="field full">No active trainers available. You can still save your personal plan.</p>}
      <div className="btn-row field full"><button className="btn btn-primary" disabled={!trainers.length} value="send">{requestId ? 'Resend to trainer' : 'Send to trainer'}</button><button type="button" className="btn btn-ghost" onClick={() => setSelected(null)}>Cancel</button></div>
    </form></section>}
    <h2 className="section-gap">My personal plans</h2><div className="grid grid-3">{state.personalPlans?.length ? state.personalPlans.map(p => card(p, true)) : <p>Create and save a routine to see it here.</p>}</div>
    <h2 className="section-gap">Explore programs</h2><div className="grid grid-3">{workoutPrograms.map(p => card(p))}</div>
    <section className="card section-gap"><h2>Sent for review</h2>{state.workoutRequests.length ? [...state.workoutRequests].reverse().map(r => <article className="session-item" key={r.id}><h3>{r.program}</h3><p>{r.trainer} · {r.date} at {r.time} · {r.status}</p><ExerciseSummary plan={r} />{['Pending', 'Denied'].includes(r.status) && <button className="btn btn-ghost" onClick={() => { setSelected(draft(r)); setRequestId(r.id); setDate(r.date); setNotice(''); }}>Edit & resend</button>}{r.status === 'Proposed' && <Link to="/member/workout-schedule">Review trainer suggestion</Link>}</article>) : <p>No requests sent yet.</p>}</section>
  </>;
}

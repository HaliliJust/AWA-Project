import { profileMeasurements } from "../../utils/bodyMeasurements";
import { useState } from "react";
import ProfilePhotoUpload from "../../components/ProfilePhotoUpload";
import PageHead from "../../components/PageHead";
import FormField from "../../components/FormField";
import DigitalCard from "../../components/DigitalCard";
import MeasurementMannequin from "../../components/MeasurementMannequin";
import { fileToCompressedDataURL } from "../../services/imageTools";
import { useMember } from "../../context/MemberContext";

function Profile() {
  const { state, updateProfile } = useMember();
  const profile = state.profile;
  const savedBody = () => ({ height: parseFloat(profile.height) || 170, weight: parseFloat(profile.weight) || 65, bodyType: profile.bodyType });
  const [body, setBody] = useState(savedBody);
  const [measurements, setMeasurements] = useState(profile.measurements || profileMeasurements(profile));
  function changeBody(key, value) {
    const next = { ...body, [key]: value };
    setBody(next);
    setMeasurements(profileMeasurements(next));
    setNotice("");
  }
  const [avatarPreview, setAvatarPreview] = useState(profile.avatar || "");
  const [errors, setErrors] = useState({});
  const [notice, setNotice] = useState("");
  const [formKey, setFormKey] = useState(0);
  const [uploading, setUploading] = useState(false);

  async function handleAvatarChange(e) {
    const file = e.target.files[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 2 * 1024 * 1024) { setErrors({avatar: 'Choose a JPG, PNG or WebP image under 2 MB.'}); return; }
    setUploading(true);
    try { setAvatarPreview(await fileToCompressedDataURL(file, {maxDim: 480})); setErrors({}); }
    catch (error) { setErrors({avatar: error.message}); }
    finally { setUploading(false); }
  }

  function handleSubmit(e) {
    e.preventDefault();
    const form = new FormData(e.target);
    const data = {
      name: form.get("name"),
      email: form.get("email"),
      contact: form.get("contact"),
      dob: form.get("dob"),
      gender: form.get("gender"),
      ...body,
      measurements,
      fitnessGoal: form.get("fitnessGoal"),
      address: form.get("address"),
      emergencyName: form.get("emergencyName"),
      emergencyContact: form.get("emergencyContact"),
    };
    if (!avatarPreview) { setErrors({avatar: "Profile picture is required."}); return; }
    if (updateProfile({...data, avatar: avatarPreview})) setNotice("Profile, body measurements and 3D preview saved.");
  }

  return (
    <>
      <PageHead
        eyebrow="Account"
        title="Update Profile"
        description="Edit your personal information and account details."
      />

      <div className="split">
        <div className="card">
          <div className="card-head">
            <h3>Personal Information</h3>
          </div>
          <form key={formKey} className="form-grid" onSubmit={handleSubmit}>
            <p role="status" className="field full">{notice}</p>
            <ProfilePhotoUpload value={avatarPreview} name={profile.name} required onChange={handleAvatarChange} busy={uploading} error={errors.avatar} />

            <FormField label="Full Name" name="name" required defaultValue={profile.name} />
            <FormField label="Email Address" name="email" required type="email" defaultValue={profile.email} />
            <FormField label="Contact Number" name="contact" placeholder="09XX XXX XXXX" defaultValue={profile.contact} />
            <FormField label="Date of Birth" name="dob" type="date" defaultValue={profile.dob} />
            <FormField label="Gender" name="gender" type="select" options={["Female", "Male", "Prefer not to say"]} defaultValue={profile.gender} />
            <FormField label="Height (cm)" name="height" type="number" required min="145" max="210" value={body.height} onChange={e => changeBody("height", e.target.value)} />
            <FormField label="Weight (kg)" name="weight" type="number" required min="1" max="500" step="0.1" value={body.weight} onChange={e => changeBody("weight", e.target.value)} />
            <FormField
              label="Body Type"
              name="bodyType"
              type="select"
              options={["Ectomorph", "Mesomorph", "Endomorph"]}
              value={body.bodyType} onChange={e => changeBody("bodyType", e.target.value)}
            />
            <FormField
              label="Fitness Goal"
              name="fitnessGoal"
              type="select"
              options={["Weight Loss", "Muscle Gain", "Endurance", "General Fitness"]}
              defaultValue={profile.fitnessGoal}
            />
            <FormField label="Address" name="address" type="textarea" full placeholder="Street, City, Province" defaultValue={profile.address} />
            <FormField label="Emergency Contact Person" name="emergencyName" defaultValue={profile.emergencyName} />
            <FormField label="Emergency Contact Number" name="emergencyContact" placeholder="09XX XXX XXXX" defaultValue={profile.emergencyContact} />

            <div className="field full">
              <p className="field-hint">Height, weight and body type update the estimated preview. Correct the measurements below with your own measurements before saving.</p>
              <MeasurementMannequin value={measurements} onChange={next => { setMeasurements(next); setBody(prev => ({...prev, height: next.height})); setNotice(""); }} />
            </div>
            <div className="field full btn-row">
              <button type="submit" disabled={uploading} className="btn btn-primary">Save Changes</button>
              <button type="button" className="btn btn-ghost" onClick={() => { setBody(savedBody()); setMeasurements(profile.measurements || profileMeasurements(profile)); setFormKey(k => k + 1); setAvatarPreview(profile.avatar); setErrors({}); setNotice(""); }}>Cancel</button>
            </div>
          </form>
        </div>

        <div className="card">
          <div className="card-head">
            <h3>Digital Membership Card</h3>
          </div>
          <DigitalCard
            roleLabel="MEMBER"
            name={profile.name}
            idNumber={profile.memberId}
            idLabel="MEMBER ID"
            tier={state.membership.plan.replace(" Monthly", "").replace(" Annual", "")}
            status={state.membership.status}
            sinceLabel="MEMBER SINCE"
            since={state.membership.joinDate}
            validThru={state.membership.expiryDate}
            avatarImage={profile.avatar}
            metaLeftValue={profile.bloodType || "Not set"}
            metaRightValue={profile.emergencyContact || "Not set"}
          />
          <div className="info-list" style={{ marginTop: 18 }}>
            <li><span>Body Type</span><span>{profile.bodyType}</span></li>
            <li><span>BMI</span><span>{parseFloat(profile.height) > 0 && parseFloat(profile.weight) > 0 ? (parseFloat(profile.weight) / (parseFloat(profile.height) / 100) ** 2).toFixed(1) : "Not available"}</span></li>
            <li><span>Joined</span><span>{state.membership.joinDate}</span></li>
          </div>
        </div>
      </div>


    </>
  );
}

export default Profile;
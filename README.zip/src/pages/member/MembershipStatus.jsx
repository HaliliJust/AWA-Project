import { Link } from 'react-router-dom';
import { useState } from 'react';
import PageHead from '../../components/PageHead';
import Badge from '../../components/Badge';
import { useMember } from '../../context/MemberContext';
import { REWARDS } from '../../services/memberStore';
export default function MembershipStatus() {
  const {
      state,
      redeem
    } = useMember(),
    m = state.membership;
  const [notice, setNotice] = useState('');
  return <><PageHead eyebrow="Membership" title="Membership Status" description="Your plan, payments and referral rewards." /><div className="split"><section className="card"><div className="card-head"><h3>Plan Details</h3><Badge status={m.status} /></div><ul className="info-list">{[['Member ID', state.profile.memberId], ['Current Plan', m.plan], ['Start Date', m.joinDate], ['Expiry Date', m.expiryDate || 'No subscription'], ['Days Left', `${m.daysLeft} days`], ['Payment Status', m.paymentStatus], ['Next Payment', m.nextPayment || 'Select a plan'], ['Membership Points', `${m.points} pts`]].map(([label, value]) => <li key={label}><span>{label}</span><span>{value}</span></li>)}</ul><Link to="/member/renew" className="btn btn-primary section-gap">Renew Membership</Link></section><section className="card"><h3>Membership Points</h3><p>Referral code: <strong>{state.profile.referralCode}</strong></p><p>Earn 20 points when a new member successfully registers with this code. Each point gives ₱1 off a renewal.</p><ul className="info-list"><li><span>Available Points</span><span>{m.points}</span></li><li><span>Total Referral Points Earned</span><span>{m.referralPoints}</span></li></ul><h4 className="section-gap">Free Rewards</h4>{REWARDS.map(r => <div className="session-item" key={r.id}><p>{r.name} · {r.points} points</p><button className="btn btn-ghost" disabled={m.points < r.points} onClick={() => {
            if (redeem(r.id)) setNotice(`${r.name} redeemed. Show your reward reference at the front desk.`);
          }}>Redeem {r.name}</button></div>)}<p role="status">{notice}</p></section></div><section className="card section-gap"><h3>Redeemed Rewards</h3>{state.rewards.length ? <ul className="info-list">{state.rewards.map(r => <li key={r.id}><span>{r.name} · {r.redeemedAt}</span><span>Reference: {r.id}</span></li>)}</ul> : <p>No rewards redeemed yet.</p>}</section></>;
}

import PageHead from "../../components/PageHead";
import DataTable from "../../components/DataTable";
import { useMember } from "../../context/MemberContext";

function AttendanceHistory() {
  const { state } = useMember();
  const attendanceHistory = state.attendanceHistory;
  return (
    <>
      <PageHead
        eyebrow="Attendance"
        title="Attendance History"
        description="Review your past gym visits."
      />

      <div className="card">
        <DataTable
          columns={["Date", "Time In", "Time Out", "Duration"]}
          rows={attendanceHistory}
          renderRow={(a) => (
            <tr key={a.id || a.date}>
              <td className="cell-primary">{a.date}</td>
              <td>{a.timeIn}</td>
              <td>{a.timeOut}</td>
              <td>{a.duration}</td>
            </tr>
          )}
        />
      </div>
    </>
  );
}

export default AttendanceHistory;

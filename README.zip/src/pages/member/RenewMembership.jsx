import { useState } from "react";
import { Check } from "lucide-react";
import PageHead from "../../components/PageHead";
import { membershipPlans } from "../../data/mockData";
import { useMember } from "../../context/MemberContext";

function RenewMembership() {
  const { state, renew } = useMember();
  const [usePoints, setUsePoints] = useState(false);
  const [step, setStep] = useState(1); // 1 = select plan, 2 = confirm, 3 = payment
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState("GCash");

  const availablePlans = membershipPlans;

  function handleSelectPlan(plan) {
    setSelectedPlan(plan);
    setStep(2);
  }

  function handleConfirm() {
    setStep(3);
  }

  function handlePayment() {
    if (renew(selectedPlan.id, paymentMethod, usePoints)) setStep(4);
  }

  return (
    <>
      <PageHead
        eyebrow="Membership"
        title="Renew Membership"
        description="Extend your membership before it expires."
      />

      <div className="payment-steps" style={{ marginBottom: 24 }}>
        <div className="payment-step">
          <span className="payment-step-num">1</span>
          Select Plan
        </div>
        <span className="payment-step-arrow">→</span>
        <div className="payment-step" style={{ opacity: step >= 2 ? 1 : 0.5 }}>
          <span className="payment-step-num">2</span>
          Confirm
        </div>
        <span className="payment-step-arrow">→</span>
        <div className="payment-step" style={{ opacity: step >= 3 ? 1 : 0.5 }}>
          <span className="payment-step-num">3</span>
          Payment
        </div>
      </div>

      {step === 1 && (
        <div className="grid grid-3">
          {availablePlans.map((plan) => {
            const isCurrent = plan.name === state.membership.plan;
            return (
              <div className="card membership-plan-card" key={plan.id} style={isCurrent ? { borderColor: "var(--accent)" } : undefined}>
                <div className="card-head">
                  <h3>{plan.name}</h3>
                  {isCurrent && <span className="badge badge-success">Current</span>}
                </div>
                <div className="stat-value" style={{ marginBottom: 14 }}>{plan.price}</div>
                <div className="info-list">
                  {plan.perks.map((perk) => (
                    <li key={perk}>
                      <span><Check size={14} style={{ marginRight: 8, verticalAlign: -2, color: "var(--accent)" }} />{perk}</span>
                      <span></span>
                    </li>
                  ))}
                </div>
                <button type="button" className="btn btn-primary btn-block" style={{ marginTop: 18 }} onClick={() => handleSelectPlan(plan)}>
                  {isCurrent ? "Renew This Plan" : "Select This Plan"}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {step === 2 && selectedPlan && (
        <div className="card">
          <div className="card-head">
            <h3>Confirm Your Selection</h3>
          </div>
          <div className="info-list">
            <li><span>Selected Plan</span><span>{selectedPlan.name}</span></li>
            <li><span>Price</span><span>{selectedPlan.price}</span></li>
            <li><span>Includes</span><span>{selectedPlan.perks.join(", ")}</span></li><li><span>Current Plan</span><span>{state.membership.plan}</span></li>
          </div>
          <div style={{ marginTop: 18, display: "flex", gap: 12 }}>
            <button type="button" className="btn btn-ghost" onClick={() => setStep(1)}>Back</button>
            <button type="button" className="btn btn-primary" onClick={handleConfirm}>Confirm & Proceed to Payment</button>
          </div>
        </div>
      )}

      {step === 3 && selectedPlan && (
        <div className="card">
          <div className="card-head">
            <h3>Payment Method</h3>
          </div>
          <p className="section-bottom">Demo checkout: this records your payment locally; no money is transferred.</p><div className="grid grid-3" style={{ marginBottom: 20 }}>
            <label className="card" style={{ padding: 16, cursor: "pointer" }}>
              <input type="radio" name="method" checked={paymentMethod === "GCash"} onChange={() => setPaymentMethod("GCash")} style={{ marginRight: 8 }} />
              GCash
            </label>
            <label className="card" style={{ padding: 16, cursor: "pointer" }}>
              <input type="radio" name="method" checked={paymentMethod === "Bank Transfer"} onChange={() => setPaymentMethod("Bank Transfer")} style={{ marginRight: 8 }} />
              Bank Transfer
            </label>
            <label className="card" style={{ padding: 16, cursor: "pointer" }}>
              <input type="radio" name="method" checked={paymentMethod === "Cash at Front Desk"} onChange={() => setPaymentMethod("Cash at Front Desk")} style={{ marginRight: 8 }} />
              Cash at Front Desk
            </label>
          </div>
          <div className="info-list" style={{ marginBottom: 20 }}>
            <li><span>Plan</span><span>{selectedPlan.name}</span></li>
            <li><span>Amount</span><span>{selectedPlan.price}</span></li>
            <li><span>Method</span><span>{paymentMethod}</span></li>
          </div>
          <label className="points-choice"><input type="checkbox" checked={usePoints} onChange={e => setUsePoints(e.target.checked)} disabled={!state.membership.points} /> Use membership points ({state.membership.points} available; PHP 1 per point)</label>
<p className="section-bottom">Total: PHP {(Number(selectedPlan.price.replace(/[^0-9]/g, '')) - (usePoints ? Math.min(state.membership.points, Number(selectedPlan.price.replace(/[^0-9]/g, ''))) : 0)).toLocaleString()}</p>
<button className="btn btn-ghost" onClick={() => setStep(2)}>Back</button>
<button type="button" className="btn btn-primary" onClick={handlePayment}>
            Complete Payment
          </button>
        </div>
      )}

      {step === 4 && (
        <div className="card" style={{ textAlign: "center", padding: 40 }}>
          <Check size={48} style={{ color: "var(--success)", margin: "0 auto 16px" }} />
          <h3 style={{ marginBottom: 8 }}>Membership Renewed!</h3>
          <p style={{ color: "var(--text-soft)" }}>Your membership has been successfully renewed.</p>
        </div>
      )}
    </>
  );
}

export default RenewMembership;
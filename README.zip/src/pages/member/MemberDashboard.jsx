import { ShieldCheck, CalendarCheck, Wallet, Dumbbell } from 'lucide-react';
import PageHead from '../../components/PageHead';
import StatCard from '../../components/StatCard';
import ProgressRing from '../../components/ProgressRing';
import BarChart from '../../components/BarChart';
import { useMember } from '../../context/MemberContext';
import { weeklySummary, localDate } from '../../services/memberStore';
export default function MemberDashboard() {
  const {
      state
    } = useMember(),
    days = weeklySummary(state.workoutSchedule);
  const completed = days.reduce((n, d) => n + d.completed, 0),
    scheduled = days.reduce((n, d) => n + d.sessions.length, 0),
    progress = scheduled ? Math.round(completed / scheduled * 100) : 0;
  const month = state.workoutSchedule.filter(s => s.date.startsWith(localDate().slice(0, 7)) && !['Cancelled', 'Proposed'].includes(s.status)),
    done = month.filter(s => s.status === 'Completed').length;
  const payment = state.payments[0],
    next = state.workoutSchedule.filter(s => s.status === 'Scheduled' && s.date >= localDate()).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))[0];
  return <><PageHead eyebrow="Personal Dashboard" title={`Welcome back, ${state.profile.name.split(' ')[0]}`} description="Your membership and workout activity at a glance." /><div className="grid grid-4 section-bottom"><StatCard icon={ShieldCheck} label="Membership" value={state.membership.status} trend={state.membership.plan} /><StatCard icon={CalendarCheck} label="Attendance this month" value={state.attendanceHistory.filter(a => a.date.startsWith(localDate().slice(0, 7))).length} unit="visits" /><StatCard icon={Wallet} label="Last Payment" value={payment ? `₱${payment.amount.toLocaleString()}` : 'No payments'} trend={payment?.date} /><StatCard icon={Dumbbell} label="Next Workout" value={next?.program || 'None scheduled'} trend={next ? `${next.date} ${next.time}` : ''} /></div><div className="split"><section className="card"><h3>Weekly Activity</h3><p>{completed} of {scheduled} sessions completed this week</p><BarChart values={days.map(d => d.sessions.length ? d.completed / d.sessions.length * 100 : 0)} labels={days.map(d => d.label)} /><label className="progress-label" htmlFor="weekly-progress">Weekly progress: {progress}%</label><progress id="weekly-progress" max="100" value={progress} /><ul className="info-list">{days.map(d => <li key={d.date}><span><strong>{d.label}</strong><br />{d.date}</span><span>{d.completed} completed · {d.duration} min<br />{d.sessions.length ? d.sessions.map(s => `${s.time} ${s.program} (${s.status})`).join('; ') : 'No sessions scheduled'}</span></li>)}</ul></section><section className="card"><h3>Monthly Goal</h3><ProgressRing percent={month.length ? Math.round(done / month.length * 100) : 0} label={`${done} of ${month.length} planned sessions`} /><p>Your goal follows the confirmed sessions in your schedule.</p></section></div><div className="split section-gap"><section className="card"><h3>Recent Attendance</h3>{state.attendanceHistory.length ? <ul className="info-list">{state.attendanceHistory.slice(0, 3).map(a => <li key={a.id}><span>{a.date}</span><span>{a.duration} min</span></li>)}</ul> : <p>No completed sessions yet.</p>}</section><section className="card"><h3>Recent Payments</h3>{state.payments.length ? <ul className="info-list">{state.payments.slice(0, 3).map(p => <li key={p.id}><span>{p.desc}<br />{p.date} · {p.method}</span><span>₱{p.amount.toLocaleString()} · {p.status}</span></li>)}</ul> : <p>No payments recorded yet.</p>}</section></div></>;
}

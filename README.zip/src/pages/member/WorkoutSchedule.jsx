import { ExerciseSummary } from '../../components/ExerciseEditor';
import { Link } from 'react-router-dom';
import WorkoutSuggestions from "../../components/WorkoutSuggestions";
import PageHead from '../../components/PageHead';
import Badge from '../../components/Badge';
import { useMember } from '../../context/MemberContext';
import { localDate } from '../../services/memberStore';
export default function WorkoutSchedule() {
  const {
    state,
    updateWorkoutScheduleStatus
  } = useMember();
  if (!state.membership.active) return <><PageHead eyebrow="Workouts" title="Workout Schedule" description="Your workouts and suggested plans." /><div className="card"><h2>Subscribe to access workout plans.</h2><Link className="btn btn-primary" to="/member/renew">Subscribe or Renew Membership</Link></div><WorkoutSuggestions profile={state.profile} active={false} /></>;
  const schedule = [...state.workoutSchedule].sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  function session(w) {
    return <article className="session-item" key={w.id}><h4>{w.program}</h4><p>{w.date} at {w.time} · {w.duration} minutes</p><p>Trainer: {w.trainer}</p><Badge status={w.status} /><ExerciseSummary plan={w} />{w.notes && <p>Trainer notes: {w.notes}</p>}{w.status === 'Proposed' ? <div className="btn-row"><button className="btn btn-primary" onClick={() => updateWorkoutScheduleStatus(w.id, 'Scheduled')}>Accept Alternative</button><button className="btn btn-ghost" onClick={() => updateWorkoutScheduleStatus(w.id, 'Cancelled')}>Decline</button></div> : ['Scheduled', 'Missed'].includes(w.status) && new Date(`${w.date}T${w.time}`) <= new Date() ? <div className="btn-row"><button className="btn btn-primary" onClick={() => updateWorkoutScheduleStatus(w.id, 'Completed')}>Mark Completed</button><button className="btn btn-ghost" onClick={() => updateWorkoutScheduleStatus(w.id, 'Cancelled')}>Did Not Proceed</button></div> : null}</article>;
  }
  const today = schedule.filter(w => w.date === localDate()),
    upcoming = schedule.filter(w => w.date > localDate());
  return <><PageHead eyebrow="Workouts" title="Workout Schedule" description="Confirmed sessions and alternatives proposed by your trainer." /><div className="split"><section className="card"><h3>Today's Workout</h3>{today.length ? today.map(session) : <p>No workout scheduled for today.</p>}</section><section className="card"><h3>Upcoming Workouts</h3>{upcoming.length ? upcoming.map(session) : <p>No upcoming workouts.</p>}</section></div><section className="card section-gap"><h3>Past Workouts</h3>{schedule.filter(w => w.date < localDate()).map(session)}{!schedule.some(w => w.date < localDate()) && <p>No past workouts.</p>}</section><section className="card section-gap"><h3>Workout Requests</h3>{state.workoutRequests.length ? <div className="table-wrap"><table><thead><tr>{['Program', 'Trainer', 'Date', 'Time', 'Duration', 'Status'].map(h => <th key={h} scope="col">{h}</th>)}</tr></thead><tbody>{[...state.workoutRequests].reverse().map(r => <tr key={r.id}><td>{r.program}</td><td>{r.trainer}</td><td>{r.date}</td><td>{r.time}</td><td>{r.duration} min</td><td><Badge status={r.status} />{["Pending", "Denied"].includes(r.status) && <Link to={`/member/workout-plans?request=${r.id}`}> Edit & resend</Link>}</td></tr>)}</tbody></table></div> : <p>No requests yet. <Link to="/member/workout-plans">Choose a workout plan</Link>.</p>}</section><WorkoutSuggestions profile={state.profile} active={state.membership.active} /></>;
}

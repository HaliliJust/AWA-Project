import { Link } from "react-router-dom";
import { Dumbbell, Activity, ShieldCheck } from "lucide-react";
import FormField from "../../components/FormField";

function Register() {
  return (
    <div className="auth-shell">
      <div className="auth-visual">
        <div className="sidebar-logo">
          Smart<span>fIT</span>
        </div>
        <p>
          Create your account to get a membership, book trainers, and track every
          workout, payment, and check-in in one place.
        </p>
        <ul className="info-list">
          <li>
            <span><Dumbbell size={14} style={{ marginRight: 8 }} /> Automated workout suggestions</span>
            <span>Based on your BMI</span>
          </li>
          <li>
            <span><Activity size={14} style={{ marginRight: 8 }} /> Progress tracking</span>
            <span>Trainer-monitored</span>
          </li>
          <li>
            <span><ShieldCheck size={14} style={{ marginRight: 8 }} /> Membership reminders</span>
            <span>Never miss a renewal</span>
          </li>
        </ul>
      </div>

      <div className="auth-form-side">
        <div className="auth-box">
          <span className="eyebrow">Create Account</span>
          <h2>Join SmartfIT</h2>
          <p>Fill in your details to register as a new member.</p>

          <form className="form-grid" onSubmit={(e) => e.preventDefault()}>
            <FormField label="Full Name" placeholder="Juan Dela Cruz" />
            <FormField label="Email Address" type="email" placeholder="you@email.com" />
            <FormField label="Password" type="password" placeholder="••••••••" />
            <FormField label="Confirm Password" type="password" placeholder="••••••••" />

            <FormField label="Height (cm)" type="number" placeholder="165" />
            <FormField label="Weight (kg)" type="number" placeholder="58" />

            <FormField
              label="Body Type"
              type="select"
              options={["Ectomorph", "Mesomorph", "Endomorph"]}
              hint="Used to auto-suggest a starter workout plan"
            />
            <FormField
              label="Preferred Plan"
              type="select"
              options={["Basic Monthly", "Premium Monthly", "Premium Annual"]}
            />

            <div className="field full">
              <label>BMI &amp; suggestion preview</label>
              <div className="card" style={{ padding: 14 }}>
                <div className="info-list">
                  <li><span>Estimated BMI</span><span>21.3 · Normal</span></li>
                  <li><span>Suggested focus</span><span>General fitness &amp; toning</span></li>
                </div>
              </div>
              <span className="field-hint">This updates automatically once height and weight are entered.</span>
            </div>

            <button type="submit" className="btn btn-primary btn-block field full">
              Create Account
            </button>
          </form>

          <p className="auth-switch">
            Already a member? <Link to="/login">Log in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Register;

import { CalendarCheck, Dumbbell, TrendingUp, Wallet } from "lucide-react";

const FEATURES = [
  {
    icon: CalendarCheck,
    title: "Membership tracking",
    text: "See your plan and expiry date, and renew before it lapses.",
  },
  {
    icon: Dumbbell,
    title: "Workout programs",
    text: "Trainers build your plan and schedule sessions with you.",
  },
  {
    icon: TrendingUp,
    title: "Progress monitoring",
    text: "Follow your weight, BMI, and attendance over time.",
  },
  {
    icon: Wallet,
    title: "Simple payments",
    text: "Renew with GCash, bank transfer, or cash at the front desk.",
  },
];

// Copy that changes with the form currently shown.
const COPY = {
  login: {
    heading: "New to SmartfIT?",
    text: "Create a member or trainer account to manage workouts, sessions, and memberships online.",
    button: "Create Account",
  },
  register: {
    heading: "Already have an account?",
    text: "Log in to see your sessions, workout plan, and membership status.",
    button: "Log In",
  },
};

/**
 * The panel that slides between the left and right half of the screen.
 * On small screens the CSS collapses it into a compact brand header
 * (only the brand block stays visible).
 */
function AuthInfoPanel({ mode, onSwitch }) {
  const copy = COPY[mode];

  return (
    <aside className="authx-info" aria-label="About SmartfIT">
      <div className="authx-brand">
        <div className="authx-logo">
          Smart<span>fIT</span>
        </div>
        <p className="authx-descriptor">Gym Management System</p>
      </div>

      <div className="authx-info-detail">
        {/* key restarts the short fade whenever the copy changes */}
        <div className="authx-switchcopy" key={mode}>
          <h2>{copy.heading}</h2>
          <p>{copy.text}</p>
        </div>

        <button type="button" className="authx-btn authx-btn--outline" onClick={onSwitch}>
          {copy.button}
        </button>

        <ul className="authx-features">
          {FEATURES.map(({ icon: Icon, title, text }) => (
            <li key={title}>
              <span className="authx-feature-icon" aria-hidden="true">
                <Icon size={20} />
              </span>
              <div>
                <strong>{title}</strong>
                <span>{text}</span>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}

export default AuthInfoPanel;

import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AlertCircle, CheckCircle2 } from "lucide-react";
import AuthField from "../../components/AuthField";
import { useAuth, homeForRole } from "../../context/AuthContext";

function LoginForm({ notice, onSwitch }) {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [busy, setBusy] = useState(false);

  // After a successful registration: clear stale errors and pre-fill the new username.
  useEffect(() => {
    if (notice) {
      setFormError("");
      setFieldErrors({});
      setUsername(notice.username);
      setPassword("");
    }
  }, [notice]);

  async function handleSubmit(e) {
    e.preventDefault();
    if (busy) return;
    setFormError("");

    const found = {};
    if (!username.trim()) found.username = "Enter your username.";
    if (!password) found.password = "Enter your password.";
    setFieldErrors(found);

    const first = ["username", "password"].find((k) => found[k]);
    if (first) {
      document.getElementById(`login-${first}`)?.focus();
      return;
    }

    setBusy(true);
    const result = await login(username, password);
    setBusy(false);
    if (!result.ok) {
      setFormError(result.error);
      return;
    }

    navigate(homeForRole(result.role), { replace: true });
  }

  return (
    <div className="authx-box">
      <h1 id="login-title" className="authx-title" tabIndex={-1}>
        Welcome back
      </h1>
      <p className="authx-lead">
        Enter your username and password. Your role is detected automatically, so we'll take you
        straight to the right dashboard.
      </p>

      {notice && (
        <div className="authx-alert authx-alert--success" role="status">
          <CheckCircle2 size={20} aria-hidden="true" />
          <div>
            <div className="authx-alert-title">Account created</div>
            <div className="authx-alert-text">
              Welcome to SmartfIT, {notice.firstName}. Log in with your new username and password to
              get started.
            </div>
          </div>
        </div>
      )}

      {formError && (
        <div className="authx-alert authx-alert--error" role="alert">
          <AlertCircle size={20} aria-hidden="true" />
          <div>
            <div className="authx-alert-title">{formError}</div>
            <div className="authx-alert-text">Check both fields and try again.</div>
          </div>
        </div>
      )}

      <form className="authx-form" onSubmit={handleSubmit} noValidate>
        <AuthField
          id="login-username"
          label="Username"
          placeholder="e.g. member001"
          value={username}
          onChange={(e) => {
            setUsername(e.target.value);
            setFieldErrors((f) => ({ ...f, username: undefined }));
          }}
          error={fieldErrors.username}
          autoComplete="username"
        />

        <AuthField
          id="login-password"
          label="Password"
          type="password"
          placeholder="Enter your password"
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
            setFieldErrors((f) => ({ ...f, password: undefined }));
          }}
          error={fieldErrors.password}
          autoComplete="current-password"
        />

        <button
          type="submit"
          className="authx-btn authx-btn--primary authx-btn--block"
          disabled={busy}
          aria-busy={busy}
        >
          {busy ? "Logging in…" : "Log In"}
        </button>
      </form>

      {/* Small screens only: the sliding panel is hidden there, so keep a switch link in the form. */}
      <p className="authx-switch">
        Don't have an account?{" "}
        <button type="button" className="authx-link" onClick={onSwitch}>
          Create one
        </button>
      </p>
    </div>
  );
}

export default LoginForm;

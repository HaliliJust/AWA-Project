import { useEffect, useRef, useState } from "react";
import AuthInfoPanel from "./AuthInfoPanel";
import LoginForm from "./LoginForm";
import RegisterForm from "./RegisterForm";
import "./auth.css";

/**
 * Login + Create Account on one "switching" screen.
 *
 *  mode = "login"    -> info panel on the LEFT,  login form on the RIGHT
 *  mode = "register" -> info panel on the RIGHT, create-account form on the LEFT
 *
 * The panel slides between the two halves (see auth.css). Both forms stay
 * mounted so switching is instant, but the hidden one is removed from the
 * tab order and from screen readers via `visibility: hidden` in the CSS.
 */
function Login() {
  const [mode, setMode] = useState("login");
  const [notice, setNotice] = useState(null);
  const previousMode = useRef(mode);

  // After a switch, move focus to the heading of the form that just appeared.
  useEffect(() => {
    if (previousMode.current === mode) return;
    previousMode.current = mode;
    document.getElementById(mode === "login" ? "login-title" : "register-title")?.focus();
  }, [mode]);

  const showLogin = () => setMode("login");
  const showRegister = () => {
    setNotice(null);
    setMode("register");
  };
  const handleRegistered = ({ firstName, username }) => {
    setNotice({ firstName, username });
    setMode("login");
  };

  return (
    <main className={`authx${mode === "register" ? " is-register" : ""}`}>
      <section
        className={`authx-pane authx-pane--register${mode === "register" ? " is-active" : ""}`}
        aria-labelledby="register-title"
      >
        <RegisterForm onRegistered={handleRegistered} onSwitch={showLogin} />
      </section>

      <section
        className={`authx-pane authx-pane--login${mode === "login" ? " is-active" : ""}`}
        aria-labelledby="login-title"
      >
        <LoginForm notice={notice} onSwitch={showRegister} />
      </section>

      <AuthInfoPanel mode={mode} onSwitch={mode === "login" ? showRegister : showLogin} />
    </main>
  );
}

export default Login;

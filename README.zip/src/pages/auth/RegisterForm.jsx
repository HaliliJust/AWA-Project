import { useEffect, useMemo, useRef, useState } from "react";
import { Activity, AlertCircle, CalendarDays } from "lucide-react";
import AuthField from "../../components/AuthField";
import AuthChoiceGroup from "../../components/AuthChoiceGroup";
import BodyTypeVisualPicker from "../../components/BodyTypeVisualPicker";
import IdUploadField from "../../components/IdUploadField";
import CaptchaBox from "../../components/CaptchaBox";
import StepIndicator from "../../components/StepIndicator";
import {
  calcAge,
  findReferrer,
  isEmailTaken,
  isUsernameTaken,
  isValidPhone,
  norm,
  registerAccount,
} from "../../services/accountStore";

// ---------- options & rules (easy to change) ----------

const MEMBER_MIN_AGE = 15;
const TRAINER_MIN_AGE = 18;
const MAX_AGE = 100;
const TOTAL_STEPS = 4;

const ROLE_OPTIONS = [
  { value: "member", label: "Member", description: "Train, book sessions, and track your progress." },
  { value: "trainer", label: "Trainer", description: "Build programs and guide your members." },
];

const GENDER_OPTIONS = [
  { value: "", label: "Select gender" },
  { value: "Male", label: "Male" },
  { value: "Female", label: "Female" },
  { value: "Prefer not to say", label: "Prefer not to say" },
];

const GOAL_OPTIONS = [
  "Lose weight",
  "Build muscle",
  "Gain weight",
  "Improve endurance",
  "Increase flexibility",
  "Stay active and healthy",
  "Other",
].map((v) => ({ value: v, label: v }));

const EXPERIENCE_OPTIONS = [
  { value: "", label: "Select years of experience" },
  { value: "<1", label: "Less than 1 year" },
  { value: "1-2", label: "1–2 years" },
  { value: "3-5", label: "3–5 years" },
  { value: "6-10", label: "6–10 years" },
  { value: "10+", label: "10+ years" },
];

const INITIAL = {
  role: "member",
  firstName: "",
  middleName: "",
  lastName: "",
  birthdate: "",
  gender: "",
  contactNumber: "",
  email: "",

  emergencyName: "",
  emergencyNumber: "",

  // member: fitness profile
  height: "",
  weight: "",
  bodyTypeStyle: "feminine",
  bodyType: "",
  bodyBuild: 50,
  fitnessGoals: [],
  fitnessGoalNote: "",

  // trainer: professional profile
  specialty: "",
  certifications: "",
  experience: "",
  idFront: "",
  idBack: "",

  username: "",
  referralCode: "",
  password: "",
  confirm: "",
  robot: false,
};

// Letters (any language), spaces, dots, hyphens, apostrophes.
const NAME_RE = /^[\p{L}][\p{L}\s.'’-]*$/u;
const NAME_MSG = "Use letters only. Spaces, hyphens, and apostrophes are fine.";

// The fields on each step, in on-screen order (used to focus the first error).
const fieldsForStep = (step, role) => {
  if (step === 1)
    return ["firstName", "middleName", "lastName", "birthdate", "gender", "contactNumber", "email"];
  if (step === 2) return ["emergencyName", "emergencyNumber"];
  if (step === 3)
    return role === "member"
      ? ["height", "weight", "bodyType", "fitnessGoals"]
      : ["idFront", "idBack", "specialty", "experience", "certifications"];
  return ["username", "referralCode", "password", "confirm", "robot"];
};

const stepOf = (name, role) =>
  [1, 2, 3, 4].find((s) => fieldsForStep(s, role).includes(name)) || TOTAL_STEPS;

// ---------- helpers ----------

function todayISO() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function bmiCategory(bmi) {
  if (bmi < 18.5) return "Underweight";
  if (bmi < 25) return "Normal";
  if (bmi < 30) return "Overweight";
  return "Obese";
}

// Finds the best element to focus for a given field: a real button (upload
// control, a body-type card) before a hidden file input, a role="radio"/"tab"
// before falling back to a plain input/select/textarea.
function focusField(name) {
  const el = document.getElementById(`reg-${name}`);
  if (!el) return;
  if (el.matches("input, select, textarea")) {
    el.focus();
    return;
  }
  const target =
    el.querySelector('button:not([tabindex="-1"])') ||
    el.querySelector('[role="radio"], [role="tab"]') ||
    el.querySelector('input:not([tabindex="-1"]), select, textarea');
  (target || el).focus();
}

function validateStep(step, v, today) {
  const e = {};

  if (step === 1) {
    if (!v.firstName.trim()) e.firstName = "Enter your first name.";
    else if (!NAME_RE.test(v.firstName.trim())) e.firstName = NAME_MSG;

    if (v.middleName.trim() && !NAME_RE.test(v.middleName.trim())) e.middleName = NAME_MSG;

    if (!v.lastName.trim()) e.lastName = "Enter your last name.";
    else if (!NAME_RE.test(v.lastName.trim())) e.lastName = NAME_MSG;

    const minAge = v.role === "trainer" ? TRAINER_MIN_AGE : MEMBER_MIN_AGE;
    const age = calcAge(v.birthdate);
    if (!v.birthdate) e.birthdate = "Enter your birthdate.";
    else if (age === null) e.birthdate = "Enter a valid date.";
    else if (v.birthdate > today) e.birthdate = "Birthdate can't be in the future.";
    else if (age > MAX_AGE) e.birthdate = `Check your birthdate. Age can't be over ${MAX_AGE}.`;
    else if (age < minAge)
      e.birthdate = `${v.role === "trainer" ? "Trainers" : "Members"} must be at least ${minAge} years old.`;

    if (!v.gender) e.gender = "Select a gender.";

    if (!isValidPhone(v.contactNumber)) e.contactNumber = "Enter a valid number, like 0917 123 4567.";

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email.trim()))
      e.email = "Enter a valid email, like name@email.com.";
    else if (isEmailTaken(v.email)) e.email = "An account with this email already exists.";
  }

  if (step === 2) {
    if (!v.emergencyName.trim()) e.emergencyName = "Enter your emergency contact's name.";
    else if (!NAME_RE.test(v.emergencyName.trim())) e.emergencyName = NAME_MSG;

    if (!isValidPhone(v.emergencyNumber)) e.emergencyNumber = "Enter a valid number, like 0917 123 4567.";
  }

  if (step === 3) {
    if (v.role === "member") {
      const h = parseFloat(v.height);
      if (!(h >= 100 && h <= 250)) e.height = "Enter your height in cm (100–250).";
      const w = parseFloat(v.weight);
      if (!(w >= 30 && w <= 300)) e.weight = "Enter your weight in kg (30–300).";
      if (!v.bodyType) e.bodyType = "Choose the body type closest to yours.";
      if (v.fitnessGoals.length === 0) e.fitnessGoals = "Choose at least one goal.";
    } else {
      if (!v.idFront) e.idFront = "Upload the front of a valid ID.";
      if (!v.idBack) e.idBack = "Upload the back of a valid ID.";
      if (!v.specialty.trim()) e.specialty = "Enter your specialty or area of expertise.";
      if (!v.experience) e.experience = "Select your years of experience.";
    }
  }

  if (step === 4) {
    if (!/^[A-Za-z0-9_]{4,20}$/.test(v.username.trim()))
      e.username = "Use 4–20 letters, numbers, or underscores.";
    else if (isUsernameTaken(v.username)) e.username = "That username is already taken.";

    if (v.referralCode.trim()) {
      const referrer = findReferrer(v.referralCode);
      if (!referrer) e.referralCode = "We couldn't find a member or trainer with that username.";
      else if (norm(referrer.username) === norm(v.username))
        e.referralCode = "You can't use your own username as a referral code.";
    }

    if (v.password.length < 8) e.password = "Use at least 8 characters.";

    if (!v.confirm) e.confirm = "Re-enter your password.";
    else if (v.confirm !== v.password) e.confirm = "Passwords don't match.";

    if (!v.robot) e.robot = "Check the box to confirm you're not a robot.";
  }

  return e;
}

function buildPayload(v) {
  const base = {
    role: v.role,
    username: v.username,
    password: v.password,
    referralCode: v.referralCode,
    firstName: v.firstName,
    middleName: v.middleName,
    lastName: v.lastName,
    birthdate: v.birthdate,
    gender: v.gender,
    contactNumber: v.contactNumber,
    email: v.email,
    emergencyContactName: v.emergencyName,
    emergencyContactNumber: v.emergencyNumber,
  };

  if (v.role === "member") {
    return {
      ...base,
      height: parseFloat(v.height),
      weight: parseFloat(v.weight),
      bodyTypeStyle: v.bodyTypeStyle,
      bodyType: v.bodyType,
      bodyBuild: v.bodyBuild,
      fitnessGoals: v.fitnessGoals,
      fitnessGoalNote: v.fitnessGoals.includes("Other") ? v.fitnessGoalNote.trim() : "",
    };
  }

  return {
    ...base,
    specialty: v.specialty,
    certifications: v.certifications,
    experience: v.experience,
    idFront: v.idFront,
    idBack: v.idBack,
  };
}

// ---------- component ----------

function RegisterForm({ onRegistered, onSwitch }) {
  const [values, setValues] = useState(INITIAL);
  const [errors, setErrors] = useState({});
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState("");

  const headingRef = useRef(null);
  const previousStep = useRef(1);
  const pendingFocus = useRef(null);

  const isMember = values.role === "member";
  const today = useMemo(() => todayISO(), []);
  const age = useMemo(() => calcAge(values.birthdate), [values.birthdate]);
  const bmi = useMemo(() => {
    const h = parseFloat(values.height) / 100;
    const w = parseFloat(values.weight);
    if (!(h >= 1 && w >= 20)) return null;
    return w / (h * h);
  }, [values.height, values.weight]);

  const stepLabels = [
    "About you",
    "Emergency contact",
    isMember ? "Fitness profile" : "Professional info",
    "Account",
  ];
  const stepTitles = [
    "About you",
    "Emergency contact",
    isMember ? "Fitness profile" : "Professional info",
    "Account details",
  ];

  // After the step changes, move focus to the new step's heading (or to a field that needs fixing).
  useEffect(() => {
    if (previousStep.current === step) return;
    previousStep.current = step;
    if (pendingFocus.current) {
      focusField(pendingFocus.current);
      pendingFocus.current = null;
    } else {
      headingRef.current?.focus();
    }
  }, [step]);

  const setValue = (name, val) => {
    setValues((v) => ({ ...v, [name]: val }));
    setErrors((er) => ({ ...er, [name]: undefined }));
    setFormError("");
  };

  const field = (name) => ({
    id: `reg-${name}`,
    value: values[name],
    onChange: (e) => setValue(name, e.target.value),
    error: errors[name],
  });

  // Gender also nudges the body-silhouette style, so the picker in the next
  // step usually already shows the right set (the person can still switch it).
  const handleGenderChange = (e) => {
    const gender = e.target.value;
    setValues((v) => ({
      ...v,
      gender,
      bodyTypeStyle: gender === "Male" ? "masculine" : gender === "Female" ? "feminine" : v.bodyTypeStyle,
    }));
    setErrors((er) => ({ ...er, gender: undefined }));
    setFormError("");
  };

  // Picking a new somatotype resets the build slider to its midpoint, rather
  // than carrying over a slider value that made sense for the old category.
  const handleBodyCategoryChange = (bodyType) => {
    setValues((v) => ({ ...v, bodyType, bodyBuild: 50 }));
    setErrors((er) => ({ ...er, bodyType: undefined }));
    setFormError("");
  };

  function goNext() {
    const found = validateStep(step, values, today);
    setErrors(found);
    const first = fieldsForStep(step, values.role).find((k) => found[k]);
    if (first) {
      focusField(first);
      return;
    }
    setStep(step + 1);
  }

  function goBack() {
    setErrors({});
    setFormError("");
    setStep(step - 1);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (busy) return;
    if (step < TOTAL_STEPS) {
      goNext();
      return;
    }

    const found = validateStep(TOTAL_STEPS, values, today);
    setErrors(found);
    const first = fieldsForStep(TOTAL_STEPS, values.role).find((k) => found[k]);
    if (first) {
      focusField(first);
      return;
    }

    setBusy(true);
    const result = await registerAccount(buildPayload(values));
    setBusy(false);

    if (!result.ok) {
      setErrors(result.errors);
      if (result.errors.form) {
        setFormError(result.errors.form);
        return;
      }
      // A field problem found while saving (for example, someone else just took the username).
      const failing = Object.keys(result.errors)[0];
      const failingStep = stepOf(failing, values.role);
      if (failingStep === step) focusField(failing);
      else {
        pendingFocus.current = failing;
        setStep(failingStep);
      }
      return;
    }

    onRegistered({ firstName: result.account.firstName, username: result.account.username });
    setValues(INITIAL);
    setErrors({});
    setFormError("");
    setStep(1);
  }

  const buttonLabel = step < TOTAL_STEPS ? "Next" : busy ? "Creating account…" : "Create Account";

  return (
    <div className="authx-box authx-box--wide">
      <h1 id="register-title" className="authx-title" tabIndex={-1}>
        Create your account
      </h1>

      <StepIndicator steps={stepLabels} current={step} />

      <form className="authx-form" onSubmit={handleSubmit} noValidate aria-labelledby="register-title">
        <div>
          <h2 ref={headingRef} className="authx-stepheading" tabIndex={-1}>
            <span className="authx-stepcount">
              Step {step} of {TOTAL_STEPS}
              <span className="authx-sr">: </span>
            </span>
            {stepTitles[step - 1]}
          </h2>
          {step === 1 && (
            <p className="authx-hint authx-hint--flush">All fields are required unless marked optional.</p>
          )}
          {step === 3 && !isMember && (
            <p className="authx-hint authx-hint--flush">
              Used to verify trainers before their profile goes live.
            </p>
          )}
        </div>

        <div className="authx-grid">
          {step === 1 && (
            <>
              <AuthChoiceGroup
                id="reg-role"
                legend="I'm registering as a"
                options={ROLE_OPTIONS}
                value={values.role}
                onChange={(val) => setValue("role", val)}
              />

              <AuthField {...field("firstName")} label="First name" span={2} autoComplete="given-name" />
              <AuthField
                {...field("middleName")}
                label="Middle name"
                optional
                span={2}
                autoComplete="additional-name"
              />
              <AuthField {...field("lastName")} label="Last name" span={2} autoComplete="family-name" />

              <AuthField
                {...field("birthdate")}
                label="Birthdate"
                type="date"
                span={2}
                autoComplete="bday"
                min="1900-01-01"
                max={today}
              />
              <div className="authx-field authx-span-2">
                <span className="authx-label" id="reg-age-label">
                  Age
                </span>
                <output className="authx-readout" aria-labelledby="reg-age-label" aria-live="off">
                  <CalendarDays size={18} aria-hidden="true" />
                  {age !== null && age >= 0 ? `${age} years old` : "From birthdate"}
                </output>
              </div>
              <AuthField
                {...field("gender")}
                label="Gender"
                type="select"
                span={2}
                options={GENDER_OPTIONS}
                autoComplete="sex"
                onChange={handleGenderChange}
              />

              <AuthField
                {...field("contactNumber")}
                label="Contact number"
                type="tel"
                span={3}
                inputMode="tel"
                autoComplete="tel"
                placeholder="0917 123 4567"
              />
              <AuthField
                {...field("email")}
                label="Email"
                type="email"
                span={3}
                autoComplete="email"
                autoCapitalize="none"
                placeholder="name@email.com"
              />
            </>
          )}

          {step === 2 && (
            <>
              <AuthField
                {...field("emergencyName")}
                label="Emergency contact person"
                span={3}
                placeholder="Full name"
              />
              <AuthField
                {...field("emergencyNumber")}
                label="Emergency contact number"
                type="tel"
                span={3}
                inputMode="tel"
                placeholder="0917 123 4567"
              />
            </>
          )}

          {step === 3 && isMember && (
            <>
              <AuthField {...field("height")} label="Height (cm)" span={2} inputMode="decimal" placeholder="170" />
              <AuthField {...field("weight")} label="Weight (kg)" span={2} inputMode="decimal" placeholder="65" />
              <div className="authx-field authx-span-2">
                <span className="authx-label" id="reg-bmi-label">
                  Estimated BMI
                </span>
                <output className="authx-readout" aria-labelledby="reg-bmi-label" aria-live="off">
                  <Activity size={18} aria-hidden="true" />
                  {bmi ? `${bmi.toFixed(1)} (${bmiCategory(bmi)})` : "From height and weight"}
                </output>
              </div>

              <BodyTypeVisualPicker
                id="reg-bodyType"
                style={values.bodyTypeStyle}
                onStyleChange={(style) => setValue("bodyTypeStyle", style)}
                category={values.bodyType}
                onCategoryChange={handleBodyCategoryChange}
                build={values.bodyBuild}
                onBuildChange={(val) => setValue("bodyBuild", val)}
                error={errors.bodyType}
              />

              <AuthChoiceGroup
                id="reg-fitnessGoals"
                legend="Fitness goals"
                type="checkbox"
                variant="chip"
                options={GOAL_OPTIONS}
                value={values.fitnessGoals}
                onChange={(val) => setValue("fitnessGoals", val)}
                hint="Choose all that apply."
                error={errors.fitnessGoals}
              />

              {values.fitnessGoals.includes("Other") && (
                <AuthField
                  id="reg-fitnessGoalNote"
                  label="Tell us more about your goal"
                  optional
                  span={6}
                  value={values.fitnessGoalNote}
                  onChange={(e) => setValue("fitnessGoalNote", e.target.value)}
                  placeholder="e.g. Train for a 10K run, rehab an old injury, general toning…"
                />
              )}
            </>
          )}

          {step === 3 && !isMember && (
            <>
              <IdUploadField
                id="reg-idFront"
                label="Government ID — front"
                value={values.idFront}
                onChange={(url) => setValue("idFront", url)}
                error={errors.idFront}
              />
              <IdUploadField
                id="reg-idBack"
                label="Government ID — back"
                value={values.idBack}
                onChange={(url) => setValue("idBack", url)}
                error={errors.idBack}
              />

              <AuthField
                {...field("specialty")}
                label="Specialty / area of expertise"
                span={3}
                placeholder="e.g. Strength & Conditioning"
              />
              <AuthField
                {...field("experience")}
                label="Years of experience"
                type="select"
                span={3}
                options={EXPERIENCE_OPTIONS}
              />

              <AuthField
                {...field("certifications")}
                label="Certifications"
                optional
                span={6}
                placeholder="e.g. NASM-CPT, ACE Group Fitness"
                hint="List any certifications you hold, separated by commas."
              />
            </>
          )}

          {step === 4 && (
            <>
              <AuthField
                {...field("username")}
                label="Username"
                span={3}
                autoComplete="username"
                autoCapitalize="none"
                placeholder="e.g. juan_dc"
                hint="4–20 letters, numbers, or underscores."
              />
              <AuthField
                {...field("referralCode")}
                label="Referral code"
                optional
                span={3}
                autoCapitalize="none"
                placeholder="Inviter's username"
                hint="The username of the person who invited you."
              />

              <AuthField
                {...field("password")}
                label="Password"
                type="password"
                span={3}
                hint="At least 8 characters."
                autoComplete="new-password"
              />
              <AuthField
                {...field("confirm")}
                label="Confirm password"
                type="password"
                span={3}
                autoComplete="new-password"
              />

              <CaptchaBox
                id="reg-robot"
                checked={values.robot}
                onChange={(checked) => setValue("robot", checked)}
                error={errors.robot}
              />
            </>
          )}
        </div>

        {formError && (
          <div className="authx-alert authx-alert--error" role="alert">
            <AlertCircle size={20} aria-hidden="true" />
            <div>
              <div className="authx-alert-title">Couldn't create your account</div>
              <div className="authx-alert-text">{formError}</div>
            </div>
          </div>
        )}

        <div className={`authx-actions${step > 1 ? " has-back" : ""}`}>
          {step > 1 && (
            <button type="button" className="authx-btn authx-btn--outline" onClick={goBack}>
              Back
            </button>
          )}
          <button type="submit" className="authx-btn authx-btn--primary" disabled={busy}>
            {buttonLabel}
          </button>
        </div>
      </form>

      {/* Small screens only: the sliding panel is hidden there, so keep a switch link in the form. */}
      <p className="authx-switch">
        Already have an account?{" "}
        <button type="button" className="authx-link" onClick={onSwitch}>
          Log in
        </button>
      </p>
    </div>
  );
}

export default RegisterForm;

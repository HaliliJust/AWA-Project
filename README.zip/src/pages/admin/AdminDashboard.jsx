import { Users, UserCog, ShieldCheck, ShieldAlert, Wallet, Clock, CalendarCheck, Target } from "lucide-react";
import PageHead from "../../components/PageHead";
import StatCard from "../../components/StatCard";
import BarChart from "../../components/BarChart";
import Badge from "../../components/Badge";
import useAdminData from "../../context/useAdminData";

function AdminDashboard() {
  const { systemOverview, allMembersAdmin, allTrainersAdmin, goalValues, goalLabels } = useAdminData();
  return (
    <>
      <PageHead
        eyebrow="Admin"
        title="System Overview"
        description="A high-level snapshot of members, trainers, payments, and attendance across SmartfIT."
      />

      <div className="grid grid-4" style={{ marginBottom: 20 }}>
        <StatCard icon={Users} label="Total Members" value={systemOverview.totalMembers} trend="Registered members" trendDirection="up" />
        <StatCard icon={UserCog} label="Total Trainers" value={systemOverview.totalTrainers} trend="Registered trainers" trendDirection="down" />
        <StatCard icon={ShieldCheck} label="Active Memberships" value={systemOverview.activeMemberships} trend={`${systemOverview.expiredMemberships} expired`} trendDirection="up" />
        <StatCard icon={Wallet} label="Total Payments (mo.)" value={systemOverview.totalPayments} trend={`${systemOverview.pendingPayments} pending`} trendDirection="up" />
      </div>

      <div className="split">
        <div className="card">
          <div className="card-head">
            <h3>Popular Fitness Goals</h3>
            <span className="card-more">•••</span>
          </div>
          <BarChart values={goalValues} labels={goalLabels} />
        </div>

        <div className="card">
          <div className="card-head">
            <h3>Key System Stats</h3>
          </div>
          <div className="info-list">
            <li><span><CalendarCheck size={13} style={{ marginRight: 6, verticalAlign: -2 }} />Avg. Attendance Rate</span><span>{systemOverview.avgAttendanceRate}%</span></li>
            <li><span><Target size={13} style={{ marginRight: 6, verticalAlign: -2 }} />Most Popular Goal</span><span>{systemOverview.popularGoal}</span></li>
            <li><span><ShieldAlert size={13} style={{ marginRight: 6, verticalAlign: -2 }} />Expired Memberships</span><span>{systemOverview.expiredMemberships}</span></li>
            <li><span><Clock size={13} style={{ marginRight: 6, verticalAlign: -2 }} />Pending Payments</span><span>{systemOverview.pendingPayments}</span></li>
          </div>
        </div>
      </div>

      <div className="split" style={{ marginTop: 20 }}>
        <div className="card">
          <div className="card-head">
            <h3>Member Roster</h3>
            <span className="card-more">•••</span>
          </div>
          <div className="info-list">
            {allMembersAdmin.slice(0, 4).map((m) => (
              <li key={m.id}>
                <span>{m.name}</span>
                <span><Badge status={m.status} /></span>
              </li>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <h3>Trainer Activity</h3>
            <span className="card-more">•••</span>
          </div>
          <div className="info-list">
            {allTrainersAdmin.map((t) => (
              <li key={t.id}>
                <span>{t.name}</span>
                <span>{t.sessionsToday} sessions today</span>
              </li>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export default AdminDashboard;

import { CheckCircle2, Clock, AlertCircle } from "lucide-react";
import PageHead from "../../components/PageHead";
import StatCard from "../../components/StatCard";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import useAdminData from "../../context/useAdminData";

function countBy(list, status) {
  return list.filter((item) => item.status === status).length;
}

function PaymentsOverview() {
  const { memberPaymentStatus, trainerPaymentStatus } = useAdminData();
  const allRoster = [...memberPaymentStatus, ...trainerPaymentStatus];

  return (
    <>
      <PageHead
        eyebrow="Admin · Payments"
        title="Payments Overview"
        description="Monitor who's paid, pending, or unpaid across every member and trainer."
      />

      <div className="grid grid-3" style={{ marginBottom: 20 }}>
        <StatCard icon={CheckCircle2} label="Paid" value={countBy(allRoster, "Paid")} trend="Members & trainers" trendDirection="up" />
        <StatCard icon={Clock} label="Pending" value={countBy(allRoster, "Pending")} trend="Awaiting confirmation" trendDirection="down" />
        <StatCard icon={AlertCircle} label="Unpaid" value={countBy(allRoster, "Unpaid")} trend="Needs follow-up" trendDirection="down" />
      </div>

      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card-head">
          <h3>Member Payment Status</h3>
          <span className="card-more">{memberPaymentStatus.length} members</span>
        </div>
        <DataTable
          columns={["Member", "Plan", "Amount Due", "Due Date", "Status"]}
          rows={memberPaymentStatus}
          renderRow={(m) => (
            <tr key={m.id}>
              <td>
                <div className="cell-primary">{m.name}</div>
                <div className="cell-sub">{m.id}</div>
              </td>
              <td>{m.plan}</td>
              <td>{m.amount}</td>
              <td>{m.dueDate}</td>
              <td><Badge status={m.status} /></td>
            </tr>
          )}
        />
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Trainer Payment Status</h3>
          <span className="card-more">{trainerPaymentStatus.length} trainers</span>
        </div>
        <DataTable
          columns={["Trainer", "Specialization", "Amount", "Due Date", "Status"]}
          rows={trainerPaymentStatus}
          renderRow={(t) => (
            <tr key={t.id}>
              <td>
                <div className="cell-primary">{t.name}</div>
                <div className="cell-sub">{t.id}</div>
              </td>
              <td>{t.role}</td>
              <td>{t.amount}</td>
              <td>{t.dueDate}</td>
              <td><Badge status={t.status} /></td>
            </tr>
          )}
        />
      </div>
    </>
  );
}

export default PaymentsOverview;

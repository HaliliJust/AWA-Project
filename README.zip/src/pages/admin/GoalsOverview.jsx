import PageHead from "../../components/PageHead";
import BarChart from "../../components/BarChart";
import { Target } from "lucide-react";
import useAdminData from "../../context/useAdminData";

function GoalsOverview() {
  const { goalStats, goalValues, goalLabels, allMembersAdmin, systemOverview } = useAdminData();
  const total = goalStats.reduce((sum, g) => sum + g.count, 0);

  return (
    <>
      <PageHead
        eyebrow="Admin · Goals"
        title="Fitness Goals"
        description="See what members across the gym are working toward, system-wide."
      />

      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card-head">
          <h3>
            <Target size={16} style={{ marginRight: 8, verticalAlign: -2 }} />
            Goal Distribution
          </h3>
          <span className="card-more">{systemOverview.totalMembers} members</span>
        </div>
        <BarChart values={goalValues} labels={goalLabels} />
      </div>

      <div className="split">
        <div className="card">
          <div className="card-head">
            <h3>Breakdown</h3>
          </div>
          <div className="info-list">
            {goalStats.map((g) => (
              <li key={g.goal}>
                <span>{g.goal}</span>
                <span>{g.count} members · {Math.round((g.count / (total || 1)) * 100)}%</span>
              </li>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <h3>Members by Goal</h3>
          </div>
          <div className="info-list">
            {allMembersAdmin.slice(0, 5).map((m) => (
              <li key={m.id}>
                <span>{m.name}</span>
                <span>{m.goal}</span>
              </li>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export default GoalsOverview;

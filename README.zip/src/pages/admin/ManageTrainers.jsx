import AdminAccountDetails, { RemovalHistory } from "../../components/AdminAccountDetails";
import { useState } from "react";
import PageHead from "../../components/PageHead";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import StatCard from "../../components/StatCard";
import { UserCog, Users, CalendarClock } from "lucide-react";
import useAdminData from "../../context/useAdminData";

function initials(name) {
  return name.split(" ").filter(Boolean).slice(-2).map((n) => n[0]).join("");
}

function ManageTrainers() {
  const { allTrainersAdmin, removals } = useAdminData();
  const [selected, setSelected] = useState(null);
  const select = (username, remove = false) => setSelected({ username, remove, key: Date.now() });
  const totalAssigned = allTrainersAdmin.reduce((sum, t) => sum + t.assigned, 0);
  const totalSessions = allTrainersAdmin.reduce((sum, t) => sum + t.sessionsToday, 0);

  return (
    <>
      <PageHead
        eyebrow="Admin · Trainers"
        title="Manage Trainers"
        description="Roster, specializations, assigned members, and today's session load."
      />

      <div className="grid grid-3" style={{ marginBottom: 20 }}>
        <StatCard icon={UserCog} label="Total Trainers" value={allTrainersAdmin.length} trend="Registered trainers" trendDirection="down" />
        <StatCard icon={Users} label="Total Assigned Members" value={totalAssigned} trend="Across all trainers" trendDirection="up" />
        <StatCard icon={CalendarClock} label="Sessions Today" value={totalSessions} trend="System-wide" trendDirection="up" />
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Trainer Roster</h3>
        </div>
        <DataTable
          columns={["Trainer", "Specialization", "Assigned Members", "Sessions Today", "Status", ""]}
          rows={allTrainersAdmin}
          renderRow={(t) => (
            <tr key={t.id}>
              <td>
                <div className="member-row">
                  <span className="mini-avatar">{initials(t.name)}</span>
                  <div>
                    <div className="cell-primary">{t.name}</div>
                    <div className="cell-sub">{t.id}</div>
                  </div>
                </div>
              </td>
              <td>{t.specialty}</td>
              <td>{t.assigned}</td>
              <td>{t.sessionsToday}</td>
              <td><Badge status={t.status} /></td>
              <td><div className="btn-row"><button className="btn btn-ghost btn-sm" onClick={() => select(t.username)}>View</button><button className="btn btn-danger btn-sm" onClick={() => select(t.username, true)}>Remove</button></div></td>
            </tr>
          )}
        />
      </div>
      {selected && <AdminAccountDetails key={selected.key} username={selected.username} startRemoval={selected.remove} onClose={() => setSelected(null)} />}
      <RemovalHistory records={removals.filter(r => r.role === 'trainer')} onView={select} />
    </>
  );
}

export default ManageTrainers;

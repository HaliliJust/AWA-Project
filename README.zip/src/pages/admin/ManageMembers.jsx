import AdminAccountDetails, { RemovalHistory } from "../../components/AdminAccountDetails";
import { useState } from "react";
import { Search } from "lucide-react";
import PageHead from "../../components/PageHead";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import useAdminData from "../../context/useAdminData";

function initials(name) {
  return name.split(" ").map((n) => n[0]).join("").slice(0, 2);
}

function ManageMembers() {
  const { allMembersAdmin, removals } = useAdminData();
  const [selected, setSelected] = useState(null);
  const select = (username, remove = false) => setSelected({ username, remove, key: Date.now() });
  const [query, setQuery] = useState("");
  const [goalFilter, setGoalFilter] = useState("All");

  const goals = ["All", ...new Set(allMembersAdmin.map((m) => m.goal))];

  const rows = allMembersAdmin.filter((m) => {
    const matchesQuery = m.name.toLowerCase().includes(query.toLowerCase()) || m.id.toLowerCase().includes(query.toLowerCase());
    const matchesGoal = goalFilter === "All" || m.goal === goalFilter;
    return matchesQuery && matchesGoal;
  });

  return (
    <>
      <PageHead
        eyebrow="Admin · Members"
        title="Manage Members"
        description="Search, filter, and review every member's status, goal, and attendance."
      />

      <div className="card">
        <div className="card-head" style={{ flexWrap: "wrap", gap: 12 }}>
          <div className="topbar-pill" style={{ minWidth: 220 }}>
            <Search size={14} />
            <input
              type="text"
              placeholder="Search by name or member ID…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              style={{ background: "none", border: "none", outline: "none", width: "100%", color: "var(--text)" }}
            />
          </div>

          <select
            value={goalFilter}
            onChange={(e) => setGoalFilter(e.target.value)}
            style={{ maxWidth: 220 }}
          >
            {goals.map((g) => (
              <option key={g} value={g}>{g === "All" ? "All Goals" : g}</option>
            ))}
          </select>
        </div>

        <DataTable
          columns={["Member", "Plan", "Goal", "Attendance", "Trainer", "Status", "Actions"]}
          rows={rows}
          renderRow={(m) => (
            <tr key={m.id}>
              <td>
                <div className="member-row">
                  <span className="mini-avatar">{initials(m.name)}</span>
                  <div>
                    <div className="cell-primary">{m.name}</div>
                    <div className="cell-sub">{m.id}</div>
                  </div>
                </div>
              </td>
              <td>{m.plan}</td>
              <td>{m.goal}</td>
              <td style={{ minWidth: 130 }}>
                <div className="progress-row">
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width: `${m.attendance}%` }} />
                  </div>
                  <span className="progress-pct">{m.attendance}%</span>
                </div>
              </td>
              <td>{m.trainer}</td>
              <td><Badge status={m.status} /></td><td><div className="btn-row"><button className="btn btn-ghost btn-sm" onClick={() => select(m.username)}>View</button><button className="btn btn-danger btn-sm" onClick={() => select(m.username, true)}>Remove</button></div></td>
            </tr>
          )}
        />
      </div>
      {selected && <AdminAccountDetails key={selected.key} username={selected.username} startRemoval={selected.remove} onClose={() => setSelected(null)} />}
      <RemovalHistory records={removals.filter(r => r.role === 'member')} onView={select} />
    </>
  );
}

export default ManageMembers;

import PageHead from "../../components/PageHead";
import FormField from "../../components/FormField";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import { allPayments, assignedMembers } from "../../data/mockData";

function RecordPayments() {
  return (
    <>
      <PageHead
        eyebrow="Payments"
        title="Record Payments"
        description="Save and manage a member's payment transaction."
      />

      <div className="split" style={{ marginBottom: 24 }}>
        <div className="card">
          <div className="card-head">
            <h3>New Transaction</h3>
          </div>
          <form className="form-grid" onSubmit={(e) => e.preventDefault()}>
            <FormField
              label="Member"
              type="select"
              options={assignedMembers.map((m) => m.name)}
            />
            <FormField
              label="Payment For"
              type="select"
              options={["Membership Renewal", "New Registration", "Personal Training Session", "Other"]}
            />
            <FormField label="Amount (₱)" type="number" placeholder="1799" />
            <FormField
              label="Payment Method"
              type="select"
              options={["Cash", "GCash", "Bank Transfer", "Credit Card"]}
            />
            <FormField label="Reference No." placeholder="Optional" />
            <FormField label="Date Received" type="date" />
            <FormField
              label="Remarks"
              type="textarea"
              full
              placeholder="Any additional notes about this payment..."
            />
            <button type="submit" className="btn btn-primary field full">Save Payment</button>
          </form>
        </div>

        <div className="card">
          <div className="card-head">
            <h3>Reminders</h3>
          </div>
          <div className="info-list">
            <li><span>Verify before issuing receipt</span><span>Required</span></li>
            <li><span>Cash payments</span><span>Count &amp; log drawer</span></li>
            <li><span>Digital payments</span><span>Attach reference no.</span></li>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Recently Recorded</h3>
        </div>
        <DataTable
          columns={["Payment ID", "Member", "Date", "Amount", "Method", "Status"]}
          rows={allPayments}
          renderRow={(p) => (
            <tr key={p.id}>
              <td className="cell-primary">{p.id}</td>
              <td>{p.member}</td>
              <td>{p.date}</td>
              <td>{p.amount}</td>
              <td>{p.method}</td>
              <td><Badge status={p.status} /></td>
            </tr>
          )}
        />
      </div>
    </>
  );
}

export default RecordPayments;

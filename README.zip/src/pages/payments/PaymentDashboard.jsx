import { Fragment } from "react";
import { Wallet, Clock, AlertCircle, Users, FileEdit, BadgeCheck, ReceiptText, History } from "lucide-react";
import PageHead from "../../components/PageHead";
import StatCard from "../../components/StatCard";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import BarChart from "../../components/BarChart";
import { paymentSummary, allPayments, weeklyLabels } from "../../data/mockData";

const paymentProcessSteps = [
  { icon: FileEdit, label: "Record Payment" },
  { icon: BadgeCheck, label: "Verify Payment" },
  { icon: ReceiptText, label: "Generate Receipt" },
  { icon: History, label: "Logged to History" },
];

function PaymentDashboard() {
  return (
    <>
      <PageHead
        eyebrow="Payments"
        title="Billing Overview"
        description="Monitor paid, pending, and overdue payments across all members."
      />

      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card-head">
          <h3>How a Payment is Processed</h3>
        </div>
        <div className="payment-steps">
          {paymentProcessSteps.map((step, i) => (
            <Fragment key={step.label}>
              <span className="payment-step">
                <span className="payment-step-num">{i + 1}</span>
                {step.label}
              </span>
              {i < paymentProcessSteps.length - 1 && <span className="payment-step-arrow">→</span>}
            </Fragment>
          ))}
        </div>
      </div>

      <div className="grid grid-4" style={{ marginBottom: 20 }}>
        <StatCard icon={Wallet} label="Collected (mo.)" value={paymentSummary.collected} trend="+8% vs last month" trendDirection="up" />
        <StatCard icon={Clock} label="Pending" value={paymentSummary.pending} trend="2 awaiting verification" trendDirection="down" />
        <StatCard icon={AlertCircle} label="Overdue" value={paymentSummary.overdue} trend="1 member overdue" trendDirection="down" />
        <StatCard icon={Users} label="Paying Members" value={paymentSummary.members} trend="All plans" trendDirection="up" />
      </div>

      <div className="split" style={{ marginBottom: 20 }}>
        <div className="card">
          <div className="card-head">
            <h3>Collections This Week</h3>
            <span className="card-more">•••</span>
          </div>
          <BarChart values={[3200, 1800, 4100, 2600, 3900, 5200, 4700]} labels={weeklyLabels} />
        </div>

        <div className="card">
          <div className="card-head">
            <h3>Status Breakdown</h3>
          </div>
          <div className="info-list">
            <li><span><Badge status="Verified" /></span><span>3 payments</span></li>
            <li><span><Badge status="Pending" /></span><span>1 payment</span></li>
            <li><span><Badge status="Overdue" /></span><span>1 payment</span></li>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Recent Transactions</h3>
        </div>
        <DataTable
          columns={["Payment ID", "Member", "Date", "Amount", "Method", "Status"]}
          rows={allPayments.slice(0, 4)}
          renderRow={(p) => (
            <tr key={p.id}>
              <td className="cell-primary">{p.id}</td>
              <td>{p.member}</td>
              <td>{p.date}</td>
              <td>{p.amount}</td>
              <td>{p.method}</td>
              <td><Badge status={p.status} /></td>
            </tr>
          )}
        />
      </div>
    </>
  );
}

export default PaymentDashboard;

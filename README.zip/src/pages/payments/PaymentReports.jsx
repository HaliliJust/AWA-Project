import PageHead from "../../components/PageHead";
import StatCard from "../../components/StatCard";
import BarChart from "../../components/BarChart";
import { Wallet, TrendingUp, Users, ReceiptText } from "lucide-react";
import { paymentSummary, weeklyLabels } from "../../data/mockData";

function PaymentReports() {
  return (
    <>
      <PageHead
        eyebrow="Reports"
        title="Payment Reports"
        description="Generate summaries of payment transactions across a selected period."
        action={
          <select defaultValue="This Month" className="btn btn-ghost btn-sm" style={{ appearance: "none" }}>
            <option>This Week</option>
            <option>This Month</option>
            <option>This Quarter</option>
          </select>
        }
      />

      <div className="grid grid-4" style={{ marginBottom: 20 }}>
        <StatCard icon={Wallet} label="Total Collected" value={paymentSummary.collected} trend="+8% vs last period" trendDirection="up" />
        <StatCard icon={TrendingUp} label="Collection Rate" value="94" unit="%" trend="+2%" trendDirection="up" />
        <StatCard icon={Users} label="Paying Members" value={paymentSummary.members} trend="Stable" trendDirection="up" />
        <StatCard icon={ReceiptText} label="Receipts Issued" value="47" trend="This month" trendDirection="up" />
      </div>

      <div className="split">
        <div className="card">
          <div className="card-head">
            <h3>Collections Trend</h3>
          </div>
          <BarChart values={[3200, 1800, 4100, 2600, 3900, 5200, 4700]} labels={weeklyLabels} />
        </div>

        <div className="card">
          <div className="card-head">
            <h3>By Payment Method</h3>
          </div>
          <div className="info-list">
            <li><span>GCash</span><span>₱21,400</span></li>
            <li><span>Cash</span><span>₱14,200</span></li>
            <li><span>Bank Transfer</span><span>₱17,999</span></li>
            <li><span>Credit Card</span><span>₱0</span></li>
          </div>
        </div>
      </div>
    </>
  );
}

export default PaymentReports;

import PageHead from "../../components/PageHead";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import { allPayments } from "../../data/mockData";

function VerifyPayments() {
  const pending = allPayments.filter((p) => p.status !== "Verified");

  return (
    <>
      <PageHead
        eyebrow="Payments"
        title="Verify Payments"
        description="Review and confirm submitted payments before they're marked as paid."
      />

      <div className="card" style={{ marginBottom: 20 }}>
        <div className="card-head">
          <h3>Awaiting Verification</h3>
          <span className="badge badge-warning">{pending.length} pending</span>
        </div>
        <DataTable
          columns={["Payment ID", "Member", "Date", "Amount", "Method", "Status", ""]}
          rows={pending}
          renderRow={(p) => (
            <tr key={p.id}>
              <td className="cell-primary">{p.id}</td>
              <td>{p.member}</td>
              <td>{p.date}</td>
              <td>{p.amount}</td>
              <td>{p.method}</td>
              <td><Badge status={p.status} /></td>
              <td>
                <div className="btn-row">
                  <button type="button" className="btn btn-primary btn-sm">Verify</button>
                  <button type="button" className="btn btn-ghost btn-sm">Reject</button>
                </div>
              </td>
            </tr>
          )}
        />
      </div>

      <div className="card">
        <div className="card-head">
          <h3>Recently Verified</h3>
        </div>
        <DataTable
          columns={["Payment ID", "Member", "Date", "Amount", "Status"]}
          rows={allPayments.filter((p) => p.status === "Verified")}
          renderRow={(p) => (
            <tr key={p.id}>
              <td className="cell-primary">{p.id}</td>
              <td>{p.member}</td>
              <td>{p.date}</td>
              <td>{p.amount}</td>
              <td><Badge status={p.status} /></td>
            </tr>
          )}
        />
      </div>
    </>
  );
}

export default VerifyPayments;

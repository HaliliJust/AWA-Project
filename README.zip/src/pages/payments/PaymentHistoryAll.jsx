import PageHead from "../../components/PageHead";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import { allPayments } from "../../data/mockData";

function PaymentHistoryAll() {
  return (
    <>
      <PageHead
        eyebrow="Payments"
        title="Payment History"
        description="Access all member payment records in one place."
        action={
          <div className="btn-row">
            <select defaultValue="All Statuses" className="btn btn-ghost btn-sm" style={{ appearance: "none" }}>
              <option>All Statuses</option>
              <option>Verified</option>
              <option>Pending</option>
              <option>Overdue</option>
            </select>
          </div>
        }
      />

      <div className="card">
        <DataTable
          columns={["Payment ID", "Member", "Date", "Amount", "Method", "Status"]}
          rows={allPayments}
          renderRow={(p) => (
            <tr key={p.id}>
              <td className="cell-primary">{p.id}</td>
              <td>{p.member}</td>
              <td>{p.date}</td>
              <td>{p.amount}</td>
              <td>{p.method}</td>
              <td><Badge status={p.status} /></td>
            </tr>
          )}
        />
      </div>
    </>
  );
}

export default PaymentHistoryAll;

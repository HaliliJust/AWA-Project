import { Printer, Download } from "lucide-react";
import PageHead from "../../components/PageHead";
import DataTable from "../../components/DataTable";
import Badge from "../../components/Badge";
import { allPayments } from "../../data/mockData";

function GenerateReceipts() {
  const latest = allPayments[0];

  return (
    <>
      <PageHead
        eyebrow="Payments"
        title="Generate Payment Receipts"
        description="Issue receipts for successful, verified payments."
      />

      <div className="split">
        <div className="card">
          <div className="card-head">
            <h3>Verified Payments</h3>
          </div>
          <DataTable
            columns={["Payment ID", "Member", "Amount", "Status", ""]}
            rows={allPayments.filter((p) => p.status === "Verified")}
            renderRow={(p) => (
              <tr key={p.id}>
                <td className="cell-primary">{p.id}</td>
                <td>{p.member}</td>
                <td>{p.amount}</td>
                <td><Badge status={p.status} /></td>
                <td><button type="button" className="btn btn-ghost btn-sm">Preview</button></td>
              </tr>
            )}
          />
        </div>

        <div className="card">
          <div className="card-head">
            <h3>Receipt Preview</h3>
          </div>
          <div style={{ background: "var(--bg-soft)", border: "1px dashed var(--border)", borderRadius: 10, padding: 20 }}>
            <div className="sidebar-logo" style={{ fontSize: "1.1rem", marginBottom: 14 }}>
              Smart<span>fIT</span>
            </div>
            <div className="info-list">
              <li><span>Receipt No.</span><span>{latest.id}</span></li>
              <li><span>Member</span><span>{latest.member}</span></li>
              <li><span>Date</span><span>{latest.date}</span></li>
              <li><span>Method</span><span>{latest.method}</span></li>
              <li><span>Amount Paid</span><span>{latest.amount}</span></li>
              <li><span>Status</span><span><Badge status={latest.status} /></span></li>
            </div>
          </div>
          <div className="btn-row" style={{ marginTop: 18 }}>
            <button type="button" className="btn btn-primary">
              <Printer /> Print Receipt
            </button>
            <button type="button" className="btn btn-ghost">
              <Download /> Download PDF
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default GenerateReceipts;

// Removal records share the member database so access and cancellation save together.
export function accountRemoval(username) {
  const db = JSON.parse(localStorage.getItem('smartfit.members.v2') || '{}');
  return db.removals?.[String(username).toLowerCase()] || null;
}

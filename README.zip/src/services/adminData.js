import { getAccounts } from './accountStore';
import { DEMO_ACCOUNTS } from '../data/demoAccounts';
import { currentTrainer } from '../data/mockData';
import { localDate, membershipInfo } from './memberStore';

export function trainerProfile(account) {
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem('smartfit.trainer-profile.' + account.username) || '{}'); } catch {}
  const demo = account.username === 'trainer001' ? currentTrainer : {};
  return {
    name: saved.name || account.name || [account.firstName, account.lastName].filter(Boolean).join(' '),
    email: saved.email ?? account.email ?? demo.email,
    phone: saved.phone ?? account.contactNumber ?? demo.phone,
    specialty: saved.specialty ?? account.specialty ?? demo.specialty,
    certification: saved.certification ?? account.certifications ?? demo.certification,
    experience: saved.experience ?? account.experience ?? demo.experience,
    photo: saved.photo || '',
  };
}
export function adminData(database, now = new Date()) {
  const accounts = [...new Map([...DEMO_ACCOUNTS, ...getAccounts()].map(a => [a.username.toLowerCase(), a])).values()].filter(a => !database.removals?.[a.username.toLowerCase()]);
  const members = accounts.filter(a => a.role === 'member').map(a => database.members[a.username.toLowerCase()]).filter(Boolean);
  const allMembersAdmin = members.map(m => {
    const sessions = m.workoutSchedule.filter(s => ['Completed', 'Missed'].includes(s.status));
    return { username: accounts.find(a => database.members[a.username.toLowerCase()] === m)?.username.toLowerCase(), id: m.profile.memberId, name: m.profile.name, plan: m.membership.plan, goal: m.profile.fitnessGoal || 'Not set', status: membershipInfo(m.membership, now).status, attendance: sessions.length ? Math.round(sessions.filter(s => s.status === 'Completed').length / sessions.length * 100) : 0, trainer: [...new Set(m.workoutSchedule.filter(s => !database.removals?.[s.trainerId?.toLowerCase()] && ['Scheduled', 'Completed', 'Missed'].includes(s.status)).map(s => s.trainer))].filter(Boolean).join(', ') || 'Unassigned' };
  });
  const allTrainersAdmin = accounts.filter(a => a.role === 'trainer').map(a => {
    const sessions = members.flatMap(m => m.workoutSchedule.filter(s => s.trainerId?.toLowerCase() === a.username.toLowerCase() && ['Scheduled', 'Completed', 'Missed'].includes(s.status)));
    const profile = trainerProfile(a);
    return { username: a.username.toLowerCase(), id: a.id || a.username, name: profile.name, specialty: profile.specialty || 'Not provided', role: profile.specialty || 'Not provided', status: a.status || 'Active', assigned: members.filter(m => membershipInfo(m.membership, now).active && m.workoutSchedule.some(s => sessions.includes(s))).length, sessionsToday: sessions.filter(s => s.date === localDate(now)).length };
  });
  const goalCounts = allMembersAdmin.reduce((counts, m) => ({ ...counts, [m.goal]: (counts[m.goal] || 0) + 1 }), {});
  const goalStats = Object.entries(goalCounts).map(([goal, count]) => ({ goal, count })).sort((a, b) => b.count - a.count);
  const month = localDate(now).slice(0, 7);
  const payments = Object.values(database.members).flatMap(m => m.payments).filter(p => p.date?.startsWith(month));
  const sessions = members.flatMap(m => m.workoutSchedule).filter(s => ['Completed', 'Missed'].includes(s.status));
  return { removals: Object.values(database.removals || {}).sort((a,b) => b.removedAt.localeCompare(a.removedAt)), allMembersAdmin, allTrainersAdmin, goalStats, goalValues: goalStats.map(g => g.count), goalLabels: goalStats.map(g => g.goal),
    memberPaymentStatus: members.map(m => ({ id: m.profile.memberId, name: m.profile.name, plan: m.membership.plan, amount: m.membership.paymentStatus === 'Paid' ? 'PHP 0' : 'Not recorded', dueDate: m.membership.nextPayment || 'Not set', status: m.membership.paymentStatus })),
    trainerPaymentStatus: [],
    systemOverview: { totalMembers: members.length, totalTrainers: allTrainersAdmin.length, activeMemberships: allMembersAdmin.filter(m => m.status === 'Active').length, expiredMemberships: allMembersAdmin.filter(m => m.status === 'Expired').length, totalPayments: 'PHP ' + payments.filter(p => p.status === 'Paid').reduce((sum, p) => sum + Number(p.amount || 0), 0).toLocaleString(), pendingPayments: members.filter(m => m.membership.paymentStatus === 'Pending').length, avgAttendanceRate: sessions.length ? Math.round(sessions.filter(s => s.status === 'Completed').length / sessions.length * 100) : 0, popularGoal: goalStats[0]?.goal || 'No goals recorded' }
  };
}

import { membershipInfo } from './memberStore';
import { workoutPrograms as templates } from '../data/mockData';

// A request alone is not an assignment. Only confirmed workouts establish clients.
export function trainerData(database, trainerId) {
  const records = Object.entries(database.members).filter(([username]) => !database.removals?.[username]).map(([username, member]) => ({
    ...member,
    username,
    sessions: member.workoutSchedule.filter(s => s.trainerId === trainerId),
    requests: member.workoutRequests.filter(r => r.trainerId === trainerId),
  }));
  const clients = records.filter(m => membershipInfo(m.membership).active &&
    m.sessions.some(s => ['Scheduled', 'Completed', 'Missed'].includes(s.status)));
  const programs = clients.flatMap(m => m.sessions.filter(s => ['Scheduled', 'Completed', 'Missed'].includes(s.status)).map(s => ({
    ...templates.find(t => t.id === s.planId),
    ...s,
    name: s.program,
    member: m.profile.name,
    memberUsername: m.username,
    level: s.level || templates.find(t => t.id === s.planId)?.level || s.activityLevel || 'Not provided',
    duration: `${s.duration} minutes`,
    schedule: `${s.date} at ${s.time}`,
  })));
  const requests = records.flatMap(m => m.requests.filter(r => r.status === 'Pending').map(r => ({ ...r, member: m.profile.name })));
  return { clients, programs, requests };
}

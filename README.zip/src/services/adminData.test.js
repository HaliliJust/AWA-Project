import { adminData } from './adminData';
import { defaultMemberState } from './memberStore';
beforeEach(() => localStorage.clear());
test('admin counts only unique registered members, excluding trainers and orphaned data', () => {
  localStorage.setItem('smartfit.accounts', JSON.stringify([
    {username: 'MEMBER001', role: 'member', firstName: 'Member'},
    {username: 'newmember', role: 'member', firstName: 'New'},
    {username: 'coach', role: 'trainer', firstName: 'Coach'}
  ]));
  const member = defaultMemberState();
  member.membership.expiryDate = '2099-01-01';
  const inactive = defaultMemberState({username: 'newmember', name: 'New member', id: 'new'});
  const data = adminData({members: {member001: member, newmember: inactive, removed: defaultMemberState()}});
  expect(data.systemOverview.totalMembers).toBe(2);
  expect(data.systemOverview.activeMemberships).toBe(1);
  expect(data.allMembersAdmin).toHaveLength(2);
  expect(data.memberPaymentStatus).toHaveLength(2);
  expect(data.goalStats.reduce((sum, g) => sum + g.count, 0)).toBe(2);
});

test('removed accounts are excluded from current rosters but payment history remains', () => {
  const member = defaultMemberState();
  member.payments = [{date: '2026-10-01', status: 'Paid', amount: 100}];
  const data = adminData({members: {member001: member}, removals: {member001: {username: 'member001', role: 'member', reason: 'Removed', removedAt: '2026-10-01'}}}, new Date('2026-10-01T12:00:00'));
  expect(data.allMembersAdmin).toHaveLength(0);
  expect(data.systemOverview.totalMembers).toBe(0);
  expect(data.systemOverview.totalPayments).toBe('PHP 100');
  expect(data.removals).toHaveLength(1);
});

import { defaultMemberState, membershipInfo, validateSlot, weeklySummary, reconcile, readDatabase, writeDatabase } from './memberStore';
beforeEach(() => localStorage.clear());
test('expiry is derived rather than trusting an Active label', () => {
  const m = {
    ...defaultMemberState().membership,
    expiryDate: '2026-09-14'
  };
  expect(membershipInfo(m, new Date('2026-09-26T12:00:00')).active).toBe(false);
  expect(membershipInfo(m, new Date('2026-09-26T12:00:00')).daysLeft).toBe(0);
  expect(membershipInfo(m, new Date('2026-09-14T12:00:00')).active).toBe(true);
});
test('weekday and weekend hours include the entire session', () => {
  const now = new Date('2026-09-01T12:00:00');
  expect(() => validateSlot('2026-09-28', '07:59', 60, now)).toThrow();
  expect(() => validateSlot('2026-09-28', '20:00', 60, now)).not.toThrow();
  expect(() => validateSlot('2026-09-28', '20:01', 60, now)).toThrow();
  expect(() => validateSlot('2026-09-27', '07:00', 60, now)).not.toThrow();
  expect(() => validateSlot('2026-09-27', '21:01', 60, now)).toThrow();
  expect(() => validateSlot('2026-08-27', '09:00', 60, now)).toThrow();
});
test('weekly activity counts all sessions only within the current week', () => {
  const rows = [{
    date: '2026-09-21',
    status: 'Completed',
    duration: 30
  }, {
    date: '2026-09-21',
    status: 'Completed',
    duration: 60
  }, {
    date: '2026-09-21',
    status: 'Scheduled',
    duration: 60
  }, {
    date: '2026-09-14',
    status: 'Completed',
    duration: 60
  }, {
    date: '2026-09-21',
    status: 'Proposed',
    duration: 60
  }];
  const week = weeklySummary(rows, new Date('2026-09-26T12:00:00'));
  expect(week[0].completed).toBe(2);
  expect(week[0].duration).toBe(90);
  expect(week[0].sessions).toHaveLength(3);
});
test('referral awards and reminders are persisted and deduplicated', () => {
  localStorage.setItem('smartfit.accounts', JSON.stringify([{
    id: 'new',
    username: 'friend',
    role: 'member',
    referredBy: 'member001',
    firstName: 'Friend'
  }]));
  const db = {
    members: {
      member001: defaultMemberState()
    }
  };
  db.members.member001.workoutSchedule.push({
    id: 's',
    date: '2026-09-25',
    time: '09:00',
    program: 'Strength',
    duration: 60,
    status: 'Scheduled'
  });
  reconcile(db, new Date('2026-09-26T12:00:00'));
  reconcile(db, new Date('2026-09-26T12:00:00'));
  expect(db.members.member001.membership.points).toBe(20);
  expect(db.members.member001.workoutSchedule[0].status).toBe('Missed');
  expect(db.members.member001.notifications.filter(n => n.type === 'workout_missed')).toHaveLength(1);
  writeDatabase(db);
  expect(readDatabase().members.member001.membership.points).toBe(20);
});
test('migrates the old member record without assigning it to another account', () => {
  localStorage.setItem('smartfit.member', JSON.stringify({
    profile: {
      name: 'Saved Member'
    },
    membership: {
      points: 25
    }
  }));
  localStorage.setItem('smartfit.accounts', JSON.stringify([{
    id: 'new',
    username: 'other',
    firstName: 'Other',
    role: 'member'
  }]));
  const db = readDatabase();
  expect(db.members.member001.profile.name).toBe('Saved Member');
  expect(db.members.other.profile.name).toBe('Other');
  expect(db.members.other.membership.points).toBe(0);
});

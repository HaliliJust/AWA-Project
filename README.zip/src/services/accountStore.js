import { DEMO_ACCOUNTS } from "../data/demoAccounts";

/**
 * Account store — everything created through "Create Account" lives here,
 * in the browser's localStorage under one key.
 *
 *   getAccounts()                 -> all registered accounts (with computed `age`)
 *   getAccount(username)          -> one account, or null
 *   registerAccount(data)         -> create an account            (async: hashes the password)
 *   updateAccount(username, patch)-> edit an account's details
 *   setPassword(username, pw)     -> change a password            (async)
 *   deleteAccount(username)       -> remove an account
 *   clearAccounts()               -> remove every registered account
 *   verifyLogin(username, pw)     -> account if credentials match (async)
 *
 * You can also inspect or edit the raw data in the browser:
 *   DevTools -> Application -> Local Storage -> "smartfit.accounts".
 *
 * NOTE: this is a front-end-only demo. Passwords are salted + hashed before
 * saving (never stored as plain text), but a real system must hash and store
 * them on a server.
 */

const STORAGE_KEY = "smartfit.accounts";

// Fields that updateAccount() will never overwrite.
const LOCKED_FIELDS = ["id", "username", "passwordHash", "salt", "createdAt"];

// ---------- helpers (exported: the forms use them too) ----------

export const norm = (s) => String(s ?? "").trim().toLowerCase();

/** "+63 917-123-4567" / "0917 123 4567" -> "09171234567" (spaces, dashes, brackets removed; +63 -> 0). */
export function normalizePhone(value) {
  const cleaned = String(value ?? "").replace(/[\s\-().]/g, "");
  return cleaned.startsWith("+63") ? `0${cleaned.slice(3)}` : cleaned;
}

/** Accepts PH mobile numbers (0917…) and landlines with area code. */
export function isValidPhone(value) {
  return /^0\d{9,10}$/.test(normalizePhone(value));
}

/** Age in whole years for a "YYYY-MM-DD" birthdate, or null if it isn't a valid date. */
export function calcAge(birthdate, today = new Date()) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(birthdate || "");
  if (!m) return null;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const born = new Date(y, mo - 1, d);
  if (born.getFullYear() !== y || born.getMonth() !== mo - 1 || born.getDate() !== d) return null;
  let age = today.getFullYear() - y;
  const beforeBirthday =
    today.getMonth() + 1 < mo || (today.getMonth() + 1 === mo && today.getDate() < d);
  if (beforeBirthday) age -= 1;
  return age;
}

export const displayName = (a) => `${a.firstName} ${a.lastName}`.trim();
export const initialsOf = (a) => `${a.firstName?.[0] ?? ""}${a.lastName?.[0] ?? ""}`.toUpperCase();

// ---------- raw storage ----------

function read() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

function write(list) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
    return true;
  } catch {
    return false; // storage full, or blocked (e.g. private mode)
  }
}

const withAge = (a) => ({ ...a, age: calcAge(a.birthdate) });

// ---------- password hashing ----------

function randomSalt() {
  const bytes = new Uint8Array(16);
  if (window.crypto?.getRandomValues) window.crypto.getRandomValues(bytes);
  else for (let i = 0; i < bytes.length; i += 1) bytes[i] = Math.floor(Math.random() * 256);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

async function hashPassword(password, salt) {
  const text = `${salt}:${password}`;
  if (window.crypto?.subtle) {
    const digest = await window.crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return `sha256:${Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("")}`;
  }
  // Fallback for non-secure pages (plain http on a LAN address), where Web Crypto is unavailable.
  // Not cryptographic — it only keeps the password from being stored as readable text.
  let h = 0x811c9dc5;
  for (const ch of text) {
    h ^= ch.codePointAt(0);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return `fnv:${h.toString(16)}`;
}

// ---------- reading ----------

export function getAccounts() {
  return read().map(withAge);
}

export function getAccount(username) {
  const found = read().find((a) => norm(a.username) === norm(username));
  return found ? withAge(found) : null;
}

export function isUsernameTaken(username) {
  const u = norm(username);
  return DEMO_ACCOUNTS.some((a) => norm(a.username) === u) || read().some((a) => norm(a.username) === u);
}

export function isEmailTaken(email) {
  const e = norm(email);
  return !!e && read().some((a) => norm(a.email) === e);
}

/** Referral code = the inviter's username. Only members and trainers can invite. */
export function findReferrer(code) {
  const u = norm(code);
  const demo = DEMO_ACCOUNTS.find((a) => norm(a.username) === u && a.role !== "admin");
  if (demo) return { username: demo.username, role: demo.role };
  const stored = read().find((a) => norm(a.username) === u);
  return stored ? { username: stored.username, role: stored.role } : null;
}

// ---------- writing ----------

/**
 * Create an account. Returns { ok: true, account } or { ok: false, errors }
 * where errors maps a field name (username, email, referralCode, form) to a message.
 */
export async function registerAccount(data) {
  const errors = {};

  if (isUsernameTaken(data.username)) errors.username = "That username is already taken.";
  if (isEmailTaken(data.email)) errors.email = "An account with this email already exists.";

  let referredBy = null;
  if (String(data.referralCode ?? "").trim()) {
    const referrer = findReferrer(data.referralCode);
    if (!referrer) errors.referralCode = "We couldn't find a member or trainer with that username.";
    else if (norm(referrer.username) === norm(data.username))
      errors.referralCode = "You can't use your own username as a referral code.";
    else referredBy = referrer.username;
  }

  if (Object.keys(errors).length) return { ok: false, errors };

  const salt = randomSalt();
  const passwordHash = await hashPassword(data.password, salt);

  const account = {
    id: `USR-${Date.now().toString(36).toUpperCase()}`,
    role: data.role,
    username: data.username.trim(),
    salt,
    passwordHash,

    firstName: data.firstName.trim(),
    middleName: (data.middleName ?? "").trim(),
    lastName: data.lastName.trim(),
    birthdate: data.birthdate,
    gender: data.gender,

    contactNumber: normalizePhone(data.contactNumber),
    email: data.email.trim().toLowerCase(),
    emergencyContactName: data.emergencyContactName.trim(),
    emergencyContactNumber: normalizePhone(data.emergencyContactNumber),

    referredBy,
    status: "active",
    createdAt: new Date().toISOString(),
  };

  // Fitness profile is for members only.
  if (data.role === "member") {
    account.height = data.height;
    account.weight = data.weight;
    account.bodyTypeStyle = data.bodyTypeStyle;
    account.bodyType = data.bodyType;
    account.bodyBuild = data.bodyBuild;
    account.fitnessGoals = data.fitnessGoals;
    account.fitnessGoalNote = data.fitnessGoalNote || "";
  }

  // Professional profile is for trainers only.
  if (data.role === "trainer") {
    account.specialty = data.specialty;
    account.certifications = (data.certifications ?? "").trim();
    account.experience = data.experience;
    account.idFront = data.idFront;
    account.idBack = data.idBack;
  }

  const list = read();
  list.push(account);
  if (!write(list)) {
    return {
      ok: false,
      errors: { form: "We couldn't save your account because browser storage is unavailable or full." },
    };
  }
  return { ok: true, account: withAge(account) };
}

/** Edit an account's details. id, username, password and createdAt can't be changed here. */
export function updateAccount(username, patch) {
  const list = read();
  const i = list.findIndex((a) => norm(a.username) === norm(username));
  if (i === -1) return null;
  const safe = { ...patch };
  LOCKED_FIELDS.forEach((f) => delete safe[f]);
  list[i] = { ...list[i], ...safe };
  return write(list) ? withAge(list[i]) : null;
}

export async function setPassword(username, newPassword) {
  const list = read();
  const i = list.findIndex((a) => norm(a.username) === norm(username));
  if (i === -1) return false;
  const salt = randomSalt();
  list[i] = { ...list[i], salt, passwordHash: await hashPassword(newPassword, salt) };
  return write(list);
}

export function deleteAccount(username) {
  const list = read();
  const next = list.filter((a) => norm(a.username) !== norm(username));
  if (next.length === list.length) return false;
  return write(next);
}

export function clearAccounts() {
  try {
    localStorage.removeItem(STORAGE_KEY);
    return true;
  } catch {
    return false;
  }
}

/** Returns the stored account when username + password match, otherwise null. */
export async function verifyLogin(username, password) {
  const found = read().find((a) => norm(a.username) === norm(username));
  if (!found) return null;
  const attempt = await hashPassword(password, found.salt);
  return attempt === found.passwordHash ? withAge(found) : null;
}

import { accountRemoval } from './accountAccess';
import { getAccounts } from './accountStore';
import { DEMO_ACCOUNTS } from '../data/demoAccounts';
export const STORAGE_KEY = 'smartfit.members.v2';
export const localDate = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
export const REWARDS = [{
  id: 'guest',
  name: 'One guest day pass',
  points: 100
}, {
  id: 'class',
  name: 'One group class pass',
  points: 150
}];
export function defaultMemberState(a = DEMO_ACCOUNTS[0]) {
  const demo = a.username === 'member001';
  return {
    profile: {
      memberId: a.id || 'MBR-00214',
      name: a.name || `${a.firstName || ''} ${a.lastName || ''}`.trim(),
      email: a.email || (demo ? 'justine.halili@email.com' : ''),
      contact: a.contactNumber || '',
      dob: a.birthdate || '',
      gender: a.gender || 'Prefer not to say',
      height: a.height || (demo ? 165 : ''),
      weight: a.weight || (demo ? 58 : ''),
      bodyType: a.bodyType || 'Mesomorph',
      fitnessGoal: a.fitnessGoals?.[0] || 'General Fitness',
      address: '',
      emergencyName: a.emergencyContactName || '',
      emergencyContact: a.emergencyContactNumber || '',
      avatar: '',
      referralCode: a.username
    },
    membership: {
      plan: demo ? 'Premium Monthly' : 'No plan',
      status: demo ? 'Active' : 'Inactive',
      joinDate: demo ? '2025-01-14' : localDate(),
      expiryDate: demo ? '2026-09-14' : '',
      paymentStatus: demo ? 'Paid' : 'Unpaid',
      nextPayment: demo ? '2026-09-14' : '',
      points: 0,
      referralPoints: 0,
      purchasedPoints: 0
    },
    notifications: [],
    workoutSchedule: [],
    workoutRequests: [],
    attendanceHistory: [],
    payments: [],
    rewards: [],
    creditedReferrals: []
  };
}
export function membershipInfo(m, now = new Date()) {
  const expiry = new Date(m.expiryDate);
  expiry.setHours(23, 59, 59, 999);
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  const daysLeft = Number.isFinite(expiry.getTime()) ? Math.max(0, Math.ceil((expiry - start) / 86400000)) : 0;
  const active = m.status === 'Active' && expiry >= now && m.paymentStatus === 'Paid';
  return {
    ...m,
    daysLeft,
    active,
    status: active ? 'Active' : m.status === 'Active' ? 'Expired' : m.status
  };
}
export function activeTrainers() {
  return [...DEMO_ACCOUNTS.filter(a => a.role === 'trainer'), ...getAccounts().filter(a => a.role === 'trainer' && a.status?.toLowerCase() === 'active')].filter(a => !accountRemoval(a.username)).map(a => ({
    username: a.username,
    name: a.name || `${a.firstName} ${a.lastName}`
  }));
}
export function hoursFor(date) {
  return [0, 6].includes(new Date(`${date}T12:00:00`).getDay()) ? {
    min: '07:00',
    max: '22:00'
  } : {
    min: '08:00',
    max: '21:00'
  };
}
export function validateSlot(date, time, duration = 60, now = new Date()) {
  const start = new Date(`${date}T${time}`);
  if (!date || !time || !Number.isFinite(start.getTime()) || start <= now) throw new Error('Choose a future date and time.');
  const h = hoursFor(date),
    minutes = v => Number(v.slice(0, 2)) * 60 + Number(v.slice(3));
  if (time < h.min || minutes(time) + Number(duration) > minutes(h.max) || !Number.isFinite(Number(duration)) || Number(duration) <= 0) throw new Error(`Your entire session must fit between ${h.min} and ${h.max}.`);
}
export function notify(s, n) {
  if (n.id && s.notifications.some(x => x.id === n.id)) return;
  s.notifications.unshift({
    id: uid(),
    read: false,
    createdAt: new Date().toISOString(),
    ...n
  });
}
export function reconcile(db, now = new Date()) {
  db.trainerNotifications ||= {};
  db.removals ||= {};
  const accounts = getAccounts();
  for (const a of [DEMO_ACCOUNTS[0], ...accounts.filter(a => a.role === 'member')]) {
    const key = a.username.toLowerCase();
    if (db.removals[key]) continue;
    if (!db.members[key]) db.members[key] = defaultMemberState(a);
  }
  Object.entries(db.members).forEach(([username, s]) => {
    s.personalPlans ||= [];
    if (db.removals[username]) return;
    const info = membershipInfo(s.membership, now);
    if (info.expiryDate && info.daysLeft <= 7) notify(s, {
      id: `expiry-${info.expiryDate}-${localDate(now)}`,
      type: 'membership_expiry',
      title: info.active ? `Membership expires in ${info.daysLeft} days` : 'Your membership has expired',
      subtitle: `Renew your ${info.plan} membership.`,
      link: '/member/renew'
    });
    for (const a of accounts.filter(a => a.referredBy?.toLowerCase() === username && a.role === 'member')) {
      if (!s.creditedReferrals.includes(a.id)) {
        s.creditedReferrals.push(a.id);
        s.membership.points += 20;
        s.membership.referralPoints += 20;
        notify(s, {
          title: 'Referral successful: 20 points earned',
          subtitle: `${a.firstName} registered using your referral code.`,
          link: '/member/membership'
        });
      }
    }
    s.workoutSchedule.forEach(w => {
      const end = new Date(`${w.date}T${w.time}`).getTime() + (parseFloat(w.duration) || 60) * 60000;
      if (w.status === 'Scheduled' && end < now.getTime()) w.status = 'Missed';
      if (['Completed', 'Missed', 'Cancelled'].includes(w.status)) notify(s, {
        id: `session-${w.id}-${w.status}`,
        type: w.status === 'Completed' ? 'workout_completed' : 'workout_missed',
        title: `${w.program}: ${w.status === 'Cancelled' ? 'did not proceed' : w.status.toLowerCase()}`,
        subtitle: `${w.date} at ${w.time}`,
        link: '/member/workout-schedule'
      });else if (w.status === 'Scheduled' && w.date >= localDate(now)) notify(s, {
        id: `reminder-${w.id}-${w.date}-${w.date === localDate(now) ? 'today' : 'upcoming'}`,
        type: 'workout_reminder',
        title: w.date === localDate(now) ? "Today's workout" : 'Upcoming workout',
        subtitle: `${w.program} · ${w.date} at ${w.time} with ${w.trainer}`,
        link: '/member/workout-schedule'
      });
    });
  });
  return db;
}
export function readDatabase() {
  const raw = localStorage.getItem(STORAGE_KEY);
  let db;
  if (raw) {
    db = JSON.parse(raw);
    if (!db?.members) throw new Error('Saved member data could not be loaded.');
  } else {
    db = {
      members: {}
    };
    const legacy = localStorage.getItem('smartfit.member');
    if (legacy) {
      const old = JSON.parse(legacy),
        base = defaultMemberState();
      db.members.member001 = {
        ...base,
        ...old,
        profile: {
          ...base.profile,
          ...old.profile,
          referralCode: 'member001'
        },
        membership: {
          ...base.membership,
          ...old.membership
        }
      };
    }
  }
  return reconcile(db);
}
export function writeDatabase(db) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
}
export function weeklySummary(schedule, now = new Date()) {
  const monday = new Date(now);
  monday.setHours(0, 0, 0, 0);
  monday.setDate(monday.getDate() - (monday.getDay() + 6) % 7);
  return Array.from({
    length: 7
  }, (_, i) => {
    const date = new Date(monday);
    date.setDate(date.getDate() + i);
    const sessions = schedule.filter(s => s.date === localDate(date) && !['Proposed', 'Cancelled'].includes(s.status));
    const completed = sessions.filter(s => s.status === 'Completed');
    return {
      date: localDate(date),
      label: date.toLocaleDateString('en', {
        weekday: 'short'
      }),
      sessions,
      completed: completed.length,
      duration: completed.reduce((sum, s) => sum + (parseFloat(s.duration) || 0), 0)
    };
  });
}

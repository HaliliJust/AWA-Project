import { trainerData } from './trainerData';
import { defaultMemberState, localDate } from './memberStore';

test('pending requests are separate from confirmed client assignments', () => {
  const member = defaultMemberState();
  const future = new Date(); future.setFullYear(future.getFullYear() + 1);
  member.membership.expiryDate = localDate(future);
  member.workoutRequests = [{id: 'pending', trainerId: 'trainer001', status: 'Pending'}];
  const db = {members: {member001: member}};
  expect(trainerData(db, 'trainer001').clients).toHaveLength(0);
  expect(trainerData(db, 'trainer001').requests).toHaveLength(1);
  member.workoutSchedule = [{id: 's', trainerId: 'trainer001', status: 'Proposed'}];
  expect(trainerData(db, 'trainer001').clients).toHaveLength(0);
  member.workoutSchedule[0].status = 'Scheduled';
  expect(trainerData(db, 'trainer001').clients).toHaveLength(1);
  expect(trainerData(db, 'another-trainer').clients).toHaveLength(0);
  member.workoutSchedule[0].status = 'Cancelled';
  expect(trainerData(db, 'trainer001').clients).toHaveLength(0);
});

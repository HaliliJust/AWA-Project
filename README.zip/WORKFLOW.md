﻿# Member and trainer workflow

The existing dark theme and page structure are retained. The supplied attachment was the written requirements; no PPT was present. Accessibility changes follow WCAG principles: associated labels, keyboard controls, visible focus, text status messages, reduced motion, and navigation at narrow widths. This is not a full WCAG conformance audit.

## Using the workflow

1. Sign in with `member001` / `member123`. Its original September 14, 2026 expiry is retained, so renew first if it has expired.
2. Renew Membership: choose a plan, confirm its details, choose payment, and complete the local demo checkout. No payment service is connected and no money is transferred.
3. Workout Plans: select a plan, an active registered trainer, a future date/time and a session duration. The entire session must fit within weekday 08:00–21:00 or weekend 07:00–22:00 hours.
4. Sign in with `trainer001` / `trainer123` and open Schedule Sessions. Accept, deny, or propose a different date/time. Other registered trainers receive only their own requests.
5. Sign back in as the member. Notifications link to the response and schedule. Accept or decline proposed alternatives. Once a confirmed session starts, mark it completed or did not proceed. Uncompleted sessions are marked missed after their end time.
6. Save a profile with a required JPG, PNG or WebP photo (under 2 MB). Photos are resized before storage. The sidebar and digital membership card reflect saved changes.

## Persistence and rewards

Trainer client lists and statistics are based on active memberships with confirmed workouts for the signed-in trainer. Pending requests and proposed alternatives alone do not create a client. Empty trainer pages no longer use the sample clients or sample progress. View opens the saved member profile, body type, measurements, goals, relevant contact details, and assigned workouts.

Workout Schedule includes suggestions from the available plan catalog; choosing one opens its request form. Inactive memberships can preview suggestions but must renew before choosing a plan. Both profiles use a photo preview and accessible upload control. Trainer profile edits are saved under an account-specific `smartfit.trainer-profile` key, and the Quick Notes section has been removed.

`smartfit.members.v2` stores records by member username. An existing `smartfit.member` record migrates to the original demo member. Registration remains in `smartfit.accounts`; sessions remain in sessionStorage. Member/trainer tabs in the same browser origin refresh on storage events, focus, and a 30-second timer. Reminders reconcile while the app is open and when it is reopened; there is no background push service or cross-device synchronization.

Referral codes use the existing registration convention: the inviter's username. The initial policy is 20 points for each successfully registered referred member, credited once per account ID. One point discounts one peso. Available rewards are a guest day pass (100 points) and group class pass (150 points); redeemed references persist for front-desk review. Reward definitions live in `src/services/memberStore.js`. These policy values are implementation defaults because the request did not specify rates or reward inventory.

Payment records, discounts, rewards, notification read state, profiles, workout requests, outcomes and attendance persist. Saving failures surface an error instead of reporting success. This remains a local browser prototype, not a server-authorized booking or payment system.

## Verification

Run `npm test -- --watchAll=false --runInBand` and `npm run build`.

Tests cover date boundaries, weekly totals, migration, referral deduplication, account separation, membership restrictions, trainer ownership, alternative approval, refresh persistence, reward balance protection, storage errors, completion/attendance updates, the shared header across roles, and profile form/card synchronization. The page tests use a DOM environment and mock the 3D preview; they do not replace real-browser visual or assistive-technology testing.
